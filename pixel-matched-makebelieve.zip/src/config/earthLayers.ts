import type { BasemapType, LayerConfig } from "@/types/earth";

/** Selection marker drawn on the WebGL canvas (Cesium needs a hex/rgb colour, not a CSS token). */
export const GLOBE_MARKER_COLOR = "#43A071";
/** Opacity of the SST overlay above the basemap. */
export const SST_OVERLAY_ALPHA = 0.85;
/** Opacity of the ERA5 air-temperature map: high so colours match the legend, with faint basemap labels. */
export const AIR_TEMP_OVERLAY_ALPHA = 0.9;
/** Opacity of the ERA5 wind-speed map. */
export const WIND_OVERLAY_ALPHA = 0.9;
/** Opacity of the ERA5 daily precipitation map. */
export const PRECIP_OVERLAY_ALPHA = 0.9;
/** Opacity of the ERA5 2 m relative-humidity map. */
export const HUMIDITY_OVERLAY_ALPHA = 0.9;
/** Opacity of the ERA5 moisture-flux map. */
export const FLUX_OVERLAY_ALPHA = 0.9;

type BasemapSource =
  | { kind: "osm"; label: string; url: string; maximumLevel: number; credit: string }
  | { kind: "template"; label: string; url: string; maximumLevel: number; credit: string };

/**
 * Keyless basemaps (both verified to send CORS headers, which WebGL requires).
 * - Street: OpenStreetMap standard tiles.
 * - Satellite: NASA Blue Marble: Next Generation via NASA GIBS (public domain, no key).
 */
export const basemapSources: Record<BasemapType, BasemapSource> = {
  default: {
    kind: "osm",
    label: "Street",
    url: "https://tile.openstreetmap.org/",
    maximumLevel: 19,
    credit: "© OpenStreetMap contributors",
  },
  satellite: {
    kind: "template",
    label: "Satellite",
    url: "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/BlueMarble_NextGeneration/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpeg",
    maximumLevel: 8,
    credit: "Imagery: NASA Blue Marble: Next Generation, via NASA GIBS",
  },
};

export const earthLayers: LayerConfig[] = [
  {
    id: "sea-surface-temperature",
    name: "Sea Surface Temperature",
    variable: "SST",
    units: "°C",
    description:
      "Sea surface temperature over ocean areas, derived from satellite observations. Distinct from atmospheric air temperature.",
    status: "active",
    provider: "NOAA NCEI / CoastWatch ERDDAP",
    attribution:
      "NOAA OISST V2.1 (AVHRR-only, final); Huang et al. (2020), DOI: 10.25921/RE9P-PT57",
    coverage: "Global oceans",
    spatialResolution: "0.25° (approx. 25 km)",
    temporalResolution: "Daily",
    dateRange: "September 1981–present",
    linkedEpisode: "/living-earth",
  },
  {
    id: "air-temperature",
    name: "2 m Air Temperature",
    variable: "2 m temperature (ERA5 2m_temperature, short name 2t, parameter 167)",
    units: "°C",
    description:
      "Air temperature 2 m above land, sea or inland water from the ERA5 reanalysis, shown as a daily mean. Distinct from sea surface and land surface (skin) temperature.",
    status: "active",
    provider: "Copernicus C3S / ECMWF ERA5",
    attribution:
      "Contains modified Copernicus Climate Change Service information. ERA5 hourly data on single levels (Hersbach et al., 2023), DOI: 10.24381/cds.adbb2d47. Map: C3S/ECMWF Climate Pulse. Point values: Open-Meteo.com (CC BY 4.0).",
    coverage: "Global (land and ocean)",
    spatialResolution: "0.25° × 0.25° grid",
    temporalResolution: "Hourly, shown as daily mean (00–23 UTC)",
    dateRange: "1940–present (about 5 days behind real time)",
  },
  {
    id: "precipitation",
    name: "Precipitation — daily accumulation",
    variable:
      "ERA5 total_precipitation (tp, param 228): rain and snow (liquid and frozen water) reaching the surface",
    units: "mm/day",
    description:
      "Daily total precipitation from the ERA5 reanalysis: the sum of the 24 hourly accumulations for one UTC day (00:00–24:00 UTC). Includes rain and snow as water equivalent, not rainfall alone.",
    status: "active",
    provider: "Copernicus C3S / ECMWF ERA5 (ARCO-ERA5, Google Cloud)",
    attribution:
      "Contains modified Copernicus Climate Change Service information. ERA5 hourly data on single levels (Hersbach et al., 2023), DOI: 10.24381/cds.adbb2d47. Read from ARCO-ERA5 (Carver & Merose, 2023), Google Cloud public dataset.",
    coverage: "Global (land and ocean)",
    spatialResolution: "0.25° × 0.25° grid",
    temporalResolution: "Hourly accumulations, summed per UTC day",
    dateRange: "1940–present (ERA5T, about 1 week behind real time)",
    linkedEpisode: "/living-earth",
  },
  {
    id: "wind-speed",
    name: "Wind Speed (10 m)",
    variable:
      "10 m wind speed, sqrt(u² + v²) from ERA5 10m_u_component_of_wind (u10, param 165) and 10m_v_component_of_wind (v10, param 166)",
    units: "m/s",
    description:
      "Horizontal wind speed 10 m above the surface from the ERA5 reanalysis, computed from the eastward (u) and northward (v) components of the same hour and grid point. Instantaneous value at 12:00 UTC, not a daily mean.",
    status: "active",
    provider: "Copernicus C3S / ECMWF ERA5 (ARCO-ERA5, Google Cloud)",
    attribution:
      "Contains modified Copernicus Climate Change Service information. ERA5 hourly data on single levels (Hersbach et al., 2023), DOI: 10.24381/cds.adbb2d47. Read from ARCO-ERA5 (Carver & Merose, 2023), Google Cloud public dataset.",
    coverage: "Global (land and ocean)",
    spatialResolution: "0.25° × 0.25° grid",
    temporalResolution: "Hourly, shown at 12:00 UTC (instantaneous)",
    dateRange: "1940–present (ERA5T, about 1 week behind real time)",
  },
  {
    id: "humidity",
    name: "Relative Humidity (2 m)",
    variable:
      "2 m relative humidity, 100 · es(Td)/es(T) from ERA5 2m_temperature (2t, param 167) and 2m_dewpoint_temperature (2d, param 168)",
    units: "%",
    description:
      "Relative humidity 2 m above the surface, derived from ERA5 2 m temperature and dew point of the same hour and grid point, with respect to saturation over water. Instantaneous value at 12:00 UTC, not a daily mean.",
    status: "active",
    provider: "Copernicus C3S / ECMWF ERA5 (ARCO-ERA5, Google Cloud)",
    attribution:
      "Contains modified Copernicus Climate Change Service information. ERA5 hourly data on single levels (Hersbach et al., 2023), DOI: 10.24381/cds.adbb2d47. Read from ARCO-ERA5 (Carver & Merose, 2023), Google Cloud public dataset. Relative humidity derived as documented by ECMWF.",
    coverage: "Global (land and ocean)",
    spatialResolution: "0.25° × 0.25° grid",
    temporalResolution: "Hourly, shown at 12:00 UTC (instantaneous)",
    dateRange: "1940–present (ERA5T, about 1 week behind real time)",
  },
  {
    id: "atmospheric-moisture-flux",
    name: "Atmospheric Moisture Flux",
    variable:
      "Vertically integrated water-vapour transport, sqrt(Fx² + Fy²) from ERA5 vertical_integral_of_eastward_water_vapour_flux (viwve, param 162071) and vertical_integral_of_northward_water_vapour_flux (viwvn, param 162072)",
    units: "kg m⁻¹ s⁻¹",
    description:
      "Horizontal flow of water vapour through the whole atmospheric column (surface to top), per metre across the flow, from the ERA5 reanalysis. Not moisture content, wind speed or precipitation. Instantaneous value at 12:00 UTC, not a daily mean.",
    status: "active",
    provider: "Copernicus C3S / ECMWF ERA5 (ARCO-ERA5, Google Cloud)",
    attribution:
      "Contains modified Copernicus Climate Change Service information. ERA5 hourly data on single levels (Hersbach et al., 2023), DOI: 10.24381/cds.adbb2d47. Read from ARCO-ERA5 (Carver & Merose, 2023), Google Cloud public dataset.",
    coverage: "Global (land and ocean)",
    spatialResolution: "0.25° × 0.25° grid",
    temporalResolution: "Hourly, shown at 12:00 UTC (instantaneous)",
    dateRange: "1940–present (ERA5T, about 1 week behind real time)",
    linkedEpisode: "/living-earth",
  },
];
