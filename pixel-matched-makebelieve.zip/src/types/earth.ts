export type BasemapType = "default" | "satellite";

export type LayerStatus = "planned" | "active";

export type LayerId =
  | "sea-surface-temperature"
  | "air-temperature"
  | "precipitation"
  | "wind-speed"
  | "humidity"
  | "atmospheric-moisture-flux";

export interface ColorRamp {
  stops: { value: number; color: string }[];
}

export interface LayerConfig {
  id: LayerId;
  name: string;
  variable: string;
  units: string;
  description: string;
  status: LayerStatus;
  provider: string;
  attribution: string;
  coverage: string;
  spatialResolution: string;
  temporalResolution: string;
  dateRange: string;
  colorRamp?: ColorRamp;
  validRange?: { min: number; max: number };
  linkedEpisode?: string;
}

export interface GeoPoint {
  longitude: number;
  latitude: number;
}

export interface SelectedLocation extends GeoPoint {
  height: number;
}

export interface GlobeCameraState {
  longitude: number;
  latitude: number;
  height: number;
}

/**
 * What the globe should draw for the SST layer. Tiles are only requested for a verified
 * date and the NOAA source that verified it; enabled without both = data unavailable.
 */
export interface SstOverlayConfig {
  enabled: boolean;
  time: string | null;
  source: "coastwatch" | "ncei" | null;
}

/** ERA5 daily-mean 2 m air temperature map; only drawn for a verified date. */
export interface AirTempOverlayConfig {
  enabled: boolean;
  date: string | null;
}

/** ERA5 10 m wind-speed map (12:00 UTC); only drawn for a verified date. */
export interface WindOverlayConfig {
  enabled: boolean;
  date: string | null;
}

/** ERA5 daily total precipitation map (UTC day); only drawn for a verified complete day. */
export interface PrecipOverlayConfig {
  enabled: boolean;
  date: string | null;
}

/** ERA5 2 m relative humidity map (12:00 UTC); only drawn for a verified date. */
export interface HumidityOverlayConfig {
  enabled: boolean;
  date: string | null;
}

/** ERA5 atmospheric moisture-flux map (12:00 UTC); only drawn for a verified date. */
export interface MoistureFluxOverlayConfig {
  enabled: boolean;
  date: string | null;
}

/** Overlays the globe can draw; each reports its own status. */
export type OverlayId =
  "sst" | "air-temperature" | "wind-speed" | "precipitation" | "humidity" | "moisture-flux";

export type OverlayStatus =
  | { state: "off" }
  | { state: "loading" }
  | { state: "ready" }
  | { state: "error"; message: string };
