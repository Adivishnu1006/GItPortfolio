import { useState } from "react";
import { Layers, ChevronDown, Clock, CheckCircle2, Eye } from "lucide-react";
import { earthLayers } from "@/config/earthLayers";
import type { LayerConfig, LayerId } from "@/types/earth";

type Props = {
  /** Implemented layer currently drawn across the globe. */
  activeLayerId: LayerId | null;
  /** Planned layer whose details are being previewed (never drawn). */
  previewLayerId: LayerId | null;
  onSelect: (layer: LayerConfig | null) => void;
  onPreviewPlanned: (layer: LayerConfig) => void;
};

export function EnvironmentalLayerSelector({
  activeLayerId,
  previewLayerId,
  onSelect,
  onPreviewPlanned,
}: Props) {
  const [open, setOpen] = useState(false);
  const activeLayer = earthLayers.find((l) => l.id === activeLayerId) ?? null;

  return (
    <div className="w-full">
      {open && (
        <div
          role="listbox"
          aria-label="Environmental layers"
          className="mb-2 surface-card rounded-xl overflow-hidden max-h-[45vh] overflow-y-auto scrollbar-hide"
        >
          <button
            type="button"
            role="option"
            aria-selected={!activeLayerId}
            onClick={() => {
              onSelect(null);
              setOpen(false);
            }}
            className={`w-full px-4 py-3 text-left text-sm transition-colors ${
              !activeLayerId
                ? "bg-accent/10 text-accent"
                : "text-muted hover:bg-bg-alt hover:text-body"
            }`}
          >
            Basemap only (no data layer)
          </button>

          {earthLayers.map((layer) => {
            const isActive = activeLayerId === layer.id;
            const isPreview = previewLayerId === layer.id;
            const available = layer.status === "active";
            return (
              <button
                type="button"
                role="option"
                aria-selected={isActive}
                key={layer.id}
                className={`w-full text-left px-4 py-3 border-t border-default transition-colors ${
                  isActive
                    ? "bg-accent/15 border-l-2 border-l-accent"
                    : isPreview
                      ? "bg-warning/10"
                      : "hover:bg-bg-alt"
                }`}
                onClick={() => {
                  if (available) onSelect(layer);
                  else onPreviewPlanned(layer);
                  setOpen(false);
                }}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className={`text-sm font-medium ${isActive ? "text-accent" : "text-body"}`}>
                    {layer.name}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono shrink-0 ${
                      isActive
                        ? "bg-accent/20 text-accent"
                        : available
                          ? "bg-accent-soft/15 text-accent-soft"
                          : "bg-warning/10 text-warning"
                    }`}
                  >
                    {isActive ? (
                      <Eye className="w-2.5 h-2.5" strokeWidth={1.5} />
                    ) : available ? (
                      <CheckCircle2 className="w-2.5 h-2.5" strokeWidth={1.5} />
                    ) : (
                      <Clock className="w-2.5 h-2.5" strokeWidth={1.5} />
                    )}
                    {isActive ? "On globe" : available ? "Available" : "Planned"}
                  </span>
                </div>
                <p className="text-[11px] text-muted leading-relaxed">{layer.description}</p>
                <p className="text-[10px] font-mono text-muted mt-1.5">
                  {layer.provider} · {layer.units}
                </p>
              </button>
            );
          })}
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="w-full surface-card rounded-xl px-4 py-3 flex items-center justify-between hover:shadow-card transition-all"
      >
        <div className="flex items-center gap-2.5">
          <Layers className="w-4 h-4 text-accent" strokeWidth={1.5} />
          <div className="text-left">
            <p className="text-[10px] uppercase tracking-wider text-muted">Globe layer</p>
            <p className="text-xs font-medium text-body" data-testid="active-layer-name">
              {activeLayer ? activeLayer.name : "Basemap only"}
            </p>
          </div>
        </div>
        <ChevronDown
          className={`w-4 h-4 text-muted transition-transform ${open ? "" : "rotate-180"}`}
          strokeWidth={1.5}
        />
      </button>
    </div>
  );
}
