import { Plus, Minus, MapPin } from "lucide-react";
import type { GlobeCameraState } from "@/types/earth";

type Props = {
  cameraState: GlobeCameraState | null;
  onZoomIn: () => void;
  onZoomOut: () => void;
};

function formatAltitude(height: number): string {
  if (height >= 1_000) {
    return `${Math.round(height / 1_000).toLocaleString()} km`;
  }

  return `${Math.round(height).toLocaleString()} m`;
}

export function GlobeControls({ cameraState, onZoomIn, onZoomOut }: Props) {
  return (
    <div className="absolute right-4 top-20 z-10 flex flex-col items-end gap-2">
      <button
        onClick={onZoomIn}
        aria-label="Zoom in"
        className="w-10 h-10 rounded-full surface-card flex items-center justify-center text-body hover:text-accent hover:shadow-card transition-all"
      >
        <Plus className="w-4.5 h-4.5" strokeWidth={1.5} />
      </button>
      <button
        onClick={onZoomOut}
        aria-label="Zoom out"
        className="w-10 h-10 rounded-full surface-card flex items-center justify-center text-body hover:text-accent hover:shadow-card transition-all"
      >
        <Minus className="w-4.5 h-4.5" strokeWidth={1.5} />
      </button>

      {cameraState && (
        <div className="mt-1 surface-card px-3 py-2.5 rounded-xl">
          <div className="flex items-center gap-1.5 mb-1">
            <MapPin className="w-3 h-3 text-accent" strokeWidth={1.5} />
            <span className="text-[10px] font-mono text-muted uppercase tracking-wider">
              Altitude
            </span>
          </div>
          <p className="text-xs font-mono text-body">{formatAltitude(cameraState.height)}</p>
        </div>
      )}
    </div>
  );
}
