import { useCallback, useMemo, useRef, useState } from "react";
import { ClientOnly, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, AlertTriangle, ArrowLeft, Clock, Globe, Info, X } from "lucide-react";
import EarthGlobe, { type EarthGlobeRef } from "@/components/earth/EarthGlobe";
import { GlobeControls } from "@/components/earth/GlobeControls";
import { BasemapSelector } from "@/components/earth/BasemapSelector";
import { EnvironmentalLayerSelector } from "@/components/earth/EnvironmentalLayerSelector";
import { LayerLegend } from "@/components/earth/LayerLegend";
import { LocationInspector, type PlaceView } from "@/components/earth/LocationInspector";
import { basemapSources, earthLayers } from "@/config/earthLayers";
import { deriveSstView } from "@/lib/earth-inspector";
import { deriveAirTempView } from "@/lib/era5-core";
import { fetchEra5LatestDate, fetchEra5Point } from "@/lib/era5";
import { deriveWindView } from "@/lib/era5-wind-core";
import { derivePrecipView } from "@/lib/era5-precip-core";
import { deriveHumidityView } from "@/lib/era5-rh-core";
import { getHumidityPoint, getLatestHumidityDate } from "@/lib/era5-rh.functions";
import { deriveMoistureFluxView } from "@/lib/era5-ivt-core";
import { getLatestMoistureFluxDate, getMoistureFluxPoint } from "@/lib/era5-ivt.functions";
import { getLatestPrecipDate, getPrecipPoint } from "@/lib/era5-precip.functions";
import { getLatestWindDate, getWindPoint } from "@/lib/era5-wind.functions";
import { fetchPlaceName } from "@/lib/reverse-geocode";
import { getLatestSstTime, getSstPoint } from "@/lib/sst.functions";
import { SST_SOURCES } from "@/lib/sst-core";
import type {
  AirTempOverlayConfig,
  BasemapType,
  GlobeCameraState,
  HumidityOverlayConfig,
  LayerConfig,
  LayerId,
  MoistureFluxOverlayConfig,
  OverlayId,
  OverlayStatus,
  PrecipOverlayConfig,
  SelectedLocation,
  SstOverlayConfig,
  WindOverlayConfig,
} from "@/types/earth";

const SST_ID = "sea-surface-temperature";
const AIR_ID = "air-temperature";
const WIND_ID = "wind-speed";
const PRECIP_ID = "precipitation";
const HUMIDITY_ID = "humidity";
const FLUX_ID = "atmospheric-moisture-flux";

export function EarthExplorer() {
  const globeRef = useRef<EarthGlobeRef>(null);
  const [basemap, setBasemap] = useState<BasemapType>("default");
  const [cameraState, setCameraState] = useState<GlobeCameraState | null>(null);
  // Two independent states: the layer drawn across the globe, and the point being inspected.
  const [activeLayerId, setActiveLayerId] = useState<LayerId | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<SelectedLocation | null>(null);
  const [previewLayerId, setPreviewLayerId] = useState<LayerId | null>(null);
  const [inspectorCollapsed, setInspectorCollapsed] = useState(false);
  const [globeReady, setGlobeReady] = useState(false);
  const [fatalError, setFatalError] = useState<string | null>(null);
  const [overlayStatus, setOverlayStatus] = useState<Record<OverlayId, OverlayStatus>>({
    sst: { state: "off" },
    "air-temperature": { state: "off" },
    "wind-speed": { state: "off" },
    precipitation: { state: "off" },
    humidity: { state: "off" },
    "moisture-flux": { state: "off" },
  });
  const [showInfo, setShowInfo] = useState(false);

  const activeLayer = earthLayers.find((l) => l.id === activeLayerId) ?? null;
  const previewLayer = earthLayers.find((l) => l.id === previewLayerId) ?? null;
  const sstActive = activeLayerId === SST_ID;
  const airActive = activeLayerId === AIR_ID;
  const windActive = activeLayerId === WIND_ID;
  const precipActive = activeLayerId === PRECIP_ID;
  const humidityActive = activeLayerId === HUMIDITY_ID;
  const fluxActive = activeLayerId === FLUX_ID;
  const fetchLatest = useServerFn(getLatestSstTime);
  const fetchPoint = useServerFn(getSstPoint);
  const fetchWindLatest = useServerFn(getLatestWindDate);
  const fetchWindPoint = useServerFn(getWindPoint);
  const fetchPrecipLatest = useServerFn(getLatestPrecipDate);
  const fetchPrecipPoint = useServerFn(getPrecipPoint);
  const fetchHumidityLatest = useServerFn(getLatestHumidityDate);
  const fetchHumidityPoint = useServerFn(getHumidityPoint);
  const fetchFluxLatest = useServerFn(getLatestMoistureFluxDate);
  const fetchFluxPoint = useServerFn(getMoistureFluxPoint);

  const handleOverlayStatus = useCallback((overlay: OverlayId, status: OverlayStatus) => {
    setOverlayStatus((prev) => ({ ...prev, [overlay]: status }));
  }, []);

  // Latest populated OISST date and the NOAA server that confirmed it. Needed whenever SST is
  // drawn or a point is inspected; overlay and point queries always share this date and server.
  const latestQuery = useQuery({
    queryKey: ["sst", "latest-time"],
    queryFn: () => fetchLatest(),
    enabled: sstActive || selectedLocation !== null,
    staleTime: 30 * 60 * 1000,
  });
  const sstDate = latestQuery.data?.time ?? null;
  const sstSource = latestQuery.data?.source ?? null;
  const latestSettled = latestQuery.isSuccess || latestQuery.isError;

  const pointQuery = useQuery({
    queryKey: [
      "sst",
      "point",
      selectedLocation?.latitude.toFixed(4),
      selectedLocation?.longitude.toFixed(4),
      sstDate,
      sstSource,
    ],
    queryFn: () =>
      fetchPoint({
        data: {
          latitude: selectedLocation!.latitude,
          longitude: selectedLocation!.longitude,
          time: sstDate!,
          source: sstSource!,
        },
      }),
    enabled: selectedLocation !== null && sstDate !== null && sstSource !== null,
    staleTime: 30 * 60 * 1000,
  });

  const placeQuery = useQuery({
    queryKey: [
      "place-name",
      selectedLocation?.latitude.toFixed(3),
      selectedLocation?.longitude.toFixed(3),
    ],
    queryFn: ({ signal }) =>
      fetchPlaceName(selectedLocation!.latitude, selectedLocation!.longitude, signal),
    enabled: selectedLocation !== null,
    staleTime: Infinity,
    retry: 1,
  });
  const placeView: PlaceView = placeQuery.data
    ? { state: "done", place: placeQuery.data }
    : placeQuery.isError
      ? { state: "error" }
      : { state: "loading" };

  const sstView = deriveSstView({
    hasLocation: selectedLocation !== null,
    latest: {
      settled: latestSettled,
      time: sstDate,
      source: sstSource,
      error: latestQuery.data?.error,
    },
    point: { data: pointQuery.data, isError: pointQuery.isError },
  });

  // ERA5 2 m air temperature: newest complete day, shared by the map and the point values.
  const airLatestQuery = useQuery({
    queryKey: ["era5", "t2m", "latest-day"],
    queryFn: ({ signal }) => fetchEra5LatestDate(signal),
    enabled: airActive || selectedLocation !== null,
    staleTime: 30 * 60 * 1000,
  });
  const airDate = airLatestQuery.data?.date ?? null;
  const airLatestSettled = airLatestQuery.isSuccess || airLatestQuery.isError;

  const airPointQuery = useQuery({
    queryKey: [
      "era5",
      "t2m",
      "point",
      selectedLocation?.latitude.toFixed(4),
      selectedLocation?.longitude.toFixed(4),
      airDate,
    ],
    queryFn: ({ signal }) =>
      fetchEra5Point(selectedLocation!.latitude, selectedLocation!.longitude, airDate!, signal),
    enabled: selectedLocation !== null && airDate !== null,
    staleTime: 30 * 60 * 1000,
    retry: 1,
  });

  const airView = deriveAirTempView({
    hasLocation: selectedLocation !== null,
    latest: { settled: airLatestSettled, date: airDate, error: airLatestQuery.data?.error },
    point: {
      data: airPointQuery.data,
      isError: airPointQuery.isError,
      error: airPointQuery.error,
    },
  });

  // ERA5 10 m wind: newest day with both u and v at 12:00 UTC, shared by map and points.
  const windLatestQuery = useQuery({
    queryKey: ["era5", "wind", "latest-day"],
    queryFn: () => fetchWindLatest(),
    enabled: windActive || selectedLocation !== null,
    staleTime: 30 * 60 * 1000,
  });
  const windDate = windLatestQuery.data?.date ?? null;
  const windFinalStop = windLatestQuery.data?.finalStop ?? null;
  const windLatestSettled = windLatestQuery.isSuccess || windLatestQuery.isError;

  const windPointQuery = useQuery({
    queryKey: [
      "era5",
      "wind",
      "point",
      selectedLocation?.latitude.toFixed(4),
      selectedLocation?.longitude.toFixed(4),
      windDate,
    ],
    queryFn: () =>
      fetchWindPoint({
        data: {
          latitude: selectedLocation!.latitude,
          longitude: selectedLocation!.longitude,
          date: windDate!,
          finalStop: windFinalStop,
        },
      }),
    enabled: selectedLocation !== null && windDate !== null,
    staleTime: 30 * 60 * 1000,
    retry: 1,
  });

  const windView = deriveWindView({
    hasLocation: selectedLocation !== null,
    latest: { settled: windLatestSettled, date: windDate, error: windLatestQuery.data?.error },
    point: { data: windPointQuery.data, isError: windPointQuery.isError },
  });

  // ERA5 precipitation: newest complete UTC day, shared by the map and the point totals.
  const precipLatestQuery = useQuery({
    queryKey: ["era5", "precip", "latest-day"],
    queryFn: () => fetchPrecipLatest(),
    enabled: precipActive || selectedLocation !== null,
    staleTime: 30 * 60 * 1000,
  });
  const precipDate = precipLatestQuery.data?.date ?? null;
  const precipFinalStop = precipLatestQuery.data?.finalStop ?? null;
  const precipLatestSettled = precipLatestQuery.isSuccess || precipLatestQuery.isError;

  const precipPointQuery = useQuery({
    queryKey: [
      "era5",
      "precip",
      "point",
      selectedLocation?.latitude.toFixed(4),
      selectedLocation?.longitude.toFixed(4),
      precipDate,
    ],
    queryFn: () =>
      fetchPrecipPoint({
        data: {
          latitude: selectedLocation!.latitude,
          longitude: selectedLocation!.longitude,
          date: precipDate!,
          finalStop: precipFinalStop,
        },
      }),
    enabled: selectedLocation !== null && precipDate !== null,
    staleTime: 30 * 60 * 1000,
    retry: 1,
  });

  const precipView = derivePrecipView({
    hasLocation: selectedLocation !== null,
    latest: {
      settled: precipLatestSettled,
      date: precipDate,
      error: precipLatestQuery.data?.error,
    },
    point: { data: precipPointQuery.data, isError: precipPointQuery.isError },
  });

  // ERA5 2 m relative humidity: newest day with both T and Td at 12:00 UTC, shared by map and points.
  const humidityLatestQuery = useQuery({
    queryKey: ["era5", "rh", "latest-day"],
    queryFn: () => fetchHumidityLatest(),
    enabled: humidityActive || selectedLocation !== null,
    staleTime: 30 * 60 * 1000,
  });
  const humidityDate = humidityLatestQuery.data?.date ?? null;
  const humidityFinalStop = humidityLatestQuery.data?.finalStop ?? null;
  const humidityLatestSettled = humidityLatestQuery.isSuccess || humidityLatestQuery.isError;

  const humidityPointQuery = useQuery({
    queryKey: [
      "era5",
      "rh",
      "point",
      selectedLocation?.latitude.toFixed(4),
      selectedLocation?.longitude.toFixed(4),
      humidityDate,
    ],
    queryFn: () =>
      fetchHumidityPoint({
        data: {
          latitude: selectedLocation!.latitude,
          longitude: selectedLocation!.longitude,
          date: humidityDate!,
          finalStop: humidityFinalStop,
        },
      }),
    enabled: selectedLocation !== null && humidityDate !== null,
    staleTime: 30 * 60 * 1000,
    retry: 1,
  });

  const humidityView = deriveHumidityView({
    hasLocation: selectedLocation !== null,
    latest: {
      settled: humidityLatestSettled,
      date: humidityDate,
      error: humidityLatestQuery.data?.error,
    },
    point: { data: humidityPointQuery.data, isError: humidityPointQuery.isError },
  });

  // ERA5 moisture flux: newest day with both viwve and viwvn at 12:00 UTC, shared by map and points.
  const fluxLatestQuery = useQuery({
    queryKey: ["era5", "ivt", "latest-day"],
    queryFn: () => fetchFluxLatest(),
    enabled: fluxActive || selectedLocation !== null,
    staleTime: 30 * 60 * 1000,
  });
  const fluxDate = fluxLatestQuery.data?.date ?? null;
  const fluxFinalStop = fluxLatestQuery.data?.finalStop ?? null;
  const fluxLatestSettled = fluxLatestQuery.isSuccess || fluxLatestQuery.isError;

  const fluxPointQuery = useQuery({
    queryKey: [
      "era5",
      "ivt",
      "point",
      selectedLocation?.latitude.toFixed(4),
      selectedLocation?.longitude.toFixed(4),
      fluxDate,
    ],
    queryFn: () =>
      fetchFluxPoint({
        data: {
          latitude: selectedLocation!.latitude,
          longitude: selectedLocation!.longitude,
          date: fluxDate!,
          finalStop: fluxFinalStop,
        },
      }),
    enabled: selectedLocation !== null && fluxDate !== null,
    staleTime: 30 * 60 * 1000,
    retry: 1,
  });

  const fluxView = deriveMoistureFluxView({
    hasLocation: selectedLocation !== null,
    latest: { settled: fluxLatestSettled, date: fluxDate, error: fluxLatestQuery.data?.error },
    point: { data: fluxPointQuery.data, isError: fluxPointQuery.isError },
  });

  // Wait for the date before drawing tiles so the overlay shows the same day as the point values.
  const sstOverlay = useMemo<SstOverlayConfig>(
    () => ({ enabled: sstActive && latestSettled, time: sstDate, source: sstSource }),
    [sstActive, latestSettled, sstDate, sstSource],
  );
  const airTempOverlay = useMemo<AirTempOverlayConfig>(
    () => ({ enabled: airActive && airLatestSettled, date: airDate }),
    [airActive, airLatestSettled, airDate],
  );
  const windOverlay = useMemo<WindOverlayConfig>(
    () => ({ enabled: windActive && windLatestSettled, date: windDate }),
    [windActive, windLatestSettled, windDate],
  );
  const precipOverlay = useMemo<PrecipOverlayConfig>(
    () => ({ enabled: precipActive && precipLatestSettled, date: precipDate }),
    [precipActive, precipLatestSettled, precipDate],
  );
  const humidityOverlay = useMemo<HumidityOverlayConfig>(
    () => ({ enabled: humidityActive && humidityLatestSettled, date: humidityDate }),
    [humidityActive, humidityLatestSettled, humidityDate],
  );
  const fluxOverlay = useMemo<MoistureFluxOverlayConfig>(
    () => ({ enabled: fluxActive && fluxLatestSettled, date: fluxDate }),
    [fluxActive, fluxLatestSettled, fluxDate],
  );
  // Legend status and date of the drawn layer; "loading" until its verified date is known.
  const legendSource: { overlay: OverlayId; settled: boolean; date: string | null } | null =
    sstActive
      ? { overlay: "sst", settled: latestSettled, date: sstDate }
      : airActive
        ? { overlay: "air-temperature", settled: airLatestSettled, date: airDate }
        : windActive
          ? { overlay: "wind-speed", settled: windLatestSettled, date: windDate }
          : precipActive
            ? { overlay: "precipitation", settled: precipLatestSettled, date: precipDate }
            : humidityActive
              ? { overlay: "humidity", settled: humidityLatestSettled, date: humidityDate }
              : fluxActive
                ? { overlay: "moisture-flux", settled: fluxLatestSettled, date: fluxDate }
                : null;
  const legendStatus: OverlayStatus | undefined = legendSource
    ? legendSource.settled
      ? overlayStatus[legendSource.overlay]
      : { state: "loading" }
    : undefined;
  const legendDate = legendSource?.date ?? null;

  const handleLocationSelect = useCallback((location: SelectedLocation) => {
    setSelectedLocation(location);
    setInspectorCollapsed(false);
  }, []);

  const handleLayerSelect = useCallback((layer: LayerConfig | null) => {
    // Only implemented layers are drawn; the selected location is left untouched.
    if (layer && layer.status !== "active") return;
    setActiveLayerId(layer?.id ?? null);
    setPreviewLayerId(null);
  }, []);

  const clearSelection = () => {
    globeRef.current?.clearSelection();
    setSelectedLocation(null);
  };

  return (
    <div className="fixed inset-0 bg-slate-900 z-40">
      <ClientOnly fallback={null}>
        <EarthGlobe
          ref={globeRef}
          basemap={basemap}
          sstOverlay={sstOverlay}
          airTempOverlay={airTempOverlay}
          windOverlay={windOverlay}
          precipOverlay={precipOverlay}
          humidityOverlay={humidityOverlay}
          fluxOverlay={fluxOverlay}
          onCameraChange={setCameraState}
          onLocationSelect={handleLocationSelect}
          onReady={() => setGlobeReady(true)}
          onFatalError={setFatalError}
          onOverlayStatus={handleOverlayStatus}
        />
      </ClientOnly>

      <Link
        to="/"
        className="absolute left-4 top-20 z-20 inline-flex items-center gap-2 px-3.5 py-2 rounded-full surface-card text-sm text-muted hover:text-body transition-all"
      >
        <ArrowLeft className="w-4 h-4" strokeWidth={1.5} />
        Back
      </Link>

      <div className="absolute left-1/2 -translate-x-1/2 top-18 z-10 surface-card pl-4 pr-1.5 py-1.5 rounded-full flex items-center gap-2">
        <Globe className="w-4 h-4 text-accent" strokeWidth={1.5} />
        <h1 className="text-xs font-medium text-body">Earth Explorer</h1>
        <span className="text-[10px] font-mono text-muted hidden md:inline">
          Living Earth Initiative
        </span>
        <button
          type="button"
          onClick={() => setShowInfo((s) => !s)}
          aria-label="About Earth Explorer"
          className="w-7 h-7 rounded-full flex items-center justify-center text-muted hover:text-accent hover:bg-bg-alt transition-all"
        >
          <Info className="w-4 h-4" strokeWidth={1.5} />
        </button>
      </div>

      <BasemapSelector basemap={basemap} onChange={setBasemap} />
      <GlobeControls
        cameraState={cameraState}
        onZoomIn={() => globeRef.current?.zoomIn()}
        onZoomOut={() => globeRef.current?.zoomOut()}
      />

      {/* Left column: planned-layer notice, legend of the drawn layer, layer selector. */}
      <div className="absolute left-4 bottom-4 z-10 w-72 max-w-[calc(100vw-2rem)] max-h-[calc(100%-11rem)] overflow-y-auto scrollbar-hide flex flex-col gap-2">
        {previewLayer && (
          <div
            role="status"
            data-testid="planned-layer-notice"
            className="surface-card rounded-xl p-4 border border-warning/30"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-1.5 text-warning">
                <Clock className="w-3.5 h-3.5" strokeWidth={1.5} />
                <p className="text-[10px] font-mono uppercase tracking-wider">
                  Planned — not yet available
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewLayerId(null)}
                aria-label="Dismiss planned layer notice"
                className="text-muted hover:text-body transition-colors"
              >
                <X className="w-3.5 h-3.5" strokeWidth={1.5} />
              </button>
            </div>
            <h4 className="text-sm font-medium text-body mt-2">{previewLayer.name}</h4>
            <p className="text-[11px] text-muted leading-relaxed mt-1">
              {previewLayer.description}
            </p>
            <dl className="mt-2 space-y-1 text-[10px] font-mono">
              <div className="flex justify-between gap-3">
                <dt className="text-muted">Variable</dt>
                <dd className="text-body text-right">{previewLayer.variable}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted">Units</dt>
                <dd className="text-body text-right">{previewLayer.units}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted">Intended dataset</dt>
                <dd className="text-body text-right">{previewLayer.provider}</dd>
              </div>
            </dl>
            <p className="text-[10px] text-muted mt-2 pt-2 border-t border-default leading-relaxed">
              No data is drawn for this layer. The globe keeps showing{" "}
              <span className="text-body">
                {activeLayer ? activeLayer.name : "the basemap only"}
              </span>
              .
            </p>
          </div>
        )}

        {activeLayer && (
          <LayerLegend
            layer={activeLayer}
            observationDate={legendDate}
            overlayStatus={legendStatus}
          />
        )}

        <EnvironmentalLayerSelector
          activeLayerId={activeLayerId}
          previewLayerId={previewLayerId}
          onSelect={handleLayerSelect}
          onPreviewPlanned={(layer) => setPreviewLayerId(layer.id)}
        />
      </div>

      {!selectedLocation && globeReady && (
        <p className="hidden sm:block absolute left-1/2 -translate-x-1/2 top-30 z-10 surface-card rounded-full px-3 py-1.5 text-[11px] text-muted pointer-events-none">
          Click anywhere on the globe to inspect that location
        </p>
      )}

      {selectedLocation && (
        <LocationInspector
          location={selectedLocation}
          place={placeView}
          activeLayerId={activeLayerId}
          sst={sstView}
          sstDate={sstDate}
          sstSourceLabel={sstSource ? SST_SOURCES[sstSource].label : null}
          air={airView}
          airDate={airDate}
          wind={windView}
          windDate={windDate}
          precip={precipView}
          precipDate={precipDate}
          humidity={humidityView}
          humidityDate={humidityDate}
          flux={fluxView}
          fluxDate={fluxDate}
          collapsed={inspectorCollapsed}
          onToggleCollapsed={() => setInspectorCollapsed((c) => !c)}
          onClear={clearSelection}
        />
      )}

      {showInfo && (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-6"
          onClick={() => setShowInfo(false)}
        >
          <div
            className="surface-card rounded-3xl p-8 max-w-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="font-serif text-xl text-body mb-3">About Earth Explorer</h2>
            <p className="text-sm text-muted leading-relaxed mb-4">
              Earth Explorer is the interactive global exploration interface for the Living Earth
              research initiative. It uses CesiumJS to render a 3D globe with street and satellite
              basemaps.
            </p>
            <p className="text-sm text-muted leading-relaxed mb-4">
              Click any point to open the location inspector with every measurement available there.
              The layer selector only changes what is drawn across the globe. Six scientific layers
              are active: NOAA OISST V2.1 sea-surface temperature, ERA5 2 m air temperature, ERA5 10
              m wind speed, ERA5 daily total precipitation, ERA5 2 m relative humidity and ERA5
              vertically integrated atmospheric moisture flux.
            </p>
            <p className="text-xs font-mono text-muted">
              Basemaps: {basemapSources.default.credit} (
              {basemapSources.default.label.toLowerCase()}) · {basemapSources.satellite.credit} (
              {basemapSources.satellite.label.toLowerCase()}). SST values and map tiles: NOAA
              CoastWatch ERDDAP, or NOAA NCEI ERDDAP when CoastWatch cannot be reached. 2 m air
              temperature: ERA5, contains modified Copernicus Climate Change Service information;
              map from C3S/ECMWF Climate Pulse, point values via Open-Meteo.com (CC BY 4.0). 10 m
              wind speed, daily precipitation and relative humidity: ERA5 u10/v10, tp, 2t and 2d
              read from ARCO-ERA5 (Google Cloud public dataset). Place names: © OpenStreetMap
              contributors (Nominatim).
            </p>
            <button
              onClick={() => setShowInfo(false)}
              className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent text-on-accent text-sm font-medium hover:opacity-90 transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {!globeReady && !fatalError && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-900">
          <Loader2 className="w-8 h-8 text-accent animate-spin mb-4" strokeWidth={1.5} />
          <p className="text-sm text-muted">Initializing 3D globe…</p>
        </div>
      )}

      {fatalError && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-900 p-6">
          <AlertTriangle className="w-8 h-8 text-warning mb-4" strokeWidth={1.5} />
          <h2 className="font-serif text-lg text-body mb-2 text-center">
            Unable to initialize the 3D globe
          </h2>
          <p className="text-sm text-muted text-center max-w-sm mb-6">{fatalError}</p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent text-on-accent text-sm font-medium hover:opacity-90 transition-all"
          >
            <ArrowLeft className="w-4 h-4" strokeWidth={1.5} />
            Back to Home
          </Link>
        </div>
      )}
    </div>
  );
}
