import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import type * as CesiumNS from "cesium";
import { loadCesium, type CesiumModule } from "@/lib/cesium-loader";
import { SST_SOURCES, SST_TILE_MAX_LEVEL, SST_TILE_SIZE } from "@/lib/sst-core";
import { T2M_MAP_EXTENT } from "@/lib/era5-core";
import { RH_HOUR_UTC } from "@/lib/era5-rh-core";
import {
  WIND_HOUR_UTC,
  WIND_MAP_EXTENT,
  WIND_MAP_HEIGHT,
  WIND_MAP_WIDTH,
} from "@/lib/era5-wind-core";
import {
  AIR_TEMP_OVERLAY_ALPHA,
  FLUX_OVERLAY_ALPHA,
  HUMIDITY_OVERLAY_ALPHA,
  PRECIP_OVERLAY_ALPHA,
  basemapSources,
  GLOBE_MARKER_COLOR,
  SST_OVERLAY_ALPHA,
  WIND_OVERLAY_ALPHA,
} from "@/config/earthLayers";
import type {
  AirTempOverlayConfig,
  BasemapType,
  GlobeCameraState,
  HumidityOverlayConfig,
  MoistureFluxOverlayConfig,
  OverlayId,
  OverlayStatus,
  PrecipOverlayConfig,
  SelectedLocation,
  SstOverlayConfig,
  WindOverlayConfig,
} from "@/types/earth";

export type EarthGlobeRef = {
  zoomIn: () => void;
  zoomOut: () => void;
  flyTo: (lon: number, lat: number, height?: number) => void;
  clearSelection: () => void;
};

type Props = {
  basemap: BasemapType;
  sstOverlay: SstOverlayConfig;
  airTempOverlay: AirTempOverlayConfig;
  windOverlay: WindOverlayConfig;
  precipOverlay: PrecipOverlayConfig;
  humidityOverlay: HumidityOverlayConfig;
  fluxOverlay: MoistureFluxOverlayConfig;
  onCameraChange?: (state: GlobeCameraState) => void;
  onLocationSelect?: (location: SelectedLocation) => void;
  onReady?: () => void;
  /** Globe could not start at all (library download or WebGL failure). */
  onFatalError?: (message: string) => void;
  onOverlayStatus?: (overlay: OverlayId, status: OverlayStatus) => void;
};

type Runtime = {
  Cesium: CesiumModule;
  viewer: CesiumNS.Viewer;
  baseLayer: CesiumNS.ImageryLayer | null;
  sstLayer: CesiumNS.ImageryLayer | null;
  airLayer: CesiumNS.ImageryLayer | null;
  windLayer: CesiumNS.ImageryLayer | null;
  precipLayer: CesiumNS.ImageryLayer | null;
  humidityLayer: CesiumNS.ImageryLayer | null;
  fluxLayer: CesiumNS.ImageryLayer | null;
  marker: CesiumNS.Entity | null;
};

/** Pixel size of the official Climate Pulse map image. */
const T2M_MAP_WIDTH = 3000;
const T2M_MAP_HEIGHT = 1500;

function createBasemapProvider(
  Cesium: CesiumModule,
  basemap: BasemapType,
): CesiumNS.ImageryProvider {
  const source = basemapSources[basemap];
  if (source.kind === "osm") {
    return new Cesium.OpenStreetMapImageryProvider({
      url: source.url,
      maximumLevel: source.maximumLevel,
    });
  }
  return new Cesium.UrlTemplateImageryProvider({
    url: source.url,
    maximumLevel: source.maximumLevel,
    credit: new Cesium.Credit(source.credit),
  });
}

/* A missing overlay prop (e.g. during a partial hot update) means "off", never a crash. */
const OFF_SST: SstOverlayConfig = { enabled: false, time: null, source: null };
const OFF_DATED = { enabled: false, date: null } as const;

const EarthGlobe = forwardRef<EarthGlobeRef, Props>(function EarthGlobe(
  {
    basemap,
    sstOverlay = OFF_SST,
    airTempOverlay = OFF_DATED,
    windOverlay = OFF_DATED,
    precipOverlay = OFF_DATED,
    humidityOverlay = OFF_DATED,
    fluxOverlay = OFF_DATED,
    onCameraChange,
    onLocationSelect,
    onReady,
    onFatalError,
    onOverlayStatus,
  },
  ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const runtimeRef = useRef<Runtime | null>(null);
  const callbacks = useRef({
    onCameraChange,
    onLocationSelect,
    onReady,
    onFatalError,
    onOverlayStatus,
  });
  callbacks.current = { onCameraChange, onLocationSelect, onReady, onFatalError, onOverlayStatus };

  // Latest desired state, read when the viewer finishes loading.
  const desired = useRef({
    basemap,
    sstOverlay,
    airTempOverlay,
    windOverlay,
    precipOverlay,
    humidityOverlay,
    fluxOverlay,
  });
  desired.current = {
    basemap,
    sstOverlay,
    airTempOverlay,
    windOverlay,
    precipOverlay,
    humidityOverlay,
    fluxOverlay,
  };

  const report = (overlay: OverlayId, status: OverlayStatus) =>
    callbacks.current.onOverlayStatus?.(overlay, status);

  useImperativeHandle(ref, () => ({
    zoomIn: () => {
      const rt = runtimeRef.current;
      if (rt) rt.viewer.camera.zoomIn(rt.viewer.camera.positionCartographic.height * 0.3);
    },
    zoomOut: () => {
      const rt = runtimeRef.current;
      if (rt) rt.viewer.camera.zoomOut(rt.viewer.camera.positionCartographic.height * 0.4);
    },
    flyTo: (lon, lat, height = 500_000) => {
      const rt = runtimeRef.current;
      if (!rt) return;
      rt.viewer.camera.flyTo({
        destination: rt.Cesium.Cartesian3.fromDegrees(lon, lat, height),
        duration: 1.5,
      });
    },
    clearSelection: () => {
      const rt = runtimeRef.current;
      if (rt?.marker) {
        rt.viewer.entities.remove(rt.marker);
        rt.marker = null;
      }
    },
  }));

  const applyBasemap = (rt: Runtime, bm: BasemapType) => {
    if (rt.baseLayer) {
      rt.viewer.imageryLayers.remove(rt.baseLayer, true);
      rt.baseLayer = null;
    }
    const layer = new rt.Cesium.ImageryLayer(createBasemapProvider(rt.Cesium, bm));
    // Index 0 keeps the basemap underneath the data overlays.
    rt.viewer.imageryLayers.add(layer, 0);
    rt.baseLayer = layer;
  };

  const applySstOverlay = (rt: Runtime, overlay: SstOverlayConfig) => {
    if (rt.sstLayer) {
      rt.viewer.imageryLayers.remove(rt.sstLayer, true);
      rt.sstLayer = null;
    }
    if (!overlay.enabled) {
      report("sst", { state: "off" });
      return;
    }
    if (!overlay.time || !overlay.source) {
      // Never draw an undated map: it could not be matched to the point values.
      report("sst", {
        state: "error",
        message: "NOAA's latest observation date is unavailable, so the SST map is not shown.",
      });
      return;
    }

    const query = `?time=${encodeURIComponent(overlay.time)}&source=${overlay.source}`;
    const provider = new rt.Cesium.UrlTemplateImageryProvider({
      url: `/api/sst-tiles/{z}/{x}/{y}${query}`,
      tilingScheme: new rt.Cesium.GeographicTilingScheme(),
      maximumLevel: SST_TILE_MAX_LEVEL,
      tileWidth: SST_TILE_SIZE,
      tileHeight: SST_TILE_SIZE,
      hasAlphaChannel: true,
      credit: new rt.Cesium.Credit(`SST: NOAA OISST V2.1 via ${SST_SOURCES[overlay.source].label}`),
    });
    let reported = false;
    provider.errorEvent.addEventListener((err: CesiumNS.TileProviderError) => {
      // NOAA is intermittently overloaded: let Cesium retry a tile a couple of times first.
      if (err.timesRetried < 2) {
        err.retry = true;
        return;
      }
      if (reported) return;
      reported = true;
      console.warn("SST tile failed", err.message);
      report("sst", {
        state: "error",
        message:
          "Some NOAA SST map tiles could not be loaded. Point values may still be available.",
      });
    });

    const layer = new rt.Cesium.ImageryLayer(provider, { alpha: SST_OVERLAY_ALPHA });
    rt.viewer.imageryLayers.add(layer);
    rt.sstLayer = layer;
    report("sst", { state: "loading" });
  };

  const applyAirTempOverlay = (rt: Runtime, overlay: AirTempOverlayConfig) => {
    if (rt.airLayer) {
      rt.viewer.imageryLayers.remove(rt.airLayer, true);
      rt.airLayer = null;
    }
    if (!overlay.enabled) {
      report("air-temperature", { state: "off" });
      return;
    }
    if (!overlay.date) {
      report("air-temperature", {
        state: "error",
        message: "The latest ERA5 day is unavailable, so the air-temperature map is not shown.",
      });
      return;
    }

    const [west, south, east, north] = T2M_MAP_EXTENT;
    const provider = new rt.Cesium.SingleTileImageryProvider({
      url: `/api/era5-t2m-map/${encodeURIComponent(overlay.date)}`,
      rectangle: rt.Cesium.Rectangle.fromDegrees(west, south, east, north),
      tileWidth: T2M_MAP_WIDTH,
      tileHeight: T2M_MAP_HEIGHT,
      credit: new rt.Cesium.Credit(
        "2 m air temperature: ERA5, Copernicus Climate Change Service / ECMWF (Climate Pulse)",
      ),
    });
    let reported = false;
    provider.errorEvent.addEventListener((err: CesiumNS.TileProviderError) => {
      if (err.timesRetried < 2) {
        err.retry = true;
        return;
      }
      if (reported) return;
      reported = true;
      console.warn("ERA5 map failed", err.message);
      report("air-temperature", {
        state: "error",
        message:
          "The ERA5 air-temperature map could not be loaded. Point values may still be available.",
      });
    });

    const layer = new rt.Cesium.ImageryLayer(provider, {
      alpha: AIR_TEMP_OVERLAY_ALPHA,
      // Keep the discrete 2 °C colour steps instead of blending neighbouring classes.
      magnificationFilter: rt.Cesium.TextureMagnificationFilter.NEAREST,
    });
    rt.viewer.imageryLayers.add(layer);
    rt.airLayer = layer;
    report("air-temperature", { state: "loading" });
  };

  const applyWindOverlay = (rt: Runtime, overlay: WindOverlayConfig) => {
    if (rt.windLayer) {
      rt.viewer.imageryLayers.remove(rt.windLayer, true);
      rt.windLayer = null;
    }
    if (!overlay.enabled) {
      report("wind-speed", { state: "off" });
      return;
    }
    if (!overlay.date) {
      report("wind-speed", {
        state: "error",
        message: "The latest ERA5 wind hour is unavailable, so the wind map is not shown.",
      });
      return;
    }

    const [west, south, east, north] = WIND_MAP_EXTENT;
    const provider = new rt.Cesium.SingleTileImageryProvider({
      url: `/api/era5-wind-map/${encodeURIComponent(overlay.date)}`,
      rectangle: rt.Cesium.Rectangle.fromDegrees(west, south, east, north),
      tileWidth: WIND_MAP_WIDTH,
      tileHeight: WIND_MAP_HEIGHT,
      credit: new rt.Cesium.Credit(
        `10 m wind speed: ERA5 ${WIND_HOUR_UTC}:00 UTC, Copernicus Climate Change Service / ECMWF (ARCO-ERA5)`,
      ),
    });
    let reported = false;
    provider.errorEvent.addEventListener((err: CesiumNS.TileProviderError) => {
      if (err.timesRetried < 2) {
        err.retry = true;
        return;
      }
      if (reported) return;
      reported = true;
      console.warn("ERA5 wind map failed", err.message);
      report("wind-speed", {
        state: "error",
        message: "The ERA5 wind map could not be loaded. Point values may still be available.",
      });
    });

    const layer = new rt.Cesium.ImageryLayer(provider, {
      alpha: WIND_OVERLAY_ALPHA,
      // Keep the discrete Beaufort classes and the 0.25° cells sharp.
      magnificationFilter: rt.Cesium.TextureMagnificationFilter.NEAREST,
    });
    rt.viewer.imageryLayers.add(layer);
    rt.windLayer = layer;
    report("wind-speed", { state: "loading" });
  };

  const applyPrecipOverlay = (rt: Runtime, overlay: PrecipOverlayConfig) => {
    if (rt.precipLayer) {
      rt.viewer.imageryLayers.remove(rt.precipLayer, true);
      rt.precipLayer = null;
    }
    if (!overlay.enabled) {
      report("precipitation", { state: "off" });
      return;
    }
    if (!overlay.date) {
      report("precipitation", {
        state: "error",
        message:
          "No complete ERA5 precipitation day could be confirmed, so the precipitation map is not shown.",
      });
      return;
    }

    const [west, south, east, north] = WIND_MAP_EXTENT;
    const provider = new rt.Cesium.SingleTileImageryProvider({
      url: `/api/era5-precip-map/${encodeURIComponent(overlay.date)}`,
      rectangle: rt.Cesium.Rectangle.fromDegrees(west, south, east, north),
      tileWidth: WIND_MAP_WIDTH,
      tileHeight: WIND_MAP_HEIGHT,
      credit: new rt.Cesium.Credit(
        "Daily total precipitation: ERA5, Copernicus Climate Change Service / ECMWF (ARCO-ERA5)",
      ),
    });
    let reported = false;
    provider.errorEvent.addEventListener((err: CesiumNS.TileProviderError) => {
      if (err.timesRetried < 2) {
        err.retry = true;
        return;
      }
      if (reported) return;
      reported = true;
      console.warn("ERA5 precipitation map failed", err.message);
      report("precipitation", {
        state: "error",
        message:
          "The ERA5 precipitation map could not be loaded. Point values may still be available.",
      });
    });

    const layer = new rt.Cesium.ImageryLayer(provider, {
      alpha: PRECIP_OVERLAY_ALPHA,
      magnificationFilter: rt.Cesium.TextureMagnificationFilter.NEAREST,
    });
    rt.viewer.imageryLayers.add(layer);
    rt.precipLayer = layer;
    report("precipitation", { state: "loading" });
  };

  const applyHumidityOverlay = (rt: Runtime, overlay: HumidityOverlayConfig) => {
    if (rt.humidityLayer) {
      rt.viewer.imageryLayers.remove(rt.humidityLayer, true);
      rt.humidityLayer = null;
    }
    if (!overlay.enabled) {
      report("humidity", { state: "off" });
      return;
    }
    if (!overlay.date) {
      report("humidity", {
        state: "error",
        message: "The latest ERA5 humidity hour is unavailable, so the humidity map is not shown.",
      });
      return;
    }

    const [west, south, east, north] = WIND_MAP_EXTENT;
    const provider = new rt.Cesium.SingleTileImageryProvider({
      url: `/api/era5-rh-map/${encodeURIComponent(overlay.date)}`,
      rectangle: rt.Cesium.Rectangle.fromDegrees(west, south, east, north),
      tileWidth: WIND_MAP_WIDTH,
      tileHeight: WIND_MAP_HEIGHT,
      credit: new rt.Cesium.Credit(
        `2 m relative humidity: derived from ERA5 2 m temperature and dew point, ${RH_HOUR_UTC}:00 UTC, Copernicus Climate Change Service / ECMWF (ARCO-ERA5)`,
      ),
    });
    let reported = false;
    provider.errorEvent.addEventListener((err: CesiumNS.TileProviderError) => {
      if (err.timesRetried < 2) {
        err.retry = true;
        return;
      }
      if (reported) return;
      reported = true;
      console.warn("ERA5 humidity map failed", err.message);
      report("humidity", {
        state: "error",
        message: "The ERA5 humidity map could not be loaded. Point values may still be available.",
      });
    });

    const layer = new rt.Cesium.ImageryLayer(provider, {
      alpha: HUMIDITY_OVERLAY_ALPHA,
      magnificationFilter: rt.Cesium.TextureMagnificationFilter.NEAREST,
    });
    rt.viewer.imageryLayers.add(layer);
    rt.humidityLayer = layer;
    report("humidity", { state: "loading" });
  };

  const applyFluxOverlay = (rt: Runtime, overlay: MoistureFluxOverlayConfig) => {
    if (rt.fluxLayer) {
      rt.viewer.imageryLayers.remove(rt.fluxLayer, true);
      rt.fluxLayer = null;
    }
    if (!overlay.enabled) {
      report("moisture-flux", { state: "off" });
      return;
    }
    if (!overlay.date) {
      report("moisture-flux", {
        state: "error",
        message:
          "The latest ERA5 moisture-flux hour is unavailable, so the moisture-flux map is not shown.",
      });
      return;
    }

    const [west, south, east, north] = WIND_MAP_EXTENT;
    const provider = new rt.Cesium.SingleTileImageryProvider({
      url: `/api/era5-ivt-map/${encodeURIComponent(overlay.date)}`,
      rectangle: rt.Cesium.Rectangle.fromDegrees(west, south, east, north),
      tileWidth: WIND_MAP_WIDTH,
      tileHeight: WIND_MAP_HEIGHT,
      credit: new rt.Cesium.Credit(
        `Moisture flux: ERA5 viwve/viwvn ${RH_HOUR_UTC}:00 UTC, Copernicus Climate Change Service / ECMWF (ARCO-ERA5)`,
      ),
    });
    let reported = false;
    provider.errorEvent.addEventListener((err: CesiumNS.TileProviderError) => {
      if (err.timesRetried < 2) {
        err.retry = true;
        return;
      }
      if (reported) return;
      reported = true;
      console.warn("ERA5 moisture flux map failed", err.message);
      report("moisture-flux", {
        state: "error",
        message:
          "The ERA5 moisture-flux map could not be loaded. Point values may still be available.",
      });
    });

    const layer = new rt.Cesium.ImageryLayer(provider, {
      alpha: FLUX_OVERLAY_ALPHA,
      magnificationFilter: rt.Cesium.TextureMagnificationFilter.NEAREST,
    });
    rt.viewer.imageryLayers.add(layer);
    rt.fluxLayer = layer;
    report("moisture-flux", { state: "loading" });
  };

  // Create the viewer once; tear it down in a safe order.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let cancelled = false;
    const disposers: Array<() => void> = [];

    loadCesium()
      .then((Cesium) => {
        if (cancelled) return;
        let viewer: CesiumNS.Viewer;
        try {
          viewer = new Cesium.Viewer(container, {
            baseLayer: false,
            baseLayerPicker: false,
            geocoder: false,
            homeButton: false,
            sceneModePicker: false,
            navigationHelpButton: false,
            animation: false,
            timeline: false,
            fullscreenButton: false,
            infoBox: false,
            selectionIndicator: false,
          });
        } catch (err) {
          callbacks.current.onFatalError?.(
            err instanceof Error
              ? err.message
              : "Failed to initialise the 3D globe (WebGL may be unavailable).",
          );
          return;
        }

        viewer.scene.globe.enableLighting = true;
        viewer.scene.globe.depthTestAgainstTerrain = false;

        const rt: Runtime = {
          Cesium,
          viewer,
          baseLayer: null,
          sstLayer: null,
          airLayer: null,
          windLayer: null,
          precipLayer: null,
          humidityLayer: null,
          fluxLayer: null,
          marker: null,
        };
        runtimeRef.current = rt;

        const reportCamera = () => {
          const c = viewer.camera.positionCartographic;
          callbacks.current.onCameraChange?.({
            longitude: Cesium.Math.toDegrees(c.longitude),
            latitude: Cesium.Math.toDegrees(c.latitude),
            height: c.height,
          });
        };
        reportCamera();
        disposers.push(viewer.camera.changed.addEventListener(reportCamera));

        // Report an overlay "ready" once the globe has no tiles left to load.
        disposers.push(
          viewer.scene.globe.tileLoadProgressEvent.addEventListener((queued: number) => {
            if (queued !== 0) return;
            if (rt.sstLayer?.ready) report("sst", { state: "ready" });
            if (rt.airLayer?.ready) report("air-temperature", { state: "ready" });
            if (rt.windLayer?.ready) report("wind-speed", { state: "ready" });
            if (rt.precipLayer?.ready) report("precipitation", { state: "ready" });
            if (rt.humidityLayer?.ready) report("humidity", { state: "ready" });
            if (rt.fluxLayer?.ready) report("moisture-flux", { state: "ready" });
          }),
        );

        const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
        handler.setInputAction((click: CesiumNS.ScreenSpaceEventHandler.PositionedEvent) => {
          const position = viewer.camera.pickEllipsoid(
            click.position,
            viewer.scene.globe.ellipsoid,
          );
          if (!position) return;
          const carto = Cesium.Cartographic.fromCartesian(position);
          if (rt.marker) viewer.entities.remove(rt.marker);
          rt.marker = viewer.entities.add({
            position,
            point: {
              pixelSize: 12,
              color: Cesium.Color.fromCssColorString(GLOBE_MARKER_COLOR),
              outlineColor: Cesium.Color.WHITE,
              outlineWidth: 2,
              disableDepthTestDistance: Number.POSITIVE_INFINITY,
            },
          });
          callbacks.current.onLocationSelect?.({
            longitude: Cesium.Math.toDegrees(carto.longitude),
            latitude: Cesium.Math.toDegrees(carto.latitude),
            height: carto.height,
          });
        }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
        disposers.push(() => handler.destroy());

        applyBasemap(rt, desired.current.basemap);
        applySstOverlay(rt, desired.current.sstOverlay);
        applyAirTempOverlay(rt, desired.current.airTempOverlay);
        applyWindOverlay(rt, desired.current.windOverlay);
        applyPrecipOverlay(rt, desired.current.precipOverlay);
        applyHumidityOverlay(rt, desired.current.humidityOverlay);
        applyFluxOverlay(rt, desired.current.fluxOverlay);
        callbacks.current.onReady?.();
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        callbacks.current.onFatalError?.(
          err instanceof Error ? err.message : "Failed to load the 3D globe.",
        );
      });

    return () => {
      cancelled = true;
      const rt = runtimeRef.current;
      runtimeRef.current = null;
      // 1) input + event listeners, 2) entities, 3) imagery layers, 4) viewer.
      disposers.reverse().forEach((dispose) => dispose());
      if (!rt || rt.viewer.isDestroyed()) return;
      rt.viewer.entities.removeAll();
      rt.viewer.imageryLayers.removeAll(true);
      rt.viewer.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applyBasemap(rt, basemap);
  }, [basemap]);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applySstOverlay(rt, sstOverlay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sstOverlay.enabled, sstOverlay.time, sstOverlay.source]);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applyAirTempOverlay(rt, airTempOverlay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [airTempOverlay.enabled, airTempOverlay.date]);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applyWindOverlay(rt, windOverlay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [windOverlay.enabled, windOverlay.date]);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applyPrecipOverlay(rt, precipOverlay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [precipOverlay.enabled, precipOverlay.date]);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applyHumidityOverlay(rt, humidityOverlay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [humidityOverlay.enabled, humidityOverlay.date]);

  useEffect(() => {
    const rt = runtimeRef.current;
    if (rt) applyFluxOverlay(rt, fluxOverlay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fluxOverlay.enabled, fluxOverlay.date]);

  return <div ref={containerRef} className="absolute inset-0 w-full h-full" />;
});

export default EarthGlobe;
