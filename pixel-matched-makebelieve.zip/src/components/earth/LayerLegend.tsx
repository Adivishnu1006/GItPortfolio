import { useState } from "react";
import { AlertCircle, CheckCircle2, ChevronDown, Loader2 } from "lucide-react";
import { sstDataSource } from "@/lib/sst-core";
import { legendPosition } from "@/lib/era5-core";
import { addDays, BEAUFORT_LOWER_BOUNDS, WIND_COLOURS, WIND_HOUR_UTC } from "@/lib/era5-wind-core";
import { PRECIP_COLOURS, PRECIP_LOWER_BOUNDS } from "@/lib/era5-precip-core";
import { RH_HOUR_UTC } from "@/lib/era5-rh-core";
import {
  ARROW_MIN_MAGNITUDE,
  IVT_COLOURS,
  IVT_HOUR_UTC,
  IVT_LOWER_BOUNDS,
} from "@/lib/era5-ivt-core";
import type { LayerConfig, OverlayStatus } from "@/types/earth";

const T2M_TICKS = [-32, -16, 0, 16, 32];
/** Beaufort forces labelled under the wind ramp (lower bound of each class). */
const WIND_TICK_FORCES = [0, 4, 8, 12];
const RH_TICKS = [0, 20, 40, 60, 80, 100];

type Props = {
  layer: LayerConfig | null;
  observationDate?: string | null;
  overlayStatus?: OverlayStatus | undefined;
};

function formatDate(value: string | null | undefined): string {
  if (!value) return "Latest available record";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toISOString().slice(0, 10);
}

export function LayerLegend({ layer, observationDate, overlayStatus }: Props) {
  const [showDetails, setShowDetails] = useState(false);
  if (!layer) return null;
  const active = layer.status === "active";
  const mid = (sstDataSource.legendMin + sstDataSource.legendMax) / 2;

  return (
    <div className="w-full surface-card rounded-xl p-4" data-testid="layer-legend">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-accent mb-2">
        {layer.name}
      </h4>
      <p className="text-[11px] text-muted leading-relaxed mb-3">
        {layer.provider} · {layer.units}
      </p>

      <div className="flex items-center gap-1.5 mb-3">
        {!active ? (
          <>
            <AlertCircle className="w-3 h-3 text-warning shrink-0" strokeWidth={1.5} />
            <span className="text-[10px] text-warning font-medium">Planned — not yet active</span>
          </>
        ) : overlayStatus?.state === "loading" ? (
          <>
            <Loader2 className="w-3 h-3 text-accent shrink-0 animate-spin" strokeWidth={1.5} />
            <span className="text-[10px] text-muted font-medium">
              {layer.id === "air-temperature"
                ? "Loading ERA5 map…"
                : layer.id === "wind-speed"
                  ? "Building ERA5 wind map…"
                  : layer.id === "precipitation"
                    ? "Summing 24 hours of ERA5 precipitation…"
                    : layer.id === "humidity"
                      ? "Computing ERA5 humidity map…"
                      : layer.id === "atmospheric-moisture-flux"
                        ? "Building ERA5 moisture-flux map…"
                        : "Loading NOAA map tiles…"}
            </span>
          </>
        ) : overlayStatus?.state === "error" ? (
          <>
            <AlertCircle className="w-3 h-3 text-warning shrink-0" strokeWidth={1.5} />
            <span className="text-[10px] text-warning font-medium leading-snug">
              {overlayStatus.message}
            </span>
          </>
        ) : (
          <>
            <CheckCircle2 className="w-3 h-3 text-accent-soft shrink-0" strokeWidth={1.5} />
            <span className="text-[10px] text-accent-soft font-medium">Active data layer</span>
          </>
        )}
      </div>

      {active && layer.id === "sea-surface-temperature" && (
        <>
          <div className="h-2 rounded-full bg-sst-ramp mb-1.5" aria-hidden />
          <div className="flex justify-between text-[9px] font-mono text-muted mb-1">
            <span>≤{sstDataSource.legendMin} °C</span>
            <span>{mid} °C</span>
            <span>≥{sstDataSource.legendMax} °C</span>
          </div>
          <p className="text-[9px] text-muted mb-3">
            Daily mean SST in °C · NOAA ERDDAP palette · land and missing data transparent
          </p>
          <div className="flex justify-between text-[10px] font-mono text-muted mb-3">
            <span>Data date</span>
            <span className="text-body">{formatDate(observationDate)}</span>
          </div>
        </>
      )}

      {active && layer.id === "air-temperature" && (
        <>
          <div className="h-2 rounded-full bg-t2m-ramp mb-1.5" aria-hidden />
          <div className="relative h-3 text-[9px] font-mono text-muted mb-1" aria-hidden>
            {T2M_TICKS.map((t) => (
              <span
                key={t}
                className="absolute -translate-x-1/2"
                style={{ left: `${legendPosition(t)}%` }}
              >
                {t > 0 ? `+${t}` : t}
              </span>
            ))}
          </div>
          <p className="text-[9px] text-muted mb-3">
            Daily mean 2 m air temperature in °C (00–23 UTC) · 2 °C steps from −32 to +32 °C, end
            colours beyond · Copernicus Climate Pulse colour scale
          </p>
          <div className="flex justify-between text-[10px] font-mono text-muted mb-3">
            <span>Data date</span>
            <span className="text-body" data-testid="legend-data-date">
              {observationDate ? `${observationDate} (UTC day)` : "Unavailable"}
            </span>
          </div>
        </>
      )}

      {active && layer.id === "wind-speed" && (
        <>
          <div className="h-2 rounded-full bg-wind-ramp mb-1.5" aria-hidden />
          <div className="relative h-3 text-[9px] font-mono text-muted mb-1" aria-hidden>
            {WIND_TICK_FORCES.map((f) => (
              <span
                key={f}
                className={`absolute ${f === 0 ? "" : f === 12 ? "-translate-x-full" : "-translate-x-1/2"}`}
                style={{ left: `${f === 12 ? 100 : (f / WIND_COLOURS.length) * 100}%` }}
              >
                {f === 12 ? `≥${BEAUFORT_LOWER_BOUNDS[f]}` : BEAUFORT_LOWER_BOUNDS[f]}
              </span>
            ))}
          </div>
          <p className="text-[9px] text-muted mb-3">
            10 m wind speed in m/s, sqrt(u² + v²) · one colour per Beaufort force 0–12 (lower bounds
            0, 0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7 m/s) · viridis
          </p>
          <div className="flex justify-between text-[10px] font-mono text-muted mb-1">
            <span>Data time</span>
            <span className="text-body" data-testid="legend-data-date">
              {observationDate
                ? `${observationDate} ${String(WIND_HOUR_UTC).padStart(2, "0")}:00 UTC`
                : "Unavailable"}
            </span>
          </div>
          <p className="text-[9px] text-muted mb-3">Instantaneous hourly value, not a daily mean</p>
        </>
      )}

      {active && layer.id === "precipitation" && (
        <>
          <div className="h-2 rounded-full bg-precip-ramp mb-1.5" aria-hidden />
          <div className="relative h-3 text-[9px] font-mono text-muted mb-1" aria-hidden>
            {PRECIP_LOWER_BOUNDS.slice(1).map((b, i) => (
              <span
                key={b}
                className="absolute -translate-x-1/2"
                style={{ left: `${((i + 1) / PRECIP_COLOURS.length) * 100}%` }}
              >
                {b}
              </span>
            ))}
          </div>
          <p className="text-[9px] text-muted mb-3">
            Daily total in mm/day (sum of 24 hourly ERA5 accumulations) · grey = dry (&lt; 0.1 mm),
            then ColorBrewer YlGnBu classes from the lower bounds shown · transparent = no data ·
            rain and snow as water equivalent
          </p>
          <div className="flex justify-between text-[10px] font-mono text-muted mb-1">
            <span>UTC day</span>
            <span className="text-body" data-testid="legend-data-date">
              {observationDate ?? "Unavailable"}
            </span>
          </div>
          {observationDate && (
            <p className="text-[9px] text-muted mb-3">
              Accumulated {observationDate} 00:00 → {addDays(observationDate, 1)} 00:00 UTC
            </p>
          )}
        </>
      )}

      {active && layer.id === "humidity" && (
        <>
          <div className="h-2 rounded-full bg-rh-ramp mb-1.5" aria-hidden />
          <div className="relative h-3 text-[9px] font-mono text-muted mb-1" aria-hidden>
            {RH_TICKS.map((t) => (
              <span
                key={t}
                className={`absolute ${t === 0 ? "" : t === 100 ? "-translate-x-full" : "-translate-x-1/2"}`}
                style={{ left: `${t}%` }}
              >
                {t}
              </span>
            ))}
          </div>
          <p className="text-[9px] text-muted mb-3">
            2 m relative humidity in % (over water), 100 · es(Td)/es(T) from ERA5 2 m temperature
            and dew point · 10 % classes, ColorBrewer BrBG (brown = dry, teal = humid) · transparent
            = no data
          </p>
          <div className="flex justify-between text-[10px] font-mono text-muted mb-1">
            <span>Data time</span>
            <span className="text-body" data-testid="legend-data-date">
              {observationDate
                ? `${observationDate} ${String(RH_HOUR_UTC).padStart(2, "0")}:00 UTC`
                : "Unavailable"}
            </span>
          </div>
          <p className="text-[9px] text-muted mb-3">Instantaneous hourly value, not a daily mean</p>
        </>
      )}

      {active && layer.id === "atmospheric-moisture-flux" && (
        <>
          <div className="h-2 rounded-full bg-ivt-ramp mb-1.5" aria-hidden />
          <div className="relative h-3 text-[9px] font-mono text-muted mb-1" aria-hidden>
            {[250, 500, 1000].map((b) => (
              <span
                key={b}
                className="absolute -translate-x-1/2"
                style={{
                  left: `${(IVT_LOWER_BOUNDS.indexOf(b as (typeof IVT_LOWER_BOUNDS)[number]) / IVT_COLOURS.length) * 100}%`,
                }}
              >
                {b}
              </span>
            ))}
            <span className="absolute left-0">0</span>
          </div>
          <p className="text-[9px] text-muted mb-3">
            Vertically integrated water-vapour transport in kg m⁻¹ s⁻¹, sqrt(Fx² + Fy²) · classes
            from 0, 50, 100, 150, 250, 350, 500, 750, 1000 · ColorBrewer YlOrRd · ≥ 250 is the usual
            atmospheric-river threshold (Ralph et al., 2019) · arrows: direction of transport from
            the real components every 5° (shown where ≥ {ARROW_MIN_MAGNITUDE}, within ±70°), longer
            = stronger · transparent = no data
          </p>
          <div className="flex justify-between text-[10px] font-mono text-muted mb-1">
            <span>Data time</span>
            <span className="text-body" data-testid="legend-data-date">
              {observationDate
                ? `${observationDate} ${String(IVT_HOUR_UTC).padStart(2, "0")}:00 UTC`
                : "Unavailable"}
            </span>
          </div>
          <p className="text-[9px] text-muted mb-3">Instantaneous hourly value, not a daily mean</p>
        </>
      )}

      <button
        type="button"
        onClick={() => setShowDetails((v) => !v)}
        aria-expanded={showDetails}
        className="flex w-full items-center justify-between text-[10px] font-mono uppercase tracking-wider text-muted hover:text-body transition-colors"
      >
        Dataset details
        <ChevronDown
          className={`w-3 h-3 transition-transform ${showDetails ? "rotate-180" : ""}`}
          strokeWidth={1.5}
        />
      </button>
      {showDetails && (
        <>
          <div className="mt-2 space-y-1.5 text-[10px] font-mono text-muted">
            <div className="flex justify-between gap-3">
              <span>Coverage</span>
              <span className="text-body text-right">{layer.coverage}</span>
            </div>
            <div className="flex justify-between gap-3">
              <span>Spatial res.</span>
              <span className="text-body text-right">{layer.spatialResolution}</span>
            </div>
            <div className="flex justify-between gap-3">
              <span>Temporal res.</span>
              <span className="text-body text-right">{layer.temporalResolution}</span>
            </div>
          </div>

          <p className="text-[10px] text-muted mt-3 pt-3 border-t border-default leading-relaxed">
            {layer.attribution}
          </p>
        </>
      )}
    </div>
  );
}
