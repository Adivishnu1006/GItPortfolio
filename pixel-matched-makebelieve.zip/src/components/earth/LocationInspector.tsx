import { ChevronDown, ChevronUp, Clock, Eye, Loader2, MapPin, X } from "lucide-react";
import { earthLayers } from "@/config/earthLayers";
import { sstSummary, type SstPointView } from "@/lib/earth-inspector";
import { airTempSummary, celsiusToKelvin, type AirTempView } from "@/lib/era5-core";
import { compassPoint, WIND_HOUR_UTC, windSummary, type WindView } from "@/lib/era5-wind-core";
import { precipSummary, type PrecipView } from "@/lib/era5-precip-core";
import {
  humiditySummary,
  kelvinToCelsius,
  RH_HOUR_UTC,
  type HumidityView,
} from "@/lib/era5-rh-core";
import {
  IVT_HOUR_UTC,
  IVT_UNITS,
  moistureFluxSummary,
  type MoistureFluxView,
} from "@/lib/era5-ivt-core";
import type { PlaceName } from "@/lib/reverse-geocode";
import type { LayerConfig, LayerId, SelectedLocation } from "@/types/earth";

export type { SstPointView } from "@/lib/earth-inspector";

export type PlaceView =
  { state: "loading" } | { state: "done"; place: PlaceName } | { state: "error" };

type Props = {
  location: SelectedLocation;
  place: PlaceView;
  /** Layer currently drawn on the globe; only marks which measurement is visualised. */
  activeLayerId: LayerId | null;
  sst: SstPointView;
  sstDate: string | null;
  sstSourceLabel: string | null;
  air: AirTempView;
  airDate: string | null;
  wind: WindView;
  windDate: string | null;
  precip: PrecipView;
  precipDate: string | null;
  humidity: HumidityView;
  humidityDate: string | null;
  flux: MoistureFluxView;
  fluxDate: string | null;
  collapsed: boolean;
  onToggleCollapsed: () => void;
  onClear: () => void;
};

const SST_ID = "sea-surface-temperature";
const AIR_ID = "air-temperature";
const WIND_ID = "wind-speed";
const PRECIP_ID = "precipitation";
const HUMIDITY_ID = "humidity";
const FLUX_ID = "atmospheric-moisture-flux";

function formatCoordinate(value: number, positive: string, negative: string): string {
  const direction = value >= 0 ? positive : negative;
  return `${Math.abs(value).toFixed(4)}° ${direction}`;
}

function placeTitle(place: PlaceView): string {
  if (place.state === "loading") return "Looking up place name…";
  if (place.state === "error") return "Place name unavailable";
  return place.place.name ?? "Open water or unnamed area";
}

function OnGlobeBadge() {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-accent/15 px-2 py-0.5 text-[9px] font-mono text-accent">
      <Eye className="w-2.5 h-2.5" strokeWidth={1.5} />
      On globe
    </span>
  );
}

function MetaRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-muted">{label}</dt>
      <dd className="text-body text-right">{value}</dd>
    </div>
  );
}

function SstMeasurement({
  layer,
  sst,
  sstDate,
  sourceLabel,
  onGlobe,
}: {
  layer: LayerConfig;
  sst: SstPointView;
  sstDate: string | null;
  sourceLabel: string | null;
  onGlobe: boolean;
}) {
  const result = sst.state === "done" ? sst.result : null;
  return (
    <article
      data-testid="measurement-sst"
      className="rounded-xl border border-accent/30 bg-accent/10 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] uppercase tracking-wider text-muted">{layer.name}</p>
        {onGlobe && <OnGlobeBadge />}
      </div>

      {!result ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Loader2 className="w-3 h-3 animate-spin" strokeWidth={1.5} />
          Retrieving the NOAA observation…
        </p>
      ) : result.status === "ok" ? (
        <>
          <p className="text-2xl font-mono text-body mt-1">
            {result.observation.valueCelsius.toFixed(2)} {layer.units}
          </p>
          <p className="text-[11px] text-muted mt-1">
            Observation: {result.observation.observedAt.slice(0, 10)} (daily mean)
          </p>
        </>
      ) : result.status === "no-data" ? (
        <>
          <p className="text-xs font-medium text-warning mt-2">No ocean observation</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">
            The 0.25° grid cell at this point has no sea-surface temperature value (land or masked).
            No nearby ocean value is substituted.
          </p>
        </>
      ) : (
        <>
          <p className="text-xs font-medium text-warning mt-2">Observation unavailable</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      )}

      <dl className="mt-3 pt-3 border-t border-default space-y-1.5 text-[10px] font-mono">
        <MetaRow label="Variable" value={layer.variable} />
        <MetaRow label="Units" value={layer.units} />
        <MetaRow label="Data date" value={sstDate ? sstDate.slice(0, 10) : "Unavailable"} />
        {result?.status === "ok" && (
          <MetaRow
            label="Grid cell centre"
            value={`${result.observation.gridLatitude.toFixed(3)}°, ${result.observation.gridLongitude.toFixed(3)}°`}
          />
        )}
        {result?.status === "no-data" &&
          result.gridLatitude !== null &&
          result.gridLongitude !== null && (
            <MetaRow
              label="Grid cell centre"
              value={`${result.gridLatitude.toFixed(3)}°, ${result.gridLongitude.toFixed(3)}°`}
            />
          )}
        <MetaRow
          label="Resolution"
          value={`${layer.spatialResolution}, ${layer.temporalResolution.toLowerCase()}`}
        />
        <MetaRow label="Dataset" value="NOAA OISST V2.1" />
        {sourceLabel && <MetaRow label="Served by" value={sourceLabel} />}
      </dl>
      <p className="text-[10px] text-muted mt-2 leading-relaxed">{layer.attribution}</p>
    </article>
  );
}

function AirTempMeasurement({
  layer,
  air,
  airDate,
  onGlobe,
}: {
  layer: LayerConfig;
  air: AirTempView;
  airDate: string | null;
  onGlobe: boolean;
}) {
  const result = air.state === "done" ? air.result : null;
  return (
    <article
      data-testid="measurement-air-temperature"
      className="rounded-xl border border-accent-soft/30 bg-accent-soft/10 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] uppercase tracking-wider text-muted">{layer.name}</p>
        {onGlobe && <OnGlobeBadge />}
      </div>

      {!result ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Loader2 className="w-3 h-3 animate-spin" strokeWidth={1.5} />
          Retrieving the ERA5 value…
        </p>
      ) : result.status === "ok" ? (
        <>
          <p className="text-2xl font-mono text-body mt-1" data-testid="air-temperature-value">
            {result.observation.meanCelsius.toFixed(2)} {layer.units}
          </p>
          <p className="text-[11px] text-muted mt-1">
            {celsiusToKelvin(result.observation.meanCelsius).toFixed(2)} K · daily mean of 24 hourly
            values, 00–23 UTC
          </p>
          <p className="text-[11px] text-muted">
            Hourly range: {result.observation.minCelsius.toFixed(1)} to{" "}
            {result.observation.maxCelsius.toFixed(1)} °C
          </p>
        </>
      ) : result.status === "no-data" ? (
        <>
          <p className="text-xs font-medium text-warning mt-2">No ERA5 value</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      ) : (
        <>
          <p className="text-xs font-medium text-warning mt-2">Value unavailable</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      )}

      <dl className="mt-3 pt-3 border-t border-default space-y-1.5 text-[10px] font-mono">
        <MetaRow label="Variable" value="2m_temperature (2t)" />
        <MetaRow label="Units" value="°C (ERA5 stores K; °C = K − 273.15)" />
        <MetaRow label="Data date" value={airDate ? `${airDate} (UTC day)` : "Unavailable"} />
        {result?.status === "ok" && (
          <>
            <MetaRow
              label="Grid point"
              value={`${result.observation.gridLatitude.toFixed(2)}°, ${result.observation.gridLongitude.toFixed(2)}°`}
            />
            {result.observation.gridElevation !== null && (
              <MetaRow
                label="Grid-cell height"
                value={`${Math.round(result.observation.gridElevation).toLocaleString()} m`}
              />
            )}
          </>
        )}
        <MetaRow label="Resolution" value="0.25° × 0.25°, hourly" />
        <MetaRow label="Dataset" value="ERA5 hourly, single levels" />
        <MetaRow label="Values via" value="Open-Meteo (ERA5 model)" />
      </dl>
      <p className="text-[10px] text-muted mt-2 leading-relaxed">{layer.attribution}</p>
    </article>
  );
}

function WindMeasurement({
  layer,
  wind,
  windDate,
  onGlobe,
}: {
  layer: LayerConfig;
  wind: WindView;
  windDate: string | null;
  onGlobe: boolean;
}) {
  const result = wind.state === "done" ? wind.result : null;
  const hour = `${String(WIND_HOUR_UTC).padStart(2, "0")}:00 UTC`;
  return (
    <article
      data-testid="measurement-wind-speed"
      className="rounded-xl border border-default bg-bg-alt/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] uppercase tracking-wider text-muted">{layer.name}</p>
        {onGlobe && <OnGlobeBadge />}
      </div>

      {!result ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Loader2 className="w-3 h-3 animate-spin" strokeWidth={1.5} />
          Retrieving the ERA5 wind value…
        </p>
      ) : result.status === "ok" ? (
        <>
          <p className="text-2xl font-mono text-body mt-1" data-testid="wind-speed-value">
            {result.observation.speedMs.toFixed(1)} m/s
          </p>
          <p className="text-[11px] text-muted mt-1">
            {result.observation.speedKmh.toFixed(1)} km/h · Beaufort force{" "}
            {result.observation.beaufort}
          </p>
          <p className="text-[11px] text-muted">
            {result.observation.directionFrom === null
              ? "Direction: calm (undefined)"
              : `From ${compassPoint(result.observation.directionFrom)} (${Math.round(result.observation.directionFrom)}°)`}
          </p>
          <p className="text-[11px] text-muted">
            Instantaneous value at {result.observation.time.slice(0, 10)} {hour}
          </p>
        </>
      ) : result.status === "no-data" ? (
        <>
          <p className="text-xs font-medium text-warning mt-2">No ERA5 wind value</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      ) : (
        <>
          <p className="text-xs font-medium text-warning mt-2">Value unavailable</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      )}

      <dl className="mt-3 pt-3 border-t border-default space-y-1.5 text-[10px] font-mono">
        <MetaRow label="Variables" value="u10 + v10 → sqrt(u² + v²)" />
        {result?.status === "ok" && (
          <MetaRow
            label="Components"
            value={`u ${result.observation.u.toFixed(2)}, v ${result.observation.v.toFixed(2)} m/s`}
          />
        )}
        <MetaRow label="Units" value="m/s (km/h = m/s × 3.6)" />
        <MetaRow label="Data time" value={windDate ? `${windDate} ${hour}` : "Unavailable"} />
        {result?.status === "ok" && (
          <>
            <MetaRow
              label="Grid point"
              value={`${result.observation.gridLatitude.toFixed(2)}°, ${result.observation.gridLongitude.toFixed(2)}°`}
            />
            <MetaRow
              label="Release"
              value={
                result.observation.release === "ERA5T"
                  ? "ERA5T (preliminary, may be revised)"
                  : "ERA5 (final)"
              }
            />
          </>
        )}
        <MetaRow label="Resolution" value="0.25° × 0.25°, hourly" />
        <MetaRow label="Dataset" value="ERA5 hourly, single levels" />
        <MetaRow label="Values via" value="ARCO-ERA5 (Google Cloud)" />
      </dl>
      <p className="text-[10px] text-muted mt-2 leading-relaxed">
        Direction is where the wind blows from, clockwise from north. {layer.attribution}
      </p>
    </article>
  );
}

function PrecipMeasurement({
  layer,
  precip,
  precipDate,
  onGlobe,
}: {
  layer: LayerConfig;
  precip: PrecipView;
  precipDate: string | null;
  onGlobe: boolean;
}) {
  const result = precip.state === "done" ? precip.result : null;
  return (
    <article
      data-testid="measurement-precipitation"
      className="rounded-xl border border-default bg-bg-alt/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] uppercase tracking-wider text-muted">{layer.name}</p>
        {onGlobe && <OnGlobeBadge />}
      </div>

      {!result ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Loader2 className="w-3 h-3 animate-spin" strokeWidth={1.5} />
          Retrieving the ERA5 daily total…
        </p>
      ) : result.status === "ok" ? (
        <>
          <p className="text-2xl font-mono text-body mt-1" data-testid="precipitation-value">
            {result.observation.totalMm.toFixed(1)} mm/day
          </p>
          <p className="text-[11px] text-muted mt-1">
            {result.observation.totalMm < 0.1
              ? "Dry: less than 0.1 mm in the whole day"
              : `${result.observation.wetHours} of 24 hours with ≥ 0.1 mm · wettest hour ${result.observation.maxHourMm.toFixed(1)} mm`}
          </p>
          <p className="text-[11px] text-muted">
            Accumulated {result.observation.periodStart.slice(0, 10)} 00:00 →{" "}
            {result.observation.periodEnd.slice(0, 10)} 00:00 UTC
          </p>
        </>
      ) : result.status === "no-data" ? (
        <>
          <p className="text-xs font-medium text-warning mt-2">No complete daily total</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      ) : (
        <>
          <p className="text-xs font-medium text-warning mt-2">Value unavailable</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      )}

      <dl className="mt-3 pt-3 border-t border-default space-y-1.5 text-[10px] font-mono">
        <MetaRow label="Variable" value="total_precipitation (tp)" />
        <MetaRow label="Units" value="mm/day (ERA5 stores m; mm = m × 1000)" />
        <MetaRow label="UTC day" value={precipDate ?? "Unavailable"} />
        <MetaRow label="Aggregation" value="Sum of 24 hourly totals ending 01:00…24:00 UTC" />
        {result?.status === "ok" && (
          <>
            <MetaRow
              label="Grid point"
              value={`${result.observation.gridLatitude.toFixed(2)}°, ${result.observation.gridLongitude.toFixed(2)}°`}
            />
            <MetaRow
              label="Release"
              value={
                result.observation.release === "ERA5T"
                  ? "ERA5T (preliminary, may be revised)"
                  : "ERA5 (final)"
              }
            />
          </>
        )}
        <MetaRow label="Resolution" value="0.25° × 0.25°, hourly" />
        <MetaRow label="Dataset" value="ERA5 hourly, single levels" />
        <MetaRow label="Values via" value="ARCO-ERA5 (Google Cloud)" />
      </dl>
      <p className="text-[10px] text-muted mt-2 leading-relaxed">
        Total precipitation is rain plus snow (liquid and frozen water) reaching the surface, as
        water depth; it is model reanalysis, not a rain-gauge reading. {layer.attribution}
      </p>
    </article>
  );
}

function HumidityMeasurement({
  layer,
  humidity,
  humidityDate,
  onGlobe,
}: {
  layer: LayerConfig;
  humidity: HumidityView;
  humidityDate: string | null;
  onGlobe: boolean;
}) {
  const result = humidity.state === "done" ? humidity.result : null;
  const hour = `${String(RH_HOUR_UTC).padStart(2, "0")}:00 UTC`;
  return (
    <article
      data-testid="measurement-humidity"
      className="rounded-xl border border-default bg-bg-alt/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] uppercase tracking-wider text-muted">{layer.name}</p>
        {onGlobe && <OnGlobeBadge />}
      </div>

      {!result ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Loader2 className="w-3 h-3 animate-spin" strokeWidth={1.5} />
          Retrieving ERA5 temperature and dew point…
        </p>
      ) : result.status === "ok" ? (
        <>
          <p className="text-2xl font-mono text-body mt-1" data-testid="humidity-value">
            {result.observation.rhPercent.toFixed(1)} %
          </p>
          <p className="text-[11px] text-muted mt-1">
            From T {kelvinToCelsius(result.observation.temperatureK).toFixed(2)} °C and dew point{" "}
            {kelvinToCelsius(result.observation.dewpointK).toFixed(2)} °C (same hour and grid point)
          </p>
          <p className="text-[11px] text-muted">
            Instantaneous value at {result.observation.time.slice(0, 10)} {hour}
          </p>
          {result.observation.clamped && (
            <p className="text-[11px] text-muted">
              Rounding overshoot just above 100 % shown as 100 %.
            </p>
          )}
        </>
      ) : result.status === "no-data" ? (
        <>
          <p className="text-xs font-medium text-warning mt-2">No ERA5 humidity value</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      ) : (
        <>
          <p className="text-xs font-medium text-warning mt-2">Value unavailable</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      )}

      <dl className="mt-3 pt-3 border-t border-default space-y-1.5 text-[10px] font-mono">
        <MetaRow label="Inputs" value="2m_temperature (2t) + 2m_dewpoint_temperature (2d)" />
        <MetaRow label="Formula" value="RH = 100 · es(Td) / es(T)" />
        <MetaRow label="es" value="Over water, Tetens (ECMWF IFS constants)" />
        {result?.status === "ok" && (
          <MetaRow
            label="Inputs (K)"
            value={`T ${result.observation.temperatureK.toFixed(2)}, Td ${result.observation.dewpointK.toFixed(2)}`}
          />
        )}
        <MetaRow label="Units" value="% (0–100)" />
        <MetaRow
          label="Data time"
          value={humidityDate ? `${humidityDate} ${hour}` : "Unavailable"}
        />
        {result?.status === "ok" && (
          <>
            <MetaRow
              label="Grid point"
              value={`${result.observation.gridLatitude.toFixed(2)}°, ${result.observation.gridLongitude.toFixed(2)}°`}
            />
            <MetaRow
              label="Release"
              value={
                result.observation.release === "ERA5T"
                  ? "ERA5T (preliminary, may be revised)"
                  : "ERA5 (final)"
              }
            />
          </>
        )}
        <MetaRow label="Resolution" value="0.25° × 0.25°, hourly" />
        <MetaRow label="Dataset" value="ERA5 hourly, single levels" />
        <MetaRow label="Values via" value="ARCO-ERA5 (Google Cloud)" />
      </dl>
      <p className="text-[10px] text-muted mt-2 leading-relaxed">
        The temperature used here is the {hour} value, not the daily mean shown in the 2 m air
        temperature card. {layer.attribution}
      </p>
    </article>
  );
}

function MoistureFluxMeasurement({
  layer,
  flux,
  fluxDate,
  onGlobe,
}: {
  layer: LayerConfig;
  flux: MoistureFluxView;
  fluxDate: string | null;
  onGlobe: boolean;
}) {
  const result = flux.state === "done" ? flux.result : null;
  const hour = `${String(IVT_HOUR_UTC).padStart(2, "0")}:00 UTC`;
  return (
    <article
      data-testid="measurement-moisture-flux"
      className="rounded-xl border border-default bg-bg-alt/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] uppercase tracking-wider text-muted">{layer.name}</p>
        {onGlobe && <OnGlobeBadge />}
      </div>

      {!result ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Loader2 className="w-3 h-3 animate-spin" strokeWidth={1.5} />
          Retrieving the ERA5 flux components…
        </p>
      ) : result.status === "ok" ? (
        <>
          <p className="text-2xl font-mono text-body mt-1" data-testid="moisture-flux-value">
            {result.observation.magnitude.toFixed(1)} <span className="text-sm">{IVT_UNITS}</span>
          </p>
          <p className="text-[11px] text-muted mt-1">
            Eastward {result.observation.eastward.toFixed(1)} · northward{" "}
            {result.observation.northward.toFixed(1)} {IVT_UNITS}
          </p>
          <p className="text-[11px] text-muted">
            {result.observation.directionTowards === null
              ? "Direction: no measurable transport"
              : `Moisture moving towards ${compassPoint(result.observation.directionTowards)} (${Math.round(result.observation.directionTowards)}°)`}
          </p>
          <p className="text-[11px] text-muted">
            Instantaneous value at {result.observation.time.slice(0, 10)} {hour}
          </p>
        </>
      ) : result.status === "no-data" ? (
        <>
          <p className="text-xs font-medium text-warning mt-2">No ERA5 flux value</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      ) : (
        <>
          <p className="text-xs font-medium text-warning mt-2">Value unavailable</p>
          <p className="text-[11px] text-muted mt-1 leading-relaxed">{result.message}</p>
        </>
      )}

      <dl className="mt-3 pt-3 border-t border-default space-y-1.5 text-[10px] font-mono">
        <MetaRow label="Variables" value="viwve + viwvn → sqrt(Fx² + Fy²)" />
        <MetaRow label="Units" value={`${IVT_UNITS} (vertically integrated)`} />
        <MetaRow label="Data time" value={fluxDate ? `${fluxDate} ${hour}` : "Unavailable"} />
        <MetaRow label="Aggregation" value="Instantaneous, surface to top of atmosphere" />
        {result?.status === "ok" && (
          <>
            <MetaRow
              label="Grid point"
              value={`${result.observation.gridLatitude.toFixed(2)}°, ${result.observation.gridLongitude.toFixed(2)}°`}
            />
            <MetaRow
              label="Release"
              value={
                result.observation.release === "ERA5T"
                  ? "ERA5T (preliminary, may be revised)"
                  : "ERA5 (final)"
              }
            />
          </>
        )}
        <MetaRow label="Resolution" value="0.25° × 0.25°, hourly" />
        <MetaRow label="Dataset" value="ERA5 hourly, single levels" />
        <MetaRow label="Values via" value="ARCO-ERA5 (Google Cloud)" />
      </dl>
      <p className="text-[10px] text-muted mt-2 leading-relaxed">
        Direction is where the water vapour is carried towards, clockwise from north — the opposite
        of the wind convention above (where wind comes from). This is transport, not moisture
        content or a precipitation rate. {layer.attribution}
      </p>
    </article>
  );
}

function PlannedMeasurement({ layer }: { layer: LayerConfig }) {
  return (
    <li
      data-testid={`measurement-${layer.id}`}
      className="rounded-xl border border-default bg-bg-alt/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-body">{layer.name}</p>
        <span className="inline-flex items-center gap-1 rounded-full bg-warning/10 px-2 py-0.5 text-[9px] font-mono text-warning">
          <Clock className="w-2.5 h-2.5" strokeWidth={1.5} />
          Planned
        </span>
      </div>
      <p className="text-[11px] text-muted mt-1">Not yet available — no value is shown.</p>
      <p className="text-[10px] font-mono text-muted mt-1.5 leading-relaxed">
        {layer.variable} · {layer.units} · {layer.provider}
      </p>
    </li>
  );
}

export function LocationInspector({
  location,
  place,
  activeLayerId,
  sst,
  sstDate,
  sstSourceLabel,
  air,
  airDate,
  wind,
  windDate,
  precip,
  precipDate,
  humidity,
  humidityDate,
  flux,
  fluxDate,
  collapsed,
  onToggleCollapsed,
  onClear,
}: Props) {
  const sstLayer = earthLayers.find((l) => l.id === SST_ID)!;
  const airLayer = earthLayers.find((l) => l.id === AIR_ID)!;
  const windLayer = earthLayers.find((l) => l.id === WIND_ID)!;
  const precipLayer = earthLayers.find((l) => l.id === PRECIP_ID)!;
  const humidityLayer = earthLayers.find((l) => l.id === HUMIDITY_ID)!;
  const fluxLayer = earthLayers.find((l) => l.id === FLUX_ID)!;
  const planned = earthLayers.filter((l) => l.status === "planned");
  const coords = `${formatCoordinate(location.latitude, "N", "S")} · ${formatCoordinate(location.longitude, "E", "W")}`;

  return (
    <aside
      aria-label="Location inspector"
      className={`absolute z-20 inset-x-2 top-44 sm:inset-x-auto sm:right-16 sm:top-32 lg:top-20 sm:w-[340px] surface-card rounded-2xl flex flex-col overflow-hidden ${
        collapsed ? "" : "max-h-[45vh] sm:max-h-none sm:bottom-4"
      }`}
    >
      <div className="px-4 py-3 border-b border-default flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5 min-w-0">
          <MapPin className="w-4 h-4 text-accent mt-0.5 shrink-0" strokeWidth={1.5} />
          <div className="min-w-0">
            <p className="text-[10px] font-mono uppercase tracking-[0.18em] text-accent">
              Selected location
            </p>
            <h2 data-testid="place-name" className="font-serif text-base text-body mt-0.5 truncate">
              {placeTitle(place)}
            </h2>
            {place.state === "done" && place.place.detail && (
              <p className="text-[11px] text-muted truncate">{place.place.detail}</p>
            )}
            <p
              className="text-[11px] font-mono text-muted mt-0.5"
              data-testid="selected-coordinates"
            >
              {coords}
            </p>
            {collapsed && (
              <>
                <p data-testid="sst-summary" className="text-[11px] text-body mt-1">
                  SST: {sstSummary(sst)}
                </p>
                <p data-testid="air-summary" className="text-[11px] text-body">
                  Air (2 m): {airTempSummary(air)}
                </p>
                <p data-testid="wind-summary" className="text-[11px] text-body">
                  Wind (10 m): {windSummary(wind)}
                </p>
                <p data-testid="precip-summary" className="text-[11px] text-body">
                  Precipitation: {precipSummary(precip)}
                </p>
                <p data-testid="humidity-summary" className="text-[11px] text-body">
                  Humidity (2 m): {humiditySummary(humidity)}
                </p>
                <p data-testid="flux-summary" className="text-[11px] text-body">
                  Moisture flux: {moistureFluxSummary(flux)}
                </p>
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={onToggleCollapsed}
            aria-label={collapsed ? "Expand location inspector" : "Collapse location inspector"}
            aria-expanded={!collapsed}
            className="w-8 h-8 rounded-full flex items-center justify-center text-muted hover:text-body hover:bg-bg-alt transition-colors"
          >
            {collapsed ? (
              <ChevronUp className="w-4 h-4" strokeWidth={1.5} />
            ) : (
              <ChevronDown className="w-4 h-4" strokeWidth={1.5} />
            )}
          </button>
          <button
            type="button"
            onClick={onClear}
            aria-label="Clear selected location"
            className="w-8 h-8 rounded-full flex items-center justify-center text-muted hover:text-body hover:bg-bg-alt transition-colors"
          >
            <X className="w-4 h-4" strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className="p-4 space-y-4 overflow-y-auto scrollbar-hide">
          <section className="space-y-2">
            <h3 className="text-[10px] font-semibold uppercase tracking-wider text-accent mb-2">
              Measurements at this point
            </h3>
            <SstMeasurement
              layer={sstLayer}
              sst={sst}
              sstDate={sstDate}
              sourceLabel={sstSourceLabel}
              onGlobe={activeLayerId === SST_ID}
            />
            <AirTempMeasurement
              layer={airLayer}
              air={air}
              airDate={airDate}
              onGlobe={activeLayerId === AIR_ID}
            />
            <WindMeasurement
              layer={windLayer}
              wind={wind}
              windDate={windDate}
              onGlobe={activeLayerId === WIND_ID}
            />
            <PrecipMeasurement
              layer={precipLayer}
              precip={precip}
              precipDate={precipDate}
              onGlobe={activeLayerId === PRECIP_ID}
            />
            <HumidityMeasurement
              layer={humidityLayer}
              humidity={humidity}
              humidityDate={humidityDate}
              onGlobe={activeLayerId === HUMIDITY_ID}
            />
            <MoistureFluxMeasurement
              layer={fluxLayer}
              flux={flux}
              fluxDate={fluxDate}
              onGlobe={activeLayerId === FLUX_ID}
            />
          </section>

          {planned.length > 0 && (
            <section>
              <h3 className="text-[10px] font-semibold uppercase tracking-wider text-muted mb-2">
                Planned measurements
              </h3>
              <ul className="space-y-2">
                {planned.map((layer) => (
                  <PlannedMeasurement key={layer.id} layer={layer} />
                ))}
              </ul>
            </section>
          )}

          <p className="text-[10px] font-mono text-muted border-t border-default pt-3 leading-relaxed">
            Point height: {(Math.round(location.height) || 0).toLocaleString()} m above ellipsoid
            <br />
            Place names: © OpenStreetMap contributors (Nominatim)
          </p>
        </div>
      )}
    </aside>
  );
}
