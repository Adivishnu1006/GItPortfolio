import { Globe as GlobeIcon, Satellite } from "lucide-react";
import { basemapSources } from "@/config/earthLayers";
import type { BasemapType } from "@/types/earth";

type Props = {
  basemap: BasemapType;
  onChange: (basemap: BasemapType) => void;
};

const options: { id: BasemapType; Icon: typeof GlobeIcon }[] = [
  { id: "default", Icon: GlobeIcon },
  { id: "satellite", Icon: Satellite },
];

export function BasemapSelector({ basemap, onChange }: Props) {
  return (
    <div
      className="absolute left-4 top-32 z-10 surface-card rounded-xl p-1.5 flex gap-1"
      role="group"
      aria-label="Basemap"
    >
      {options.map(({ id, Icon }) => (
        <button
          key={id}
          type="button"
          aria-pressed={basemap === id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            basemap === id
              ? "bg-accent text-warmwhite-100"
              : "text-muted hover:text-body hover:bg-bg-alt"
          }`}
        >
          <Icon className="w-3.5 h-3.5" strokeWidth={1.5} />
          {basemapSources[id].label}
        </button>
      ))}
    </div>
  );
}
