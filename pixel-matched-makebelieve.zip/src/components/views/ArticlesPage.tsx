import { Link } from "@tanstack/react-router";
import { BookOpen, ArrowLeft, Clock, Calendar, ArrowUpRight } from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";
import { articles } from "@/data/content";

export function ArticlesPage() {
  return (
    <div className="pt-24">
      <section className="py-16 md:py-20 border-b border-default">
        <div className="container-page">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Articles
            </p>
            <h1 className="font-serif text-display text-body text-balance max-w-3xl">
              Published technical articles
            </h1>
            <p className="mt-6 text-lg text-muted leading-relaxed max-w-2xl text-pretty">
              Technical articles published on LinkedIn, exploring Earth Observation, remote sensing,
              and the science of seeing our planet from above.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-12">
        <div className="container-page">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {articles.map((article, i) => (
              <Reveal key={article.id} delay={i * 80}>
                <div className="group block surface-card overflow-hidden hover:shadow-card transition-all duration-500 h-full flex flex-col">
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={article.coverImage}
                      alt={article.title}
                      loading="lazy"
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/50 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="text-xs font-medium text-warmwhite-100 bg-ocean-900/40 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        {article.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-7 flex-1 flex flex-col">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-xs text-muted font-mono flex items-center gap-1">
                        <Clock className="w-3 h-3" strokeWidth={1.5} /> {article.readingTime}
                      </span>
                      <span className="text-xs text-muted font-mono flex items-center gap-1">
                        <Calendar className="w-3 h-3" strokeWidth={1.5} /> {article.date}
                      </span>
                    </div>
                    <h3 className="font-serif text-xl text-body mb-3 group-hover:text-accent transition-colors leading-snug">
                      {article.title}
                    </h3>
                    <p className="text-sm text-muted leading-relaxed line-clamp-3 mb-5 flex-1">
                      {article.summary}
                    </p>
                    <a
                      href={article.linkedinUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-accent hover:gap-2.5 transition-all mt-auto"
                    >
                      Read Article
                      <ArrowUpRight className="w-4 h-4" strokeWidth={2} />
                    </a>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {articles.length === 0 && (
            <div className="text-center py-20">
              <BookOpen className="w-10 h-10 text-muted mx-auto mb-4" strokeWidth={1} />
              <p className="text-muted">No articles published yet.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

export function ArticlePage({ slug }: { slug: string }) {
  const article = articles.find((a) => a.slug === slug);

  if (!article) {
    return (
      <div className="pt-32 pb-20 container-page text-center">
        <h1 className="font-serif text-2xl text-body mb-4">Article not found</h1>
        <Link to="/articles" className="text-accent hover:underline inline-flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" /> Back to articles
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-24">
      <article className="py-16 md:py-20">
        <div className="container-page">
          <div className="max-w-prose-wide mx-auto">
            <Reveal>
              <Link
                to="/articles"
                className="inline-flex items-center gap-2 text-sm text-muted hover:text-accent transition-colors mb-8"
              >
                <ArrowLeft className="w-4 h-4" strokeWidth={1.5} /> Back to articles
              </Link>
              <div className="flex items-center gap-3 mb-6">
                <span className="text-xs font-medium text-accent px-3 py-1.5 rounded-full bg-accent/8">
                  {article.category}
                </span>
                <span className="text-xs text-muted font-mono flex items-center gap-1">
                  <Clock className="w-3 h-3" strokeWidth={1.5} /> {article.readingTime}
                </span>
                <span className="text-xs text-muted font-mono">{article.date}</span>
              </div>
              <h1 className="font-serif text-hero text-body text-balance mb-8">{article.title}</h1>
              <p className="text-xl text-muted leading-relaxed text-pretty font-serif italic mb-12 border-l-2 border-accent pl-6">
                {article.summary}
              </p>
            </Reveal>

            <Reveal delay={100}>
              <div className="relative h-64 md:h-80 rounded-3xl overflow-hidden mb-12">
                <img
                  src={article.coverImage}
                  alt={article.title}
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/40 to-transparent" />
              </div>
            </Reveal>

            <Reveal delay={150}>
              <a
                href={article.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-accent text-warmwhite-100 font-medium text-sm hover:opacity-90 transition-all shadow-soft"
              >
                Read on LinkedIn
                <ArrowUpRight className="w-4 h-4" strokeWidth={2} />
              </a>
            </Reveal>

            <div className="mt-16 pt-8 border-t border-default">
              <p className="text-sm text-muted mb-4">More articles</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {articles
                  .filter((a) => a.slug !== article.slug)
                  .map((a) => (
                    <a
                      key={a.id}
                      href={a.linkedinUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group block surface-card p-5 hover:shadow-card transition-all"
                    >
                      <span className="text-xs text-accent">{a.category}</span>
                      <h3 className="font-serif text-base text-body mt-1 group-hover:text-accent transition-colors">
                        {a.title}
                      </h3>
                    </a>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </article>
    </div>
  );
}
