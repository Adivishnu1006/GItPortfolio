import { Link } from "@tanstack/react-router";
import { useEffect } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  MapPin,
  Calendar,
  Satellite,
  Cloud,
  Droplets,
  Layers,
  Mountain,
  GitCompare,
  Database,
  Activity,
  AlertTriangle,
  RefreshCw,
  Gauge,
  CheckCircle2,
} from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";

const GEE_URL = "https://total-now-460106-b2.projects.earthengine.app/view/nepalfloods";
const HERO_IMAGE =
  "https://images.pexels.com/photos/30462124/pexels-photo-30462124.jpeg?auto=compress&cs=tinysrgb&w=1920";

const workflowSteps = [
  { icon: Satellite, label: "Sentinel-2", desc: "Surface reflectance imagery acquisition" },
  {
    icon: Cloud,
    label: "Cloud Masking",
    desc: "SCL-based removal of clouds, shadows, cirrus, and snow",
  },
  {
    icon: Droplets,
    label: "MNDWI",
    desc: "Modified Normalized Difference Water Index calculation",
  },
  { icon: GitCompare, label: "Change Detection", desc: "Pre-event vs post-event MNDWI comparison" },
  { icon: Mountain, label: "DEM / Slope Filtering", desc: "SRTM-derived slope constraint (< 15°)" },
  {
    icon: Layers,
    label: "Historical Water Context",
    desc: "JRC Global Surface Water occurrence masking",
  },
  {
    icon: Activity,
    label: "Potential Inundation",
    desc: "Terrain-constrained analytical output layer",
  },
];

const datasets = [
  {
    name: "Copernicus Sentinel-2 Surface Reflectance",
    desc: "Optical satellite imagery providing multi-spectral surface reflectance for water index computation and change detection.",
  },
  {
    name: "SRTM DEM",
    desc: "Shuttle Radar Topography Mission digital elevation model used to derive slope and constrain analysis to low-slope terrain.",
  },
  {
    name: "JRC Global Surface Water",
    desc: "Historical water-occurrence dataset used to distinguish newly developed water from persistent water bodies.",
  },
  {
    name: "Google Earth Engine",
    desc: "Cloud computing platform enabling satellite data access, processing, and dynamic archive search at scale.",
  },
];

const keyParameters = [
  { label: "MNDWI water threshold", value: "> 0.1" },
  { label: "MNDWI change threshold", value: "> 0.2" },
  { label: "Terrain constraint", value: "Slope < 15°" },
  { label: "Pre-event reference", value: "27 Jul – 27 Aug 2026" },
  { label: "Latest post-event acquisition", value: "29 Aug 2026" },
  { label: "Sentinel-2 tile", value: "45RUL" },
];

const limitations = [
  "The output represents a satellite-derived analytical indication of potential inundation.",
  "It is NOT an officially mapped flood boundary.",
  "It should NOT be interpreted as a confirmed flooded area.",
  "The latest Sentinel-2 acquisition does not provide complete fresh coverage of the entire study area.",
  "Therefore, the approximately 0.03 km² estimate represents only the terrain-constrained potential inundation detected within the latest available imagery coverage.",
  "It should NOT be interpreted as the total flood extent across the Bhote Koshi region.",
  "Optical satellite observations can also be affected by cloud cover, image availability, terrain effects, and other sources of uncertainty.",
  "Independent validation would be required before using the result for operational decision-making.",
];

const validationSources = [
  "Field observations",
  "Authoritative disaster-response information",
  "Additional satellite observations",
  "Sentinel-1 SAR",
];

const techTags = [
  "Google Earth Engine",
  "Sentinel-2",
  "Remote Sensing",
  "Earth Observation",
  "MNDWI",
  "Flood Mapping",
  "SRTM",
  "DEM",
  "Terrain Analysis",
  "JRC Global Surface Water",
  "Geospatial Analysis",
  "Disaster Risk Mapping",
];

export function NepalFloodCaseStudy() {
  useEffect(() => {
    document.title = "Nepal Flood Response Mapping | Earth Observation Lab";
    const meta = document.createElement("meta");
    meta.name = "description";
    meta.content =
      "Satellite-based potential inundation analysis of the Bhote Koshi region of Nepal using Sentinel-2, MNDWI, terrain analysis, JRC Global Surface Water, and Google Earth Engine.";
    document.head.appendChild(meta);
    return () => {
      document.head.removeChild(meta);
      document.title = "Earth Observation Lab";
    };
  }, []);

  return (
    <div className="pt-24">
      <Hero />
      <Introduction />
      <AnalysisQuestion />
      <BeforeAfter />
      <Methodology />
      <Datasets />
      <KeyParameters />
      <DynamicMonitoring />
      <Results />
      <Interpretation />
      <Limitations />
      <InteractiveApp />
      <TechTags />
      <FinalStatement />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative min-h-[72vh] flex items-end py-20 grain">
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO_IMAGE})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/80 via-slate-900/60 to-slate-900" />
      </div>

      <div className="container-page relative">
        <div className="max-w-3xl">
          <Reveal>
            <Link
              to="/research"
              className="inline-flex items-center gap-2 text-sm text-warmwhite-100/70 hover:text-warmwhite-100 transition-colors mb-8"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={1.5} /> Back to Research
            </Link>
          </Reveal>
          <Reveal delay={100}>
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <span className="text-xs font-medium text-warmwhite-100 bg-ocean-900/50 backdrop-blur-md px-3 py-1.5 rounded-full">
                Earth Observation · Remote Sensing · Flood Analysis
              </span>
            </div>
          </Reveal>
          <Reveal delay={200}>
            <h1 className="font-serif text-display text-warmwhite-100 text-balance">
              Nepal Flood Response Mapping
            </h1>
          </Reveal>
          <Reveal delay={300}>
            <p className="mt-5 text-lg text-warmwhite-100/80 leading-relaxed text-pretty">
              Satellite-based potential inundation analysis | August 2026
            </p>
          </Reveal>
          <Reveal delay={400}>
            <div className="mt-6 flex flex-wrap items-center gap-5 text-sm text-warmwhite-100/70">
              <span className="inline-flex items-center gap-2">
                <MapPin className="w-4 h-4" strokeWidth={1.5} /> Bhote Koshi Region, Nepal
              </span>
              <span className="inline-flex items-center gap-2">
                <Calendar className="w-4 h-4" strokeWidth={1.5} /> August 2026
              </span>
            </div>
          </Reveal>
          <Reveal delay={500}>
            <a
              href={GEE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100 text-ocean-600 font-medium text-sm hover:bg-warmwhite-200 transition-all shadow-elevated"
            >
              Explore Interactive Analysis
              <ArrowUpRight className="w-4 h-4" strokeWidth={2} />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Introduction() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <div className="max-w-3xl mx-auto">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Introduction
            </p>
            <p className="text-lg text-muted leading-relaxed text-pretty">
              This analysis examines potential flood inundation in the Bhote Koshi region of Nepal
              using satellite imagery and Google Earth Engine. The objective was to compare
              pre-event and post-event surface conditions and identify areas showing signs of newly
              developed water coverage.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function AnalysisQuestion() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <div className="max-w-3xl mx-auto">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Analysis Question
            </p>
            <h2 className="font-serif text-section text-body text-balance mb-6">
              What changed after the event?
            </h2>
            <p className="text-lg text-muted leading-relaxed text-pretty">
              The analysis uses satellite observations to compare surface conditions before and
              after the event and identify locations where water presence appears to have increased.
              This is an analytical screening workflow, not an official disaster map.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function BeforeAfter() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Before &amp; After
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Pre-event reference vs latest post-event acquisition
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Reveal>
            <div className="surface-card overflow-hidden h-full">
              <div className="relative h-64 md:h-80 overflow-hidden bg-bg-alt flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-br from-ocean-700/30 to-ocean-900/50" />
                <div className="relative text-center px-6">
                  <Satellite className="w-8 h-8 text-accent mx-auto mb-3" strokeWidth={1.5} />
                  <p className="text-sm font-mono text-muted">Pre-event Sentinel-2 composite</p>
                  <p className="text-xs text-muted mt-1">27 July – 27 August 2026</p>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-serif text-lg text-body mb-1">Pre-event Reference</h3>
                <p className="text-sm text-muted leading-relaxed">
                  Sentinel-2 surface reflectance composite built from imagery acquired between 27
                  July and 27 August 2026, serving as the baseline for change detection.
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <div className="surface-card overflow-hidden h-full">
              <div className="relative h-64 md:h-80 overflow-hidden bg-bg-alt flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-700/30 to-forest-900/50" />
                <div className="relative text-center px-6">
                  <RefreshCw className="w-8 h-8 text-accent mx-auto mb-3" strokeWidth={1.5} />
                  <p className="text-sm font-mono text-muted">Latest post-event acquisition</p>
                  <p className="text-xs text-muted mt-1">29 August 2026 · Tile 45RUL</p>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-serif text-lg text-body mb-1">Post-event Acquisition</h3>
                <p className="text-sm text-muted leading-relaxed">
                  Latest available Sentinel-2 acquisition after the event, dynamically identified
                  from the Google Earth Engine archive. Tile 45RUL.
                </p>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={200}>
          <p className="mt-8 text-xs text-muted font-mono text-center max-w-2xl mx-auto">
            Visual placeholders represent the analytical composite periods. No fabricated imagery is
            shown. The interactive Earth Engine application displays the actual satellite
            observations.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

function Methodology() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Methodology
            </p>
            <h2 className="font-serif text-section text-body text-balance">Analysis Workflow</h2>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="max-w-2xl mx-auto mb-16">
            <div className="space-y-0">
              {workflowSteps.map((step, i) => (
                <div key={step.label} className="flex items-stretch">
                  <div className="flex flex-col items-center mr-5">
                    <div className="w-12 h-12 rounded-xl bg-surface border border-default flex items-center justify-center shrink-0">
                      <step.icon className="w-5 h-5 text-accent" strokeWidth={1.5} />
                    </div>
                    {i < workflowSteps.length - 1 && <div className="w-px flex-1 bg-border my-1" />}
                  </div>
                  <div className="pb-8 pt-2">
                    <span className="text-[10px] font-mono text-muted">
                      Step {String(i + 1).padStart(2, "0")}
                    </span>
                    <h3 className="font-serif text-base text-body mt-0.5">{step.label}</h3>
                    <p className="text-sm text-muted leading-relaxed mt-1">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={200}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-5xl mx-auto">
            {methodDetails.map((m, i) => (
              <div key={m.title} className="surface-card p-6">
                <span className="text-[10px] font-mono text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="font-serif text-base text-body mt-2 mb-2">{m.title}</h3>
                <p className="text-sm text-muted leading-relaxed">{m.text}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

const methodDetails = [
  {
    title: "Study Area",
    text: "The Bhote Koshi region of Nepal, a steep mountain river valley prone to seasonal flood events and terrain-driven hazards.",
  },
  {
    title: "Pre-event Reference",
    text: "A Sentinel-2 surface reflectance composite was built for the period 27 July – 27 August 2026 to establish baseline surface conditions.",
  },
  {
    title: "Dynamic Post-event Search",
    text: "The workflow searches the available Sentinel-2 archive after the event and dynamically identifies the latest available acquisition, rather than relying on a single hard-coded date.",
  },
  {
    title: "Cloud Masking",
    text: "The Sentinel-2 Scene Classification Layer (SCL) is used to remove cloud shadow, medium and high probability clouds, cirrus, and snow or ice contamination.",
  },
  {
    title: "Water Detection",
    text: "The Modified Normalized Difference Water Index (MNDWI) is calculated to enhance the contrast between water and surrounding land surfaces.",
  },
  {
    title: "Temporal Change Detection",
    text: "Pre-event and post-event MNDWI values are compared to identify areas showing increased water presence relative to the baseline.",
  },
  {
    title: "Terrain Filtering",
    text: "The SRTM DEM is used to derive slope, and potential inundation is constrained to lower-slope terrain (slope < 15°) to reduce false positives on steep slopes.",
  },
  {
    title: "Historical Water Context",
    text: "JRC Global Surface Water is used to provide historical water-occurrence context and reduce confusion with persistent water bodies.",
  },
  {
    title: "Final Analytical Layer",
    text: "A terrain-constrained potential inundation layer is produced, representing locations where satellite-derived water indicators increased and satisfied all applied constraints.",
  },
];

function Datasets() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Datasets
            </p>
            <h2 className="font-serif text-section text-body text-balance">Data &amp; Methods</h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {datasets.map((d, i) => (
            <Reveal key={d.name} delay={i * 80}>
              <div className="surface-card p-6 h-full flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5 text-accent" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="font-serif text-base text-body mb-1.5">{d.name}</h3>
                  <p className="text-sm text-muted leading-relaxed">{d.desc}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function KeyParameters() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Key Parameters
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Analysis configuration
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl">
          {keyParameters.map((p, i) => (
            <Reveal key={p.label} delay={i * 60}>
              <div className="surface-card p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Gauge className="w-4 h-4 text-accent" strokeWidth={1.5} />
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted">
                    {p.label}
                  </span>
                </div>
                <p className="font-mono text-lg text-body">{p.value}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function DynamicMonitoring() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="relative rounded-5xl overflow-hidden grain">
            <div className="absolute inset-0 bg-gradient-to-br from-ocean-600 via-ocean-500 to-emerald-500" />
            <div className="relative px-8 py-14 md:px-16 md:py-16">
              <div className="max-w-2xl">
                <div className="inline-flex items-center gap-2 mb-5">
                  <RefreshCw className="w-4 h-4 text-warmwhite-100" strokeWidth={1.5} />
                  <span className="text-xs font-semibold uppercase tracking-[0.2em] text-warmwhite-100">
                    Dynamic Post-event Monitoring
                  </span>
                </div>
                <h2 className="font-serif text-section text-warmwhite-100 text-balance mb-6">
                  The workflow updates as new imagery becomes available
                </h2>
                <p className="text-base text-warmwhite-100/85 leading-relaxed text-pretty">
                  The workflow does not permanently depend on a single post-event image. It searches
                  the available Sentinel-2 archive after the event and identifies the latest
                  available acquisition, allowing the analysis to update as new imagery becomes
                  available through Google Earth Engine. This dynamic post-event analysis is one of
                  the key strengths of the approach.
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Results() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Results
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Current Analytical Result
            </h2>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="max-w-3xl mx-auto text-center">
            <p className="font-serif text-display text-body text-balance">~0.03 km²</p>
            <p className="mt-4 text-sm font-semibold uppercase tracking-wider text-accent">
              Terrain-constrained potential inundation
            </p>
            <p className="mt-6 text-base text-muted leading-relaxed max-w-xl mx-auto text-pretty">
              The analysis identified approximately 0.03 km² of terrain-constrained potential
              inundation within the latest available Sentinel-2 imagery coverage.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Interpretation() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <div className="max-w-3xl mx-auto">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Result Interpretation
            </p>
            <p className="text-lg text-muted leading-relaxed text-pretty">
              The detected areas represent locations where satellite-derived water indicators
              increased relative to the pre-event reference and satisfied the applied terrain and
              historical-water constraints. This is an analytical indication requiring further
              investigation.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Limitations() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-amber-500" strokeWidth={1.5} />
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-500">
                  Important
                </p>
                <h2 className="font-serif text-section text-body">
                  Limitations &amp; Interpretation
                </h2>
              </div>
            </div>

            <ul className="space-y-3 mb-10">
              {limitations.map((l) => (
                <li key={l} className="flex items-start gap-3 text-sm text-muted leading-relaxed">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-2" />
                  <span className="text-pretty">{l}</span>
                </li>
              ))}
            </ul>

            <div className="surface-card p-6">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-accent mb-4">
                Recommended Validation Sources
              </h3>
              <div className="flex flex-wrap gap-2">
                {validationSources.map((v) => (
                  <span
                    key={v}
                    className="inline-flex items-center gap-1.5 text-xs font-mono text-body px-2.5 py-1.5 rounded-lg bg-bg-alt border border-default"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" strokeWidth={1.5} />
                    {v}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function InteractiveApp() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-10">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Interactive Application
            </p>
            <h2 className="font-serif text-section text-body text-balance mb-5">
              Explore the Interactive Analysis
            </h2>
            <p className="text-base text-muted leading-relaxed text-pretty">
              The Google Earth Engine application provides an interactive interface for exploring
              the satellite observations, derived water indicators, temporal change, terrain
              constraints, and potential inundation results.
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="relative rounded-5xl overflow-hidden surface-card">
            <div className="relative h-64 md:h-96 bg-gradient-to-br from-ocean-700 via-ocean-600 to-emerald-600 flex items-center justify-center">
              <div className="absolute inset-0 grain" />
              <div className="relative text-center px-6">
                <Satellite
                  className="w-12 h-12 text-warmwhite-100/80 mx-auto mb-4"
                  strokeWidth={1}
                />
                <p className="text-sm font-mono text-warmwhite-100/70 mb-6">
                  Google Earth Engine Application
                </p>
                <a
                  href={GEE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100 text-ocean-600 font-medium text-sm hover:bg-warmwhite-200 transition-all shadow-elevated"
                >
                  Explore Interactive Analysis
                  <ArrowUpRight className="w-4 h-4" strokeWidth={2} />
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function TechTags() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-8">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Technology
            </p>
            <h2 className="font-serif text-section text-body text-balance">Tools &amp; Methods</h2>
          </div>
        </Reveal>
        <Reveal delay={100}>
          <div className="flex flex-wrap gap-2">
            {techTags.map((tag) => (
              <span
                key={tag}
                className="text-xs font-mono text-body px-3 py-1.5 rounded-lg bg-surface border border-default"
              >
                {tag}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function FinalStatement() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="max-w-3xl mx-auto text-center">
            <p className="font-serif text-hero text-body text-balance leading-snug">
              "This analysis demonstrates how Earth Observation data can be transformed into a
              rapid, reproducible workflow for identifying areas that may warrant further
              investigation during flood events."
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
