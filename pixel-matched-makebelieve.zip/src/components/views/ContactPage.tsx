import { useState, type FormEvent } from "react";
import { Mail, MapPin, Send, CheckCircle2, Github, Linkedin } from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="pt-24">
      <section className="py-16 md:py-20 border-b border-default">
        <div className="container-page">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Contact
            </p>
            <h1 className="font-serif text-display text-body text-balance max-w-3xl">
              Let's talk about Earth
            </h1>
            <p className="mt-6 text-lg text-muted leading-relaxed max-w-2xl text-pretty">
              Whether you're interested in collaboration, have a question about the research, or
              just want to connect — I'd love to hear from you.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 md:py-20">
        <div className="container-page">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5">
              <Reveal>
                <div className="space-y-6">
                  <div className="surface-card p-6 flex items-center gap-4">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center">
                      <Mail className="w-5 h-5 text-accent" strokeWidth={1.5} />
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted">
                        Email
                      </p>
                      <p className="text-sm text-body font-mono">Connect via LinkedIn</p>
                    </div>
                  </div>

                  <div className="surface-card p-6 flex items-center gap-4">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-accent" strokeWidth={1.5} />
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted">
                        Location
                      </p>
                      <p className="text-sm text-body">Hyderabad, India</p>
                    </div>
                  </div>

                  <div className="surface-card p-6">
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted mb-4">
                      Find me online
                    </p>
                    <div className="flex gap-3">
                      {[
                        { icon: Github, href: "https://github.com/Adivishnu1006", label: "GitHub" },
                        {
                          icon: Linkedin,
                          href: "https://www.linkedin.com/in/ledallaadi/",
                          label: "LinkedIn",
                        },
                      ].map(({ icon: Icon, href, label }) => (
                        <a
                          key={label}
                          href={href}
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label={label}
                          className="w-10 h-10 rounded-full bg-bg-alt border border-default flex items-center justify-center text-muted hover:text-accent hover:border-accent/30 transition-all"
                        >
                          <Icon className="w-4 h-4" strokeWidth={1.5} />
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>

            <div className="lg:col-span-7">
              <Reveal delay={100}>
                {submitted ? (
                  <div className="surface-card p-10 text-center h-full flex flex-col items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mb-5">
                      <CheckCircle2 className="w-8 h-8 text-emerald-500" strokeWidth={1.5} />
                    </div>
                    <h3 className="font-serif text-xl text-body mb-2">Message sent</h3>
                    <p className="text-sm text-muted max-w-sm text-pretty">
                      Thank you for reaching out. I'll get back to you as soon as possible.
                    </p>
                    <button
                      onClick={() => {
                        setSubmitted(false);
                        setForm({ name: "", email: "", subject: "", message: "" });
                      }}
                      className="mt-6 text-sm font-medium text-accent hover:underline"
                    >
                      Send another message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="surface-card p-7 md:p-8 space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <Field label="Name">
                        <input
                          required
                          type="text"
                          value={form.name}
                          onChange={(e) => setForm({ ...form, name: e.target.value })}
                          placeholder="Your name"
                          className="w-full px-4 py-3 rounded-xl bg-bg-alt border border-default text-body placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all text-sm"
                        />
                      </Field>
                      <Field label="Email">
                        <input
                          required
                          type="email"
                          value={form.email}
                          onChange={(e) => setForm({ ...form, email: e.target.value })}
                          placeholder="you@example.com"
                          className="w-full px-4 py-3 rounded-xl bg-bg-alt border border-default text-body placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all text-sm"
                        />
                      </Field>
                    </div>
                    <Field label="Subject">
                      <input
                        required
                        type="text"
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        placeholder="What's this about?"
                        className="w-full px-4 py-3 rounded-xl bg-bg-alt border border-default text-body placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all text-sm"
                      />
                    </Field>
                    <Field label="Message">
                      <textarea
                        required
                        rows={6}
                        value={form.message}
                        onChange={(e) => setForm({ ...form, message: e.target.value })}
                        placeholder="Tell me about your project, question, or idea..."
                        className="w-full px-4 py-3 rounded-xl bg-bg-alt border border-default text-body placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all text-sm resize-none"
                      />
                    </Field>
                    <button
                      type="submit"
                      className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-accent text-warmwhite-100 font-medium text-sm hover:opacity-90 transition-all shadow-soft w-full sm:w-auto"
                    >
                      Send Message
                      <Send
                        className="w-4 h-4 transition-transform group-hover:translate-x-0.5"
                        strokeWidth={2}
                      />
                    </button>
                  </form>
                )}
              </Reveal>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold uppercase tracking-wider text-muted mb-2">
        {label}
      </label>
      {children}
    </div>
  );
}
