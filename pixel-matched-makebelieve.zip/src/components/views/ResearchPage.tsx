import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Search, Layers, ArrowUpRight } from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";
import { projects } from "@/data/content";

export function ResearchPage() {
  const categories = ["All", ...Array.from(new Set(projects.map((p) => p.category)))];
  const [filter, setFilter] = useState("All");
  const [query, setQuery] = useState("");

  const filtered = projects.filter((p) => {
    const matchesCat = filter === "All" || p.category === filter;
    const matchesQuery =
      query === "" ||
      p.title.toLowerCase().includes(query.toLowerCase()) ||
      p.subtitle.toLowerCase().includes(query.toLowerCase()) ||
      p.tools.some((t) => t.toLowerCase().includes(query.toLowerCase()));
    return matchesCat && matchesQuery;
  });

  return (
    <div className="pt-24">
      <section className="py-16 md:py-20 border-b border-default">
        <div className="container-page">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Research
            </p>
            <h1 className="font-serif text-display text-body text-balance max-w-3xl">
              GIS and Earth Observation projects
            </h1>
            <p className="mt-6 text-lg text-muted leading-relaxed max-w-2xl text-pretty">
              A collection of projects built using Google Earth Engine, QGIS, Remote Sensing, and
              Python. Each project applies spatial analysis and satellite data to answer a
              scientific question about Earth's systems.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-12">
        <div className="container-page">
          <Reveal>
            <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between mb-10">
              <div className="flex flex-wrap gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setFilter(cat)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      filter === cat
                        ? "bg-accent text-warmwhite-100"
                        : "surface-card text-muted hover:text-body"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="relative md:w-64">
                <Search
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted"
                  strokeWidth={1.5}
                />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search projects..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-full text-sm bg-bg-alt border border-default text-body placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
                />
              </div>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filtered.map((p, i) => {
              const card = (
                <div className="group block surface-card overflow-hidden hover:shadow-card transition-all duration-500 h-full flex flex-col">
                  <div className="relative h-56 overflow-hidden">
                    <img
                      src={p.image}
                      alt={p.title}
                      loading="lazy"
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/50 to-transparent" />
                    <div className="absolute bottom-4 left-5 right-5 flex items-center justify-between">
                      <span className="text-xs font-medium text-warmwhite-100 bg-ocean-900/40 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        {p.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-7 flex-1 flex flex-col">
                    <h3 className="font-serif text-xl text-body mb-2 group-hover:text-accent transition-colors">
                      {p.title}
                    </h3>
                    <p className="text-sm text-muted leading-relaxed line-clamp-2 mb-4">
                      {p.description}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {p.tools.map((tool) => (
                        <span
                          key={tool}
                          className="text-[11px] font-mono text-muted px-2 py-1 rounded-md bg-bg-alt"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                    {p.caseStudySlug && (
                      <span className="inline-flex items-center gap-1.5 text-sm font-medium text-accent mt-auto">
                        Explore Case Study
                        <ArrowUpRight className="w-4 h-4" strokeWidth={2} />
                      </span>
                    )}
                  </div>
                </div>
              );
              return (
                <Reveal key={p.id} delay={i * 80}>
                  {p.caseStudySlug ? (
                    <Link
                      to="/research/$slug"
                      params={{ slug: p.caseStudySlug }}
                      className="block h-full"
                    >
                      {card}
                    </Link>
                  ) : (
                    card
                  )}
                </Reveal>
              );
            })}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-20">
              <Layers className="w-10 h-10 text-muted mx-auto mb-4" strokeWidth={1} />
              <p className="text-muted">No projects match your search.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
