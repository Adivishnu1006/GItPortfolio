import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  CheckCircle2,
  Briefcase,
  Target,
  Satellite,
  Code2,
  BarChart3,
  Map,
  Eye,
  Workflow,
} from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";
import {
  experiences,
  skillGroups,
  currentFocus,
  resumeSummary,
  education,
  achievements,
} from "@/data/content";

const focusIcons: Record<string, typeof Satellite> = {
  "Google Earth Engine": Satellite,
  "Remote Sensing": Satellite,
  "Climate Data Analysis": BarChart3,
  "GIS Development": Code2,
  "Earth Observation": Eye,
  "Scientific Visualization": Map,
  "Living Earth Research Initiative": Workflow,
};

export function AboutPage() {
  return (
    <div className="pt-24">
      <Hero />
      <Journey />
      <CurrentFocusSection />
      <ExperienceSection />
      <SkillsSection />
      <CtaBand />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative py-20 md:py-28 grain">
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(https://images.pexels.com/photos/1310757/pexels-photo-1310757.jpeg?auto=compress&cs=tinysrgb&w=1920)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ocean-900/70 via-ocean-900/50 to-bg dark:from-slate-900/80 dark:via-slate-900/60 dark:to-slate-900" />
      </div>

      <div className="container-page relative">
        <div className="max-w-3xl">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-warmwhite-100/90 mb-5">
              About
            </p>
            <h1 className="font-serif text-display text-warmwhite-100 text-balance">
              Understanding Earth as one connected system
            </h1>
            <p className="mt-7 text-lg text-warmwhite-100/80 leading-relaxed text-pretty">
              I am a Mapping Operator currently working at Wipro, where I work with mapping
              workflows, spatial data validation, satellite imagery interpretation, feature editing,
              topology validation, and geospatial quality assurance. Alongside my professional work,
              I am continuously learning and building projects using Google Earth Engine, QGIS,
              Remote Sensing, Earth Observation, Python, and JavaScript.
            </p>
            <p className="mt-5 text-lg text-warmwhite-100/80 leading-relaxed text-pretty">
              My long-term goal is to become a GIS Developer and Earth Observation Engineer by
              combining technical skills with scientific storytelling. Instead of simply making
              maps, I enjoy understanding how Earth's systems are connected through climate,
              atmosphere, oceans, vegetation, hydrology, and human activity. I believe GIS is not
              only about visualization but about answering scientific questions through spatial
              data.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Journey() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <Reveal>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
                My Journey
              </p>
              <h2 className="font-serif text-section text-body text-balance">
                From mapping operator to Earth Observation engineer
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-7">
            <Reveal delay={100}>
              <p className="text-lg text-muted leading-relaxed text-pretty mb-6">
                I started in GIS as a mapping operator, working with spatial data every day —
                validating features, interpreting satellite imagery, and ensuring geospatial
                quality. But the more I worked with Earth data, the more I wanted to understand the
                science behind it.
              </p>
              <p className="text-base text-muted leading-relaxed text-pretty mb-6">
                That curiosity led me to the Living Earth initiative — a long-term research project
                exploring how Earth's systems are connected. Each episode traces a thread from one
                system to the next, from the warmth of the Pacific Ocean to the monsoon that
                sustains a billion people.
              </p>
              <p className="text-base text-muted leading-relaxed text-pretty">
                Today, I combine my professional GIS work with independent research using Google
                Earth Engine, ERA5 Reanalysis, and satellite remote sensing. I publish my findings
                as technical articles and build tools that make Earth data accessible and
                meaningful.
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function CurrentFocusSection() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Current Focus
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              What I'm working on right now
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {currentFocus.map((item, i) => {
            const Icon = focusIcons[item] ?? Target;
            return (
              <Reveal key={item} delay={i * 80}>
                <div className="surface-card p-6 h-full hover:shadow-card transition-shadow duration-500 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5 text-accent" strokeWidth={1.5} />
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" strokeWidth={2} />
                    <span className="text-sm font-medium text-body">{item}</span>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function ExperienceSection() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Experience
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Professional background
            </h2>
          </div>
        </Reveal>

        <div className="space-y-6 max-w-3xl">
          {experiences.map((exp, i) => (
            <Reveal key={exp.id} delay={i * 120}>
              <div className="surface-card p-7">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center">
                      <Briefcase className="w-5 h-5 text-accent" strokeWidth={1.5} />
                    </div>
                    <div>
                      <h3 className="font-serif text-lg text-body">{exp.role}</h3>
                      <p className="text-sm text-muted">{exp.company}</p>
                    </div>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-medium ${
                      exp.current
                        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                        : "bg-slate-300/20 text-slate-500"
                    }`}
                  >
                    {exp.period}
                  </span>
                </div>
                {exp.responsibilities.length > 0 && (
                  <ul className="space-y-2 mt-4">
                    {exp.responsibilities.map((r) => (
                      <li key={r} className="flex items-center gap-2.5 text-sm text-muted">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent shrink-0" />
                        {r}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function SkillsSection() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="max-w-2xl mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
              Skills
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Tools and technologies
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {skillGroups.map((group, i) => (
            <Reveal key={group.category} delay={i * 80}>
              <div className="surface-card p-6 h-full">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-accent mb-4">
                  {group.category}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {group.skills.map((skill) => (
                    <span
                      key={skill}
                      className="text-xs font-mono text-body px-2.5 py-1.5 rounded-lg bg-bg-alt border border-default"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function CtaBand() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="relative rounded-5xl overflow-hidden grain">
            <div className="absolute inset-0 bg-gradient-to-br from-forest-500 via-moss-500 to-sand-400" />
            <div className="relative px-8 py-14 md:px-16 md:py-16 text-center">
              <h2 className="font-serif text-section text-warmwhite-100 text-balance max-w-2xl mx-auto">
                Want to collaborate on Earth Observation research?
              </h2>
              <Link
                to="/contact"
                className="mt-8 inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100 text-forest-600 font-medium text-sm hover:bg-warmwhite-200 transition-all shadow-elevated"
              >
                Get in Touch
                <ArrowRight className="w-4 h-4" strokeWidth={2} />
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
