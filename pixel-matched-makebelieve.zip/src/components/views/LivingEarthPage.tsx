import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowDown,
  Compass,
  Target,
  Telescope,
  GitBranch,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  Eye,
  Globe,
  Workflow,
  Sparkles,
  Satellite,
  CloudRain,
  Trees,
  Droplets,
  Thermometer,
  Mountain,
  Users,
} from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";
import { completedEpisodes, upcomingEpisodes, earthSystemChain } from "@/data/content";

const chainIcons: Record<string, typeof Globe> = {
  "Ocean Temperature": Satellite,
  "El Niño": Compass,
  "Atmospheric Moisture": CloudRain,
  Rainfall: CloudRain,
  Vegetation: Trees,
  Hydrology: Droplets,
  "Human Systems": Users,
};

export function LivingEarthPage() {
  return (
    <div className="pt-24">
      <Hero />
      <Vision />
      <Mission />
      <SystemChain />
      <Episodes />
      <UpcomingSection />
      <Roadmap />
      <Philosophy />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative min-h-[70vh] flex items-center py-20 grain">
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(https://images.pexels.com/photos/30596214/pexels-photo-30596214.jpeg?auto=compress&cs=tinysrgb&w=1920)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ocean-900/70 via-ocean-900/50 to-bg dark:from-slate-900/80 dark:via-slate-900/60 dark:to-slate-900" />
      </div>

      <div className="container-page relative">
        <div className="max-w-3xl">
          <Reveal>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-warmwhite-100/10 backdrop-blur-md border border-warmwhite-100/20 mb-7">
              <Compass className="w-3.5 h-3.5 text-sand-300" strokeWidth={1.5} />
              <span className="text-xs font-medium text-warmwhite-100 tracking-wide">
                A Long-Term Research Initiative
              </span>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <h1 className="font-serif text-display text-warmwhite-100 text-balance">
              Living Earth
            </h1>
          </Reveal>
          <Reveal delay={200}>
            <p className="mt-6 text-lg text-warmwhite-100/80 leading-relaxed max-w-xl text-pretty">
              An Earth Observation initiative exploring how Earth's interconnected systems function
              using GIS, Remote Sensing, Google Earth Engine, Python, AI, and Geospatial Analysis.
              This is not a collection of projects — it is one continuous story about how Earth's
              systems connect, influence, and sustain each other.
            </p>
          </Reveal>
          <Reveal delay={300}>
            <div className="mt-8 flex items-center gap-3">
              <span className="px-3 py-1.5 rounded-full text-xs font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                2 Episodes Completed
              </span>
              <span className="px-3 py-1.5 rounded-full text-xs font-medium bg-warmwhite-100/10 text-warmwhite-100/70 border border-warmwhite-100/20">
                6 Episodes Planned
              </span>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Vision() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <Reveal>
              <div className="inline-flex items-center gap-2 mb-5">
                <Eye className="w-4 h-4 text-accent" strokeWidth={1.5} />
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                  Vision
                </p>
              </div>
              <h2 className="font-serif text-section text-body text-balance">
                To see Earth not as isolated parts, but as one living system.
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-7">
            <Reveal delay={100}>
              <p className="text-lg text-muted leading-relaxed text-pretty mb-6">
                Modern science often studies Earth in fragments — the ocean here, the atmosphere
                there, the biosphere somewhere else. But Earth does not work in fragments. Every
                part is connected to every other part through flows of energy, water, carbon, and
                life.
              </p>
              <p className="text-base text-muted leading-relaxed text-pretty">
                Living Earth is my attempt to document these connections through a series of
                research episodes. Each episode focuses on one system, but always in relation to the
                next — tracing the thread from the warmth of the ocean to the resilience of human
                communities.
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function Mission() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <Reveal>
              <div className="inline-flex items-center gap-2 mb-5">
                <Target className="w-4 h-4 text-accent" strokeWidth={1.5} />
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                  Mission
                </p>
              </div>
              <h2 className="font-serif text-section text-body text-balance">
                Use satellite data and geospatial analysis to answer scientific questions about
                Earth.
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-7">
            <Reveal delay={100}>
              <p className="text-lg text-muted leading-relaxed text-pretty mb-6">
                Every episode follows the same approach: identify a scientific question, find the
                right satellite dataset, build a reproducible workflow in Google Earth Engine or
                Python, and communicate the results as a clear, visual story.
              </p>
              <p className="text-base text-muted leading-relaxed text-pretty">
                The mission is not just to make maps, but to answer questions: How does El Niño
                affect the Indian Monsoon? Where do atmospheric rivers carry water? How does
                vegetation respond to changing rainfall? Each answer adds one more piece to the
                picture of Earth as a connected system.
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function SystemChain() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
              The Thread
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Every system links naturally to the next
            </h2>
            <p className="mt-5 text-muted text-pretty">
              Follow the chain from the heat of the ocean to the systems that sustain human life.
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="flex flex-wrap items-center justify-center gap-3 md:gap-4">
            {earthSystemChain.map((item, i) => {
              const Icon = chainIcons[item.label] ?? Globe;
              return (
                <div key={item.label} className="flex items-center gap-3 md:gap-4">
                  <div className="group relative px-4 py-3 md:px-5 md:py-4 rounded-2xl surface-card hover:shadow-card transition-all duration-500 cursor-default flex items-center gap-3">
                    <Icon className="w-4 h-4 text-accent" strokeWidth={1.5} />
                    <span className="text-sm font-medium text-body whitespace-nowrap">
                      {item.label}
                    </span>
                  </div>
                  {i < earthSystemChain.length - 1 && (
                    <ArrowDown
                      className="w-4 h-4 text-accent rotate-[-90deg] shrink-0 hidden sm:block"
                      strokeWidth={1.5}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Episodes() {
  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
              Episodes
            </p>
            <h2 className="font-serif text-section text-body text-balance">Completed research</h2>
          </div>
        </Reveal>

        <div className="space-y-8 max-w-5xl mx-auto">
          {completedEpisodes.map((ep, i) => (
            <Reveal key={ep.id} delay={i * 100}>
              <div className="surface-card overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-2/5 relative overflow-hidden h-56 md:h-auto">
                    <img
                      src={ep.image}
                      alt={ep.title}
                      loading="lazy"
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/60 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="text-xs font-mono text-warmwhite-100 bg-ocean-900/40 backdrop-blur-sm px-2.5 py-1 rounded-full">
                        {ep.number}
                      </span>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 backdrop-blur-sm">
                        <CheckCircle2 className="w-3 h-3" strokeWidth={2} />
                        Completed
                      </span>
                    </div>
                  </div>
                  <div className="md:w-3/5 p-7 md:p-8">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-accent">
                      {ep.system}
                    </span>
                    <h3 className="font-serif text-xl text-body mt-2 mb-2">{ep.title}</h3>
                    <p className="text-sm text-muted leading-relaxed mb-4">{ep.summary}</p>
                    <p className="text-xs text-muted font-mono mb-5">{ep.date}</p>
                    {ep.links && (
                      <div className="flex flex-wrap gap-2">
                        {ep.links.map((link) => (
                          <a
                            key={link.label}
                            href={link.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-xs font-medium text-accent px-3 py-1.5 rounded-full border border-accent/20 hover:bg-accent/8 transition-all"
                          >
                            {link.label}
                            <ArrowUpRight className="w-3 h-3" strokeWidth={2} />
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Roadmap() {
  const phases = [
    {
      icon: Telescope,
      title: "Phase 1 — Foundation",
      text: "Episodes 01–02: Ocean temperature, El Niño, and atmospheric moisture. Establishing the physical basis of the climate chain.",
      status: "complete",
    },
    {
      icon: Target,
      title: "Phase 2 — Land Response",
      text: "Episodes 03–04: Rainfall and vegetation. How the atmosphere delivers water and how ecosystems respond.",
      status: "planned",
    },
    {
      icon: GitBranch,
      title: "Phase 3 — Human Connection",
      text: "Episodes 05–08: Hydrology, land surface temperature, geosphere, and human systems. Where natural systems meet society.",
      status: "planned",
    },
  ];

  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
              Roadmap
            </p>
            <h2 className="font-serif text-section text-body text-balance">
              Where the initiative stands today
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {phases.map((p, i) => (
            <Reveal key={p.title} delay={i * 120}>
              <div className="surface-card p-7 h-full">
                <div className="flex items-center justify-between mb-5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center">
                    <p.icon className="w-5 h-5 text-accent" strokeWidth={1.5} />
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-medium ${
                      p.status === "complete"
                        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                        : "bg-slate-300/20 text-slate-500"
                    }`}
                  >
                    {p.status === "complete" ? "Complete" : "Planned"}
                  </span>
                </div>
                <h3 className="font-serif text-lg text-body mb-3">{p.title}</h3>
                <p className="text-sm text-muted leading-relaxed">{p.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function UpcomingSection() {
  const upcomingIcons: Record<string, typeof Globe> = {
    Rainfall: CloudRain,
    Vegetation: Trees,
    Hydrology: Droplets,
    "Land Surface Temperature": Thermometer,
    Geosphere: Mountain,
    "Human Systems": Users,
  };

  return (
    <section className="py-24 md:py-28 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
              Upcoming Episodes
            </p>
            <h2 className="font-serif text-section text-body text-balance">Planned research</h2>
            <p className="mt-5 text-muted text-pretty">
              These episodes are planned as future research. No pages yet — just the vision of what
              comes next.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {upcomingEpisodes.map((ep, i) => {
            const Icon = upcomingIcons[ep.title] ?? Clock;
            return (
              <Reveal key={ep.id} delay={i * 80}>
                <div className="surface-card p-6 h-full opacity-80">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-bg-alt flex items-center justify-center">
                      <Icon className="w-5 h-5 text-muted" strokeWidth={1.5} />
                    </div>
                    <span className="text-[10px] font-mono text-muted">{ep.number}</span>
                  </div>
                  <h3 className="font-serif text-base text-body mb-1">{ep.title}</h3>
                  <p className="text-xs text-muted leading-relaxed mb-4">{ep.subtitle}</p>
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium bg-slate-300/20 text-slate-500">
                    <Clock className="w-3 h-3" strokeWidth={1.5} />
                    Coming Soon
                  </span>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Philosophy() {
  return (
    <section className="py-24 md:py-28">
      <div className="container-page">
        <Reveal>
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
              Research Philosophy
            </p>
            <h2 className="font-serif text-section text-body text-balance mb-8">
              Science should be open, connected, and honest about what it does not yet know.
            </h2>
            <div className="space-y-6 text-left">
              {[
                {
                  title: "Open by default",
                  text: "Research built on open data, open source tools, and open communication of methods and results.",
                },
                {
                  title: "Systems thinking",
                  text: "No system studied in isolation. Every episode connects to the next, forming a coherent picture.",
                },
                {
                  title: "Honest uncertainty",
                  text: "Every finding comes with its confidence interval. Uncertainty is not a weakness — it is the shape of knowledge.",
                },
                {
                  title: "Reproducibility first",
                  text: "Every workflow documented, every dataset cited, every result verifiable by anyone who follows the path.",
                },
              ].map((item) => (
                <div key={item.title} className="flex gap-5 items-start">
                  <div className="w-1 h-full min-h-[3rem] rounded-full bg-gradient-to-b from-ocean-500 to-emerald-500 shrink-0 mt-1" />
                  <div>
                    <h3 className="font-serif text-lg text-body mb-1">{item.title}</h3>
                    <p className="text-sm text-muted leading-relaxed text-pretty">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
