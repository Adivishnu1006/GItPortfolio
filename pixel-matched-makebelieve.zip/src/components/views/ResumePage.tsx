import {
  Download,
  Briefcase,
  GraduationCap,
  Award,
  User,
  FileText,
  ArrowUpRight,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";
import {
  resumeSummary,
  experiences,
  skillGroups,
  education,
  achievements,
  projects,
} from "@/data/content";
import resumeAsset from "@/assets/resume.docx.asset.json";

export function ResumePage() {
  return (
    <div className="pt-24">
      <section className="py-16 md:py-20 border-b border-default">
        <div className="container-page">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
            <Reveal>
              <div className="max-w-2xl">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
                  Resume
                </p>
                <h1 className="font-serif text-display text-body text-balance">
                  Ledalla Naga Sai Adivishnu
                </h1>
                <p className="mt-4 text-lg text-muted leading-relaxed text-pretty">
                  Mapping Operator at Wipro · Earth Observation Researcher
                </p>
              </div>
            </Reveal>
            <Reveal delay={100}>
              <a
                href={resumeAsset.url}
                download
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-accent text-warmwhite-100 font-medium text-sm hover:opacity-90 transition-all shadow-elevated"
              >
                <Download className="w-4 h-4" strokeWidth={2} />
                Download Resume
              </a>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container-page">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-8 space-y-16">
              <SummarySection />
              <ExperienceSection />
              <ProjectsSection />
            </div>
            <div className="lg:col-span-4 space-y-16">
              <SkillsSection />
              <EducationSection />
              <AchievementsSection />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function SummarySection() {
  return (
    <div>
      <Reveal>
        <h2 className="font-serif text-xl text-body mb-5 flex items-center gap-3">
          <User className="w-5 h-5 text-accent" strokeWidth={1.5} />
          Professional Summary
        </h2>
        <p className="text-base text-muted leading-relaxed text-pretty">{resumeSummary}</p>
      </Reveal>
    </div>
  );
}

function ExperienceSection() {
  return (
    <div>
      <Reveal>
        <h2 className="font-serif text-xl text-body mb-6 flex items-center gap-3">
          <Briefcase className="w-5 h-5 text-accent" strokeWidth={1.5} />
          Experience
        </h2>
      </Reveal>
      <div className="space-y-5">
        {experiences.map((exp, i) => (
          <Reveal key={exp.id} delay={i * 100}>
            <div className="surface-card p-6">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-serif text-lg text-body">{exp.role}</h3>
                  <p className="text-sm text-accent">{exp.company}</p>
                </div>
                <span
                  className={`px-2.5 py-1 rounded-full text-[10px] font-medium ${
                    exp.current
                      ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                      : "bg-slate-300/20 text-slate-500"
                  }`}
                >
                  {exp.period}
                </span>
              </div>
              {exp.responsibilities.length > 0 && (
                <ul className="space-y-2 mt-4">
                  {exp.responsibilities.map((r) => (
                    <li key={r} className="flex items-center gap-2.5 text-sm text-muted">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent shrink-0" />
                      {r}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  );
}

function ProjectsSection() {
  return (
    <div>
      <Reveal>
        <h2 className="font-serif text-xl text-body mb-6 flex items-center gap-3">
          <FileText className="w-5 h-5 text-accent" strokeWidth={1.5} />
          Selected Projects
        </h2>
      </Reveal>
      <div className="space-y-3">
        {projects.map((p, i) => (
          <Reveal key={p.id} delay={i * 60}>
            <div className="surface-card p-5 flex items-center gap-4 hover:shadow-card transition-all duration-500">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center shrink-0">
                <span className="text-xs font-mono text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-serif text-base text-body">{p.title}</h3>
                <p className="text-xs text-muted truncate">{p.subtitle}</p>
              </div>
              <span className="text-[10px] font-mono text-muted px-2 py-1 rounded-md bg-bg-alt hidden sm:block">
                {p.category}
              </span>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  );
}

function SkillsSection() {
  return (
    <div>
      <Reveal>
        <h2 className="font-serif text-xl text-body mb-6">Skills</h2>
        <div className="space-y-5">
          {skillGroups.map((group) => (
            <div key={group.category}>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-accent mb-3">
                {group.category}
              </h3>
              <div className="flex flex-wrap gap-2">
                {group.skills.map((skill) => (
                  <span
                    key={skill}
                    className="text-xs font-mono text-body px-2.5 py-1.5 rounded-lg bg-bg-alt border border-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Reveal>
    </div>
  );
}

function EducationSection() {
  return (
    <div>
      <Reveal>
        <h2 className="font-serif text-xl text-body mb-6 flex items-center gap-3">
          <GraduationCap className="w-5 h-5 text-accent" strokeWidth={1.5} />
          Education
        </h2>
        <div className="space-y-4">
          {education.map((edu) => (
            <div key={edu.id} className="surface-card p-5">
              <h3 className="font-serif text-base text-body">{edu.degree}</h3>
              <p className="text-sm text-muted mt-1">{edu.institution}</p>
            </div>
          ))}
        </div>
      </Reveal>
    </div>
  );
}

function AchievementsSection() {
  return (
    <div>
      <Reveal>
        <h2 className="font-serif text-xl text-body mb-6 flex items-center gap-3">
          <Award className="w-5 h-5 text-accent" strokeWidth={1.5} />
          Achievements
        </h2>
        <ul className="space-y-3">
          {achievements.map((a) => (
            <li key={a} className="flex items-start gap-3 text-sm text-muted leading-relaxed">
              <CheckCircle2
                className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5"
                strokeWidth={1.5}
              />
              <span className="text-pretty">{a}</span>
            </li>
          ))}
        </ul>
      </Reveal>
    </div>
  );
}
