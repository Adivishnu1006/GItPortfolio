import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  Satellite,
  Layers,
  Sparkles,
  BookOpen,
  Compass,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { Reveal } from "@/components/portfolio/Reveal";
import {
  completedEpisodes,
  upcomingEpisodes,
  projects,
  articles,
  currentFocus,
} from "@/data/content";

export function HomePage() {
  return (
    <div className="overflow-hidden">
      <Hero />
      <Intro />
      <LivingEarthPreview />
      <ResearchPreview />
      <ArticlesPreview />
      <CtaBand />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-24 pb-16 grain">
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0 bg-cover bg-center animate-slow-pan"
          style={{
            backgroundImage:
              "url(https://images.pexels.com/photos/30596225/pexels-photo-30596225.jpeg?auto=compress&cs=tinysrgb&w=1920)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ocean-900/60 via-ocean-900/40 to-ocean-900/80 dark:from-slate-900/80 dark:via-slate-900/60 dark:to-slate-900/90" />
        <div className="absolute inset-0 bg-gradient-to-r from-ocean-900/50 to-transparent" />
      </div>

      <div className="container-page relative">
        <div className="max-w-3xl">
          <Reveal>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-warmwhite-100/10 backdrop-blur-md border border-warmwhite-100/20 mb-8">
              <Sparkles className="w-3.5 h-3.5 text-sand-300" strokeWidth={1.5} />
              <span className="text-xs font-medium text-warmwhite-100 tracking-wide">
                Earth Observation Research Lab
              </span>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <h1 className="font-serif text-display text-warmwhite-100 text-balance">
              Exploring Earth's interconnected systems through GIS, Remote Sensing, and scientific
              visualization
            </h1>
          </Reveal>

          <Reveal delay={250}>
            <p className="mt-7 text-lg text-warmwhite-100/80 leading-relaxed max-w-xl text-pretty">
              From ocean temperatures to atmospheric rivers, from vegetation patterns to human
              communities — this is a living record of how Earth's systems connect, influence, and
              sustain each other.
            </p>
          </Reveal>

          <Reveal delay={400}>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Link
                to="/living-earth"
                className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100 text-ocean-700 font-medium text-sm hover:bg-warmwhite-200 transition-all shadow-elevated"
              >
                Explore Living Earth
                <ArrowRight
                  className="w-4 h-4 transition-transform group-hover:translate-x-0.5"
                  strokeWidth={2}
                />
              </Link>
              <Link
                to="/research"
                className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100/10 backdrop-blur-md border border-warmwhite-100/25 text-warmwhite-100 font-medium text-sm hover:bg-warmwhite-100/15 transition-all"
              >
                View Research
                <ArrowUpRight
                  className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  strokeWidth={2}
                />
              </Link>
            </div>
          </Reveal>
        </div>
      </div>

      <div className="absolute bottom-8 left-0 right-0 flex justify-center">
        <div className="flex flex-col items-center gap-2 text-warmwhite-100/50">
          <span className="text-[10px] uppercase tracking-[0.2em]">Scroll</span>
          <div className="w-px h-12 bg-gradient-to-b from-warmwhite-100/40 to-transparent" />
        </div>
      </div>
    </section>
  );
}

function Intro() {
  const pillars = [
    {
      icon: Satellite,
      title: "Earth Observation",
      text: "Satellite missions that measure our planet every day, from ocean temperature to canopy health.",
    },
    {
      icon: Layers,
      title: "GIS & Spatial Analysis",
      text: "Geographic information systems that turn raw data into spatial understanding and answers.",
    },
    {
      icon: Sparkles,
      title: "Scientific Storytelling",
      text: "Communicating complex Earth science as clear, visual narratives that anyone can follow.",
    },
  ];

  return (
    <section className="py-24 md:py-32">
      <div className="container-page">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <Reveal>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-5">
                The Research
              </p>
              <h2 className="font-serif text-section text-body text-balance">
                Earth's systems are not separate. They are one continuous conversation.
              </h2>
            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <Reveal delay={100}>
              <p className="text-lg text-muted leading-relaxed text-pretty mb-8">
                The ocean warms. The atmosphere responds. Rainfall shifts. Vegetation changes. Water
                moves. Communities adapt. Each system speaks to the next in a chain that circles the
                planet. My work is to listen — and to map what I hear.
              </p>
            </Reveal>
            <Reveal delay={200}>
              <p className="text-base text-muted leading-relaxed text-pretty mb-12">
                Through satellite remote sensing, geographic information systems, and Google Earth
                Engine, I trace these connections from the top of the atmosphere to the roots of the
                soil. The result is not a collection of isolated projects, but a single evolving
                story about how Earth works.
              </p>
            </Reveal>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {pillars.map((p, i) => (
                <Reveal key={p.title} delay={300 + i * 100}>
                  <div className="surface-card p-6 h-full hover:shadow-card transition-shadow duration-500">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ocean-500/10 to-emerald-500/10 flex items-center justify-center mb-4">
                      <p.icon className="w-5 h-5 text-accent" strokeWidth={1.5} />
                    </div>
                    <h3 className="font-serif text-base font-medium text-body mb-2">{p.title}</h3>
                    <p className="text-sm text-muted leading-relaxed">{p.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function LivingEarthPreview() {
  return (
    <section className="py-24 md:py-32 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
                The Centerpiece
              </p>
              <h2 className="font-serif text-section text-body text-balance">
                Living Earth: an ongoing research initiative
              </h2>
            </div>
            <Link
              to="/living-earth"
              className="group inline-flex items-center gap-2 text-sm font-medium text-accent whitespace-nowrap"
            >
              Explore all episodes
              <ArrowRight
                className="w-4 h-4 transition-transform group-hover:translate-x-1"
                strokeWidth={2}
              />
            </Link>
          </div>
        </Reveal>

        <div className="relative">
          <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-ocean-300/40 via-emerald-300/40 to-sand-300/40 md:-translate-x-1/2" />

          <div className="space-y-12">
            {completedEpisodes.map((ep, i) => (
              <Reveal key={ep.id} delay={i * 80}>
                <div
                  className={`relative flex ${i % 2 === 0 ? "md:justify-start" : "md:justify-end"}`}
                >
                  <div className="absolute left-6 md:left-1/2 w-3 h-3 rounded-full bg-gradient-to-br from-ocean-500 to-emerald-500 ring-4 ring-bg-alt -translate-x-1/2 top-2" />
                  <Link
                    to="/living-earth"
                    className={`ml-14 md:ml-0 w-full md:w-[calc(50%-2.5rem)] surface-card overflow-hidden group hover:shadow-card transition-all duration-500 ${
                      i % 2 === 0 ? "md:mr-auto" : "md:ml-auto"
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row">
                      <div className="sm:w-2/5 relative overflow-hidden h-44 sm:h-auto">
                        <img
                          src={ep.image}
                          alt={ep.title}
                          loading="lazy"
                          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/40 to-transparent" />
                        <span className="absolute top-3 left-3 text-xs font-mono text-warmwhite-100 bg-ocean-900/40 backdrop-blur-sm px-2 py-1 rounded-full">
                          {ep.number}
                        </span>
                      </div>
                      <div className="sm:w-3/5 p-6">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-accent">
                          {ep.system}
                        </span>
                        <h3 className="font-serif text-xl text-body mt-2 mb-1">{ep.title}</h3>
                        <p className="text-sm text-muted leading-relaxed line-clamp-3">
                          {ep.description}
                        </p>
                        <div className="mt-4 flex items-center gap-3">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3 h-3" strokeWidth={2} />
                            Completed
                          </span>
                          <span className="text-xs text-muted font-mono">{ep.date}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={200}>
            <div className="mt-12 ml-14 md:ml-0 flex flex-wrap gap-3">
              {upcomingEpisodes.map((ep) => (
                <div
                  key={ep.id}
                  className="inline-flex items-center gap-2 px-3 py-2 rounded-full surface-card"
                >
                  <Clock className="w-3.5 h-3.5 text-muted" strokeWidth={1.5} />
                  <span className="text-xs text-muted">{ep.title}</span>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function ResearchPreview() {
  return (
    <section className="py-24 md:py-32">
      <div className="container-page">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
                Research Projects
              </p>
              <h2 className="font-serif text-section text-body text-balance">
                GIS and Earth Observation projects
              </h2>
            </div>
            <Link
              to="/research"
              className="group inline-flex items-center gap-2 text-sm font-medium text-accent whitespace-nowrap"
            >
              View all projects
              <ArrowRight
                className="w-4 h-4 transition-transform group-hover:translate-x-1"
                strokeWidth={2}
              />
            </Link>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.slice(0, 3).map((p, i) => (
            <Reveal key={p.id} delay={i * 100}>
              <div className="group block surface-card overflow-hidden hover:shadow-card transition-all duration-500 h-full">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.title}
                    loading="lazy"
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/50 to-transparent" />
                  <span className="absolute top-3 left-3 text-xs font-medium text-warmwhite-100 bg-ocean-900/40 backdrop-blur-sm px-2.5 py-1 rounded-full">
                    {p.category}
                  </span>
                </div>
                <div className="p-6">
                  <h3 className="font-serif text-lg text-body mb-2 group-hover:text-accent transition-colors">
                    {p.title}
                  </h3>
                  <p className="text-sm text-muted leading-relaxed line-clamp-2 mb-4">
                    {p.subtitle}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {p.tools.slice(0, 3).map((tool) => (
                      <span
                        key={tool}
                        className="text-[10px] font-mono text-muted px-2 py-0.5 rounded-md bg-bg-alt"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ArticlesPreview() {
  return (
    <section className="py-24 md:py-32 bg-bg-alt grain">
      <div className="container-page">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent mb-4">
                Writing
              </p>
              <h2 className="font-serif text-section text-body text-balance">
                Published technical articles
              </h2>
            </div>
            <Link
              to="/articles"
              className="group inline-flex items-center gap-2 text-sm font-medium text-accent whitespace-nowrap"
            >
              Read all articles
              <ArrowRight
                className="w-4 h-4 transition-transform group-hover:translate-x-1"
                strokeWidth={2}
              />
            </Link>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {articles.map((article, i) => (
            <Reveal key={article.id} delay={i * 100}>
              <a
                href={article.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group block surface-card overflow-hidden hover:shadow-card transition-all duration-500 h-full"
              >
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={article.coverImage}
                    alt={article.title}
                    loading="lazy"
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/50 to-transparent" />
                  <span className="absolute top-3 left-3 text-xs font-medium text-warmwhite-100 bg-ocean-900/40 backdrop-blur-sm px-2.5 py-1 rounded-full">
                    {article.category}
                  </span>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-xs text-muted font-mono">{article.readingTime}</span>
                    <span className="text-xs text-muted font-mono">{article.date}</span>
                  </div>
                  <h3 className="font-serif text-lg text-body mb-3 group-hover:text-accent transition-colors leading-snug">
                    {article.title}
                  </h3>
                  <p className="text-sm text-muted leading-relaxed line-clamp-2">
                    {article.excerpt}
                  </p>
                  <div className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-accent">
                    Read Article
                    <ArrowUpRight
                      className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"
                      strokeWidth={2}
                    />
                  </div>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function CtaBand() {
  return (
    <section className="py-24 md:py-32">
      <div className="container-page">
        <Reveal>
          <div className="relative rounded-5xl overflow-hidden grain">
            <div className="absolute inset-0 bg-gradient-to-br from-ocean-500 via-ocean-400 to-emerald-500" />
            <div
              className="absolute inset-0 opacity-20 bg-cover bg-center"
              style={{
                backgroundImage:
                  "url(https://images.pexels.com/photos/1310757/pexels-photo-1310757.jpeg?auto=compress&cs=tinysrgb&w=1200)",
              }}
            />
            <div className="relative px-8 py-16 md:px-16 md:py-20 text-center">
              <h2 className="font-serif text-section text-warmwhite-100 text-balance max-w-2xl mx-auto">
                Every dataset tells a story about our planet. Let's read them together.
              </h2>
              <p className="mt-5 text-warmwhite-100/80 max-w-lg mx-auto text-pretty">
                Explore the Living Earth initiative, browse research projects, or get in touch about
                collaboration.
              </p>
              <div className="mt-9 flex flex-col sm:flex-row justify-center gap-4">
                <Link
                  to="/living-earth"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100 text-ocean-700 font-medium text-sm hover:bg-warmwhite-200 transition-all shadow-elevated"
                >
                  Explore Living Earth
                  <ArrowRight className="w-4 h-4" strokeWidth={2} />
                </Link>
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-warmwhite-100/10 backdrop-blur-md border border-warmwhite-100/25 text-warmwhite-100 font-medium text-sm hover:bg-warmwhite-100/15 transition-all"
                >
                  Get in Touch
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
