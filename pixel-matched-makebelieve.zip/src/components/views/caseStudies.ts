import type { ComponentType } from "react";
import { NepalFloodCaseStudy } from "@/components/views/NepalFloodCaseStudy";

export type CaseStudy = {
  component: ComponentType;
  title: string;
  description: string;
  heroImage: string;
};

/** Full case-study pages, keyed by the project's `caseStudySlug` in content.ts. */
export const caseStudies: Record<string, CaseStudy> = {
  "nepal-flood-response-mapping": {
    component: NepalFloodCaseStudy,
    title: "Nepal Flood Response Mapping — Case Study",
    description:
      "Satellite-based potential inundation analysis in the Bhote Koshi region of Nepal using Sentinel-2 imagery and Google Earth Engine.",
    heroImage:
      "https://images.pexels.com/photos/30462124/pexels-photo-30462124.jpeg?auto=compress&cs=tinysrgb&w=1920",
  },
};
