import { Link } from "@tanstack/react-router";
import { Globe, Mail, Github, Linkedin } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-default bg-bg-alt mt-32">
      <div className="container-page py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          <div className="md:col-span-5">
            <Link to="/" className="flex items-center gap-2.5 mb-5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-ocean-500 to-emerald-500 flex items-center justify-center">
                <Globe className="w-4.5 h-4.5 text-warmwhite-100" strokeWidth={1.5} />
              </div>
              <span className="font-serif text-lg font-medium text-body">
                Earth Observation Lab
              </span>
            </Link>
            <p className="text-sm text-muted leading-relaxed max-w-sm text-pretty">
              Exploring Earth’s interconnected systems through GIS, Remote Sensing, Earth
              Observation, and scientific visualization.
            </p>
          </div>

          <div className="md:col-span-4">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted mb-4">
              Explore
            </h4>
            <ul className="space-y-2.5">
              {(
                [
                  { label: "Earth Explorer", path: "/earth" },
                  { label: "Living Earth", path: "/living-earth" },
                  { label: "Research", path: "/research" },
                  { label: "Articles", path: "/articles" },
                  { label: "About", path: "/about" },
                  { label: "Resume", path: "/resume" },
                ] as const
              ).map((l) => (
                <li key={l.path}>
                  <Link
                    to={l.path}
                    className="text-sm text-body hover:text-accent transition-colors link-underline"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted mb-4">
              Connect
            </h4>
            <div className="flex gap-3">
              {[
                { icon: Mail, href: "/contact", label: "Email" },
                { icon: Github, href: "https://github.com/Adivishnu1006", label: "GitHub" },
                {
                  icon: Linkedin,
                  href: "https://www.linkedin.com/in/ledallaadi/",
                  label: "LinkedIn",
                },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-10 h-10 rounded-full surface-card flex items-center justify-center text-muted hover:text-accent hover:shadow-card transition-all"
                >
                  <Icon className="w-4 h-4" strokeWidth={1.5} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-default flex flex-col sm:flex-row justify-between gap-4">
          <p className="text-xs text-muted">
            © {new Date().getFullYear()} Ledalla Naga Sai Adivishnu. Exploring Earth’s
            interconnected systems.
          </p>
          <p className="text-xs text-muted">Built with open data and open source.</p>
        </div>
      </div>
    </footer>
  );
}
