import { Link, useLocation } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Globe, Menu, X } from "lucide-react";
import { navLinks } from "@/data/content";

export function Navigation() {
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-bg/85 backdrop-blur-xl border-b border-default"
          : "bg-transparent border-transparent"
      }`}
    >
      <nav className="container-page flex items-center justify-between h-16 md:h-18">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-ocean-500 to-emerald-500 flex items-center justify-center shadow-soft transition-transform group-hover:scale-105">
            <Globe className="w-4.5 h-4.5 text-warmwhite-100" strokeWidth={1.5} />
          </div>
          <span className="font-serif text-lg font-medium tracking-tight text-body">
            Earth Observation Lab
          </span>
        </Link>

        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => {
            const active = location.pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`px-3 py-2 text-sm font-medium rounded-full transition-all duration-300 ${
                  active ? "text-accent bg-accent/8" : "text-muted hover:text-body hover:bg-bg-alt"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setMenuOpen((o) => !o)}
            aria-label="Menu"
            className="lg:hidden w-9 h-9 rounded-full flex items-center justify-center text-body hover:bg-bg-alt transition-colors"
          >
            {menuOpen ? (
              <X className="w-5 h-5" strokeWidth={1.5} />
            ) : (
              <Menu className="w-5 h-5" strokeWidth={1.5} />
            )}
          </button>
        </div>
      </nav>

      <div
        className={`lg:hidden overflow-hidden transition-all duration-400 ${
          menuOpen ? "max-h-[28rem] border-b border-default" : "max-h-0"
        }`}
      >
        <div className="container-page py-4 flex flex-col gap-1 bg-bg/95 backdrop-blur-xl">
          {navLinks.map((link) => {
            const active = location.pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-2.5 text-sm font-medium rounded-xl transition-colors ${
                  active ? "text-accent bg-accent/8" : "text-muted hover:text-body hover:bg-bg-alt"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </div>
      </div>
    </header>
  );
}
