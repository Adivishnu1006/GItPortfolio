// ── Living Earth Episodes ──────────────────────────────────────────

export type Episode = {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  system: string;
  color: string;
  gradient: string;
  status: "completed" | "coming-soon";
  date: string;
  image: string;
  summary: string;
  links?: { label: string; href: string }[];
};

export const completedEpisodes: Episode[] = [
  {
    id: "el-nino-monitoring",
    number: "01",
    title: "Global El Niño Monitoring",
    subtitle: "Tracking Pacific Ocean SST anomalies and monsoon influence",
    description:
      "Investigating how Pacific Ocean sea surface temperature anomalies influence Earth\u2019s climate and the Indian Monsoon using NOAA OISST and Google Earth Engine.",
    system: "Ocean \u00b7 Atmosphere \u00b7 Monsoon",
    color: "#0F4C5C",
    gradient: "from-ocean-500 to-ocean-300",
    status: "completed",
    date: "2025",
    image:
      "https://images.pexels.com/photos/30596225/pexels-photo-30596225.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "El Ni\u00f1o is a periodic warming of the central and eastern equatorial Pacific that disrupts global weather patterns. This episode traces how sea surface temperature anomalies propagate through atmospheric teleconnections to influence the Indian Monsoon \u2014 affecting rainfall, agriculture, and water security for over a billion people.",
    links: [
      { label: "GitHub", href: "https://github.com/ledallaadi" },
      {
        label: "LinkedIn Article",
        href: "https://www.linkedin.com/pulse/ocean-controls-monsoon-tracking-el-ni%C3%B1os-influence-india-ledalla-ewlwf",
      },
    ],
  },
  {
    id: "water-highways",
    number: "02",
    title: "Earth\u2019s Water Highways",
    subtitle: "Mapping seasonal atmospheric moisture transport",
    description:
      "Visualizing seasonal atmospheric moisture transport using ERA5 Reanalysis and Google Earth Engine to understand Earth\u2019s invisible water highways.",
    system: "Atmosphere \u00b7 Hydrosphere",
    color: "#3F8398",
    gradient: "from-ocean-400 to-emerald-400",
    status: "completed",
    date: "2025",
    image:
      "https://images.pexels.com/photos/5493069/pexels-photo-5493069.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "Atmospheric rivers and moisture flux transport vast quantities of water vapor across the globe. Using ERA5 Reanalysis data processed through Google Earth Engine, this episode maps these invisible corridors and their seasonal patterns \u2014 revealing how the atmosphere moves water from ocean to land.",
    links: [
      { label: "GitHub", href: "https://github.com/ledallaadi" },
      {
        label: "LinkedIn Article",
        href: "https://www.linkedin.com/pulse/living-earth-episode-2-earths-water-highways-mapping-seasonal-kv2ef",
      },
    ],
  },
];

export const upcomingEpisodes: Episode[] = [
  {
    id: "rainfall",
    number: "03",
    title: "Rainfall",
    subtitle: "The pulse of the land",
    description:
      "Analyzing satellite-based rainfall estimates (GPM IMERG) to understand spatial and temporal variability of precipitation patterns.",
    system: "Hydrosphere",
    color: "#2E8B57",
    gradient: "from-emerald-500 to-forest-500",
    status: "coming-soon",
    date: "Planned",
    image:
      "https://images.pexels.com/photos/6078836/pexels-photo-6078836.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "How the atmosphere delivers water to Earth\u2019s surface, and what satellite rainfall data reveals about changing precipitation patterns.",
  },
  {
    id: "vegetation",
    number: "04",
    title: "Vegetation",
    subtitle: "The green mirror",
    description:
      "Monitoring vegetation indices (NDVI, EVI) to reveal how ecosystems respond to water availability and climatic change.",
    system: "Biosphere",
    color: "#3A7D44",
    gradient: "from-forest-500 to-moss-500",
    status: "coming-soon",
    date: "Planned",
    image:
      "https://images.pexels.com/photos/32077731/pexels-photo-32077731.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "Vegetation is Earth\u2019s mirror \u2014 reflecting the combined effects of rainfall, temperature, and human activity.",
  },
  {
    id: "hydrology",
    number: "05",
    title: "Hydrology",
    subtitle: "Water across the land",
    description:
      "Tracing surface water, soil moisture, and groundwater through watersheds using satellite missions and geospatial analysis.",
    system: "Hydrosphere \u00b7 Land",
    color: "#7A9E7E",
    gradient: "from-moss-500 to-sand-400",
    status: "coming-soon",
    date: "Planned",
    image:
      "https://images.pexels.com/photos/32395648/pexels-photo-32395648.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "Surface water, soil moisture, and groundwater form the terrestrial water cycle that sustains ecosystems and communities.",
  },
  {
    id: "land-surface-temperature",
    number: "06",
    title: "Land Surface Temperature",
    subtitle: "Heat across the terrain",
    description:
      "Mapping land surface temperature from satellite thermal sensors to understand urban heat, drought, and thermal patterns.",
    system: "Geosphere \u00b7 Atmosphere",
    color: "#D9C7A3",
    gradient: "from-sand-400 to-ocean-400",
    status: "coming-soon",
    date: "Planned",
    image:
      "https://images.pexels.com/photos/12413177/pexels-photo-12413177.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "Land surface temperature reveals how heat is distributed across terrain \u2014 from urban heat islands to agricultural stress.",
  },
  {
    id: "geosphere",
    number: "07",
    title: "Geosphere",
    subtitle: "The solid Earth",
    description:
      "Exploring geological processes, landforms, tectonic activity, and Earth\u2019s surface dynamics through remote sensing.",
    system: "Geosphere",
    color: "#9E8A55",
    gradient: "from-sand-500 to-sand-300",
    status: "coming-soon",
    date: "Planned",
    image:
      "https://images.pexels.com/photos/5803272/pexels-photo-5803272.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "The solid Earth \u2014 its structure, processes, and surface dynamics \u2014 as seen from orbit.",
  },
  {
    id: "human-systems",
    number: "08",
    title: "Human Systems",
    subtitle: "Where Earth meets society",
    description:
      "Integrating socioeconomic data with Earth Observation to understand how natural systems shape agriculture, cities, and human resilience.",
    system: "Anthroposphere",
    color: "#0C3E4A",
    gradient: "from-ocean-600 to-ocean-400",
    status: "coming-soon",
    date: "Planned",
    image:
      "https://images.pexels.com/photos/30596313/pexels-photo-30596313.png?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "The final connection: how natural systems shape agriculture, cities, and human resilience.",
  },
];

export const allEpisodes = [...completedEpisodes, ...upcomingEpisodes];

// ── Earth System Chain ─────────────────────────────────────────────

export const earthSystemChain = [
  { label: "Ocean Temperature", icon: "ocean" },
  { label: "El Ni\u00f1o", icon: "wave" },
  { label: "Atmospheric Moisture", icon: "cloud" },
  { label: "Rainfall", icon: "rain" },
  { label: "Vegetation", icon: "leaf" },
  { label: "Hydrology", icon: "water" },
  { label: "Human Systems", icon: "people" },
];

// ── Research Projects ──────────────────────────────────────────────

export type Project = {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: string;
  image: string;
  description: string;
  tools: string[];
  caseStudySlug?: string;
};

export const projects: Project[] = [
  {
    id: "1",
    slug: "global-el-nino-monitoring",
    title: "Global El Ni\u00f1o Monitoring",
    subtitle: "Pacific SST anomalies and Indian Monsoon teleconnections",
    category: "Earth Observation",
    image:
      "https://images.pexels.com/photos/30596225/pexels-photo-30596225.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Investigating how Pacific Ocean sea surface temperature anomalies influence Earth\u2019s climate and the Indian Monsoon using NOAA OISST and Google Earth Engine.",
    tools: ["Google Earth Engine", "NOAA OISST", "Remote Sensing", "Python"],
  },
  {
    id: "2",
    slug: "earths-water-highways",
    title: "Earth\u2019s Water Highways",
    subtitle: "Seasonal atmospheric moisture transport visualization",
    category: "Earth Observation",
    image:
      "https://images.pexels.com/photos/5493069/pexels-photo-5493069.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Visualizing seasonal atmospheric moisture transport using ERA5 Reanalysis and Google Earth Engine to understand Earth\u2019s invisible water highways.",
    tools: ["Google Earth Engine", "ERA5 Reanalysis", "Python", "GIS"],
  },
  {
    id: "3",
    slug: "hyderabad-flood-mapping",
    title: "Hyderabad Flood Mapping",
    subtitle: "Spatial analysis of urban flood inundation",
    category: "GIS Analysis",
    image:
      "https://images.pexels.com/photos/28447761/pexels-photo-28447761.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Mapping flood inundation extent and affected zones in Hyderabad using satellite imagery and GIS spatial analysis techniques.",
    tools: ["QGIS", "Sentinel-1", "GIS Analysis", "Remote Sensing"],
  },
  {
    id: "4",
    slug: "ndvi-vegetation-analysis",
    title: "NDVI Vegetation Analysis",
    subtitle: "Normalized Difference Vegetation Index monitoring",
    category: "Remote Sensing",
    image:
      "https://images.pexels.com/photos/32077731/pexels-photo-32077731.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Analyzing vegetation health and density using NDVI derived from satellite imagery to monitor seasonal changes and long-term trends.",
    tools: ["Google Earth Engine", "Sentinel-2", "Remote Sensing", "Raster Analysis"],
  },
  {
    id: "5",
    slug: "era5-heat-pattern-analysis",
    title: "ERA5 Heat Pattern Analysis",
    subtitle: "Temperature pattern analysis using reanalysis data",
    category: "Climate Data Analysis",
    image:
      "https://images.pexels.com/photos/12413177/pexels-photo-12413177.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Analyzing temperature patterns and heat distribution using ERA5 reanalysis data to identify trends and anomalies in climate data.",
    tools: ["Google Earth Engine", "ERA5 Reanalysis", "Python", "Time-Series Analysis"],
  },
  {
    id: "6",
    slug: "telangana-land-cover-mapping",
    title: "Telangana Land Cover Mapping",
    subtitle: "Regional land cover classification",
    category: "GIS Analysis",
    image:
      "https://images.pexels.com/photos/38013987/pexels-photo-38013987.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Classifying and mapping land cover types across Telangana using satellite imagery and supervised classification techniques.",
    tools: ["QGIS", "Sentinel-2", "GIS Analysis", "Remote Sensing"],
  },
  {
    id: "7",
    slug: "forest-cover-analysis",
    title: "Forest Cover Analysis",
    subtitle: "Forest extent and change detection",
    category: "Remote Sensing",
    image:
      "https://images.pexels.com/photos/1310757/pexels-photo-1310757.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Analyzing forest cover extent and changes over time using satellite-derived vegetation indices and time-series analysis.",
    tools: ["Google Earth Engine", "Landsat", "Remote Sensing", "Time-Series Analysis"],
  },
  {
    id: "8",
    slug: "india-soil-types-mapping",
    title: "India Soil Types Mapping",
    subtitle: "Spatial distribution of soil types across India",
    category: "GIS Analysis",
    image:
      "https://images.pexels.com/photos/5803272/pexels-photo-5803272.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Mapping the spatial distribution of soil types across India using GIS data and satellite imagery to support agricultural planning.",
    tools: ["QGIS", "GIS Analysis", "Spatial Data", "Python"],
  },
  {
    id: "9",
    slug: "global-earthquake-analysis",
    title: "Global Earthquake Analysis",
    subtitle: "Seismic activity patterns and spatial distribution",
    category: "GIS Analysis",
    image:
      "https://images.pexels.com/photos/17511750/pexels-photo-17511750.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Analyzing global earthquake patterns, magnitudes, and spatial distribution using seismic data and GIS visualization techniques.",
    tools: ["QGIS", "GIS Analysis", "Spatial Data", "JavaScript"],
  },
  {
    id: "10",
    slug: "hyderabad-metro-restaurant-density",
    title: "Hyderabad Metro Restaurant Density Analysis",
    subtitle: "Urban density and spatial distribution patterns",
    category: "GIS Analysis",
    image:
      "https://images.pexels.com/photos/28349218/pexels-photo-28349218.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Analyzing restaurant density and distribution patterns across Hyderabad metro area using GIS spatial analysis and POI data.",
    tools: ["QGIS", "GIS Analysis", "Spatial Data", "SQL"],
  },
  {
    id: "11",
    slug: "nepal-flood-response-mapping",
    title: "Nepal Flood Response Mapping",
    subtitle:
      "Satellite-based potential inundation analysis in the Bhote Koshi region of Nepal using Sentinel-2 imagery and Google Earth Engine.",
    category: "Earth Observation",
    image:
      "https://images.pexels.com/photos/30462124/pexels-photo-30462124.jpeg?auto=compress&cs=tinysrgb&w=1200",
    description:
      "Satellite-based potential inundation analysis in the Bhote Koshi region of Nepal using Sentinel-2 imagery and Google Earth Engine.",
    tools: [
      "Google Earth Engine",
      "Sentinel-2",
      "MNDWI",
      "SRTM",
      "JRC Global Surface Water",
      "Remote Sensing",
    ],
    caseStudySlug: "nepal-flood-response-mapping",
  },
];

// ── Articles ───────────────────────────────────────────────────────

export type Article = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readingTime: string;
  coverImage: string;
  summary: string;
  linkedinUrl: string;
};

export const articles: Article[] = [
  {
    id: "1",
    slug: "ocean-controls-monsoon",
    title: "The Ocean Controls the Monsoon: Tracking El Ni\u00f1o\u2019s Influence on India",
    excerpt:
      "How Pacific Ocean sea surface temperature anomalies influence the Indian Monsoon \u2014 and why understanding this connection matters for a billion people.",
    category: "Earth Observation",
    date: "2025",
    readingTime: "8 min read",
    coverImage:
      "https://images.pexels.com/photos/30596225/pexels-photo-30596225.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "El Ni\u00f1o is more than a Pacific phenomenon. Its influence reaches across oceans and continents, shaping the monsoon that sustains India\u2019s agriculture and water security. This article traces the chain from ocean temperature to monsoon response using satellite data and Google Earth Engine.",
    linkedinUrl:
      "https://www.linkedin.com/pulse/ocean-controls-monsoon-tracking-el-ni%C3%B1os-influence-india-ledalla-ewlwf",
  },
  {
    id: "2",
    slug: "earths-water-highways",
    title: "Living Earth | Episode 2: Earth\u2019s Water Highways",
    excerpt:
      "Mapping seasonal atmospheric moisture transport using ERA5 Reanalysis and Google Earth Engine to understand Earth\u2019s invisible water highways.",
    category: "Earth Observation",
    date: "2025",
    readingTime: "7 min read",
    coverImage:
      "https://images.pexels.com/photos/5493069/pexels-photo-5493069.jpeg?auto=compress&cs=tinysrgb&w=1200",
    summary:
      "The atmosphere is a river system \u2014 not of liquid, but of vapor moving at highway speeds. This article explores how ERA5 Reanalysis data reveals Earth\u2019s atmospheric moisture corridors and their seasonal patterns.",
    linkedinUrl:
      "https://www.linkedin.com/pulse/living-earth-episode-2-earths-water-highways-mapping-seasonal-kv2ef",
  },
];

// ── Publications ────────────────────────────────────────────────────

export type Publication = {
  id: string;
  type: "Technical Article" | "Future Publication";
  title: string;
  description: string;
  year: string;
  status: "Published" | "Forthcoming";
  url?: string;
};

export const publications: Publication[] = [
  {
    id: "1",
    type: "Technical Article",
    title: "The Ocean Controls the Monsoon: Tracking El Ni\u00f1o\u2019s Influence on India",
    description:
      "A technical article exploring how Pacific Ocean sea surface temperature anomalies influence the Indian Monsoon, published on LinkedIn.",
    year: "2025",
    status: "Published",
    url: "https://www.linkedin.com/pulse/ocean-controls-monsoon-tracking-el-ni%C3%B1os-influence-india-ledalla-ewlwf",
  },
  {
    id: "2",
    type: "Technical Article",
    title: "Living Earth | Episode 2: Earth\u2019s Water Highways",
    description:
      "A technical article on visualizing seasonal atmospheric moisture transport using ERA5 Reanalysis and Google Earth Engine.",
    year: "2025",
    status: "Published",
    url: "https://www.linkedin.com/pulse/living-earth-episode-2-earths-water-highways-mapping-seasonal-kv2ef",
  },
  {
    id: "3",
    type: "Future Publication",
    title: "Living Earth: A Connected Atlas of Earth\u2019s Systems",
    description:
      "A planned longer-form publication synthesizing the Living Earth research initiative into a cohesive narrative about Earth\u2019s interconnected systems.",
    year: "Forthcoming",
    status: "Forthcoming",
  },
];

// ── Current Focus ──────────────────────────────────────────────────

export const currentFocus = [
  "Google Earth Engine",
  "Remote Sensing",
  "Climate Data Analysis",
  "GIS Development",
  "Earth Observation",
  "Scientific Visualization",
  "Living Earth Research Initiative",
];

// ── Experience ──────────────────────────────────────────────────────

export type Experience = {
  id: string;
  company: string;
  role: string;
  period: string;
  current: boolean;
  responsibilities: string[];
};

export const experiences: Experience[] = [
  {
    id: "1",
    company: "Wipro",
    role: "Mapping Operator",
    period: "Current",
    current: true,
    responsibilities: [
      "Mapping Workflows",
      "Spatial Data Validation",
      "Satellite Imagery Interpretation",
      "Feature Editing",
      "Topology Validation",
      "Geospatial Quality Assurance",
    ],
  },
  {
    id: "2",
    company: "TTEC",
    role: "Technical Support Analyst",
    period: "Previous",
    current: false,
    responsibilities: [],
  },
];

// ── Skills ─────────────────────────────────────────────────────────

export type SkillGroup = {
  category: string;
  skills: string[];
};

export const skillGroups: SkillGroup[] = [
  {
    category: "GIS",
    skills: [
      "Google Earth Engine",
      "QGIS",
      "Remote Sensing",
      "Earth Observation",
      "Raster Analysis",
      "Time-Series Analysis",
      "Satellite Imagery Interpretation",
    ],
  },
  {
    category: "Programming",
    skills: ["Python", "JavaScript", "React", "HTML", "CSS", "Bootstrap", "SQL"],
  },
  {
    category: "Operating Systems",
    skills: ["Linux", "Windows"],
  },
];

// ── Resume ─────────────────────────────────────────────────────────

export const resumeSummary =
  "Mapping Operator at Wipro with professional experience in mapping workflows, spatial data validation, satellite imagery interpretation, feature editing, topology validation, and geospatial quality assurance. Alongside my professional work, I am continuously learning Google Earth Engine, QGIS, Remote Sensing, Earth Observation, Python, and JavaScript. My long-term goal is to become a GIS Developer and Earth Observation Engineer while building the Living Earth initiative.";

export const education = [
  {
    id: "1",
    degree: "Bachelor of Technology (B.Tech) — Computer Science and Engineering",
    institution: "St. Mary's Engineering College",
    period: "",
  },
];

export const achievements = [
  "Published two technical articles on Earth Observation and climate systems",
  "Launched the Living Earth research initiative with two completed episodes",
  "Developed 10+ GIS and Earth Observation projects using Google Earth Engine, QGIS, and Python",
  "Professional experience in geospatial quality assurance at Wipro",
];

// ── Navigation ─────────────────────────────────────────────────────

export const navLinks = [
  { label: "Home", path: "/" },
  { label: "Earth", path: "/earth" },
  { label: "Living Earth", path: "/living-earth" },
  { label: "Research", path: "/research" },
  { label: "Articles", path: "/articles" },
  { label: "About", path: "/about" },
  { label: "Resume", path: "/resume" },
  { label: "Contact", path: "/contact" },
] as const;
