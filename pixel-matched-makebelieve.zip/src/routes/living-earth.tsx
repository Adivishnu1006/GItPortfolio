import { createFileRoute } from "@tanstack/react-router";
import { LivingEarthPage } from "@/components/views/LivingEarthPage";

const HERO =
  "https://images.pexels.com/photos/30596214/pexels-photo-30596214.jpeg?auto=compress&cs=tinysrgb&w=1920";

export const Route = createFileRoute("/living-earth")({
  head: () => ({
    meta: [
      { title: "Living Earth — Earth Observation Research Initiative" },
      {
        name: "description",
        content:
          "Living Earth: a connected atlas of Earth's systems — El Niño monitoring with NOAA OISST, ERA5 atmospheric moisture flux and upcoming episodes.",
      },
      { property: "og:title", content: "Living Earth — Earth Observation Research Initiative" },
      {
        property: "og:description",
        content:
          "A connected atlas of Earth's systems, told through satellite and reanalysis data.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: HERO },
      { name: "twitter:image", content: HERO },
    ],
  }),
  component: LivingEarthPage,
});
