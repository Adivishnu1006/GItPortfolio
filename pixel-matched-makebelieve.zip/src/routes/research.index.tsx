import { createFileRoute } from "@tanstack/react-router";
import { ResearchPage } from "@/components/views/ResearchPage";

export const Route = createFileRoute("/research/")({
  head: () => ({
    meta: [
      { title: "Research & GIS Case Studies — Earth Observation Lab" },
      {
        name: "description",
        content:
          "GIS and remote sensing projects: El Niño monitoring, ERA5 moisture transport, flood mapping, NDVI, land cover, soil and seismic analysis.",
      },
      { property: "og:title", content: "Research & GIS Case Studies — Earth Observation Lab" },
      {
        property: "og:description",
        content:
          "Earth observation research and GIS case studies using Google Earth Engine, Sentinel-2, ERA5 and NOAA data.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResearchPage,
});
