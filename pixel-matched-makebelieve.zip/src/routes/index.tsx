import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/views/HomePage";

const HERO =
  "https://images.pexels.com/photos/30596225/pexels-photo-30596225.jpeg?auto=compress&cs=tinysrgb&w=1920";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Earth Observation Lab — GIS & Remote Sensing Research" },
      {
        name: "description",
        content:
          "GIS, Earth Observation and remote sensing research by Ledalla Naga Sai Adivishnu: Living Earth, case studies, articles and an interactive 3D Earth Explorer.",
      },
      { property: "og:title", content: "Earth Observation Lab — GIS & Remote Sensing Research" },
      {
        property: "og:description",
        content:
          "Mapping Earth's invisible connections through GIS, Earth Observation, and remote sensing research.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: HERO },
      { name: "twitter:image", content: HERO },
    ],
  }),
  component: HomePage,
});
