import { createFileRoute, notFound } from "@tanstack/react-router";
import { caseStudies } from "@/components/views/caseStudies";

export const Route = createFileRoute("/research/$slug")({
  loader: ({ params }) => {
    if (!caseStudies[params.slug]) throw notFound();
    return { slug: params.slug };
  },
  head: ({ params }) => {
    const study = caseStudies[params.slug];
    if (!study) {
      return {
        meta: [
          { title: "Case study unavailable — Earth Observation Lab" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    return {
      meta: [
        { title: study.title },
        { name: "description", content: study.description },
        { property: "og:title", content: study.title },
        { property: "og:description", content: study.description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
        { property: "og:image", content: study.heroImage },
        { name: "twitter:image", content: study.heroImage },
      ],
    };
  },
  component: CaseStudyRoute,
});

function CaseStudyRoute() {
  const { slug } = Route.useLoaderData();
  const study = caseStudies[slug];
  if (!study) return null;
  const Study = study.component;
  return <Study />;
}
