import { createFileRoute, notFound } from "@tanstack/react-router";
import { ArticlePage } from "@/components/views/ArticlesPage";
import { articles } from "@/data/content";

export const Route = createFileRoute("/articles/$slug")({
  loader: ({ params }) => {
    if (!articles.some((a) => a.slug === params.slug)) throw notFound();
  },
  head: ({ params }) => {
    const article = articles.find((a) => a.slug === params.slug);
    if (!article) {
      return {
        meta: [
          { title: "Article not found — Earth Observation Lab" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    return {
      meta: [
        { title: `${article.title} — Earth Observation Lab` },
        { name: "description", content: article.excerpt },
        { property: "og:title", content: article.title },
        { property: "og:description", content: article.excerpt },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
        { property: "og:image", content: article.coverImage },
        { name: "twitter:image", content: article.coverImage },
      ],
    };
  },
  component: ArticleRoute,
});

function ArticleRoute() {
  const { slug } = Route.useParams();
  return <ArticlePage slug={slug} />;
}
