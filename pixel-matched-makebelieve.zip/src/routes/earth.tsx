import { createFileRoute } from "@tanstack/react-router";
import { EarthExplorer } from "@/components/earth/EarthExplorer";

export const Route = createFileRoute("/earth")({
  head: () => ({
    meta: [
      { title: "Earth Explorer — 3D Globe: Temperature, Wind, Rain, Humidity & Moisture Flux" },
      {
        name: "description",
        content:
          "Interactive CesiumJS globe with NOAA OISST V2.1 sea-surface temperature, ERA5 2 m air temperature, 10 m wind speed, daily precipitation, 2 m relative humidity and atmospheric moisture flux: global maps and point values anywhere.",
      },
      { property: "og:title", content: "Earth Explorer — Interactive 3D Globe" },
      {
        property: "og:description",
        content:
          "Explore NOAA sea-surface temperature, ERA5 air temperature, wind, precipitation, humidity and moisture transport on a 3D globe.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EarthExplorer,
});
