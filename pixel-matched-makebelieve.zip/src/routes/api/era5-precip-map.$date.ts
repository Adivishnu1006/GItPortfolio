import { createFileRoute } from "@tanstack/react-router";
import { ArcoDataMissing, mapPool, MAX_PARALLEL_FETCHES, readField } from "@/lib/arco-era5-fetch";
import {
  dailyHourIndices,
  metresToMm,
  PRECIP_COLOURS,
  PRECIP_MISSING_INDEX,
  precipClass,
} from "@/lib/era5-precip-core";
import {
  arcoChunkUrl,
  gridRaster,
  WIND_GRID,
  WIND_MAP_HEIGHT,
  WIND_MAP_WIDTH,
  windDateSchema,
} from "@/lib/era5-wind-core";
import { encodeIndexedPng } from "@/lib/png-indexed";

/*
 * ERA5 daily total precipitation map (UTC day) for the Earth Explorer globe, rendered from the
 * real hourly "tp" fields: per grid point, the sum of the 24 hourly accumulations valid
 * D 01:00 … D+1 00:00, in mm. Any missing hour → the whole day is refused (404), and a
 * missing value at a grid point → transparent pixel. NOT a general proxy.
 */
const pngCache = new Map<string, Uint8Array>();

export const Route = createFileRoute("/api/era5-precip-map/$date")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const date = windDateSchema.safeParse(params.date);
        if (!date.success) return new Response("Invalid date", { status: 400 });

        let png = pngCache.get(date.data);
        if (!png) {
          try {
            const started = Date.now();
            const sum = new Float64Array(WIND_GRID.latCount * WIND_GRID.lonCount);
            // Decode one hour at a time and add it, so only a few fields are in memory.
            await mapPool(dailyHourIndices(date.data), MAX_PARALLEL_FETCHES, async (t) => {
              const field = await readField(arcoChunkUrl("tp", t));
              for (let i = 0; i < sum.length; i++) sum[i] = sum[i]! + field[i]!;
            });
            png = await encodeIndexedPng(
              WIND_MAP_WIDTH,
              WIND_MAP_HEIGHT,
              gridRaster((i) => precipClass(metresToMm(sum[i]!)) ?? PRECIP_MISSING_INDEX),
              PRECIP_COLOURS,
            );
            console.info(`ERA5 precipitation map ${date.data} built in ${Date.now() - started} ms`);
            pngCache.set(date.data, png);
            while (pngCache.size > 2) pngCache.delete(pngCache.keys().next().value!);
          } catch (err) {
            console.error("ERA5 precipitation map failed", date.data, err);
            return new Response("ERA5 precipitation map unavailable", {
              status: err instanceof ArcoDataMissing ? 404 : 502,
            });
          }
        }
        return new Response(png as BodyInit, {
          status: 200,
          headers: {
            "content-type": "image/png",
            "cache-control": "public, max-age=21600",
          },
        });
      },
    },
  },
});
