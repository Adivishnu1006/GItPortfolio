import { createFileRoute } from "@tanstack/react-router";
import { ArcoDataMissing, readField } from "@/lib/arco-era5-fetch";
import {
  drawFluxArrows,
  IVT_HOUR_UTC,
  IVT_MAP_PALETTE,
  ivtPaletteIndex,
} from "@/lib/era5-ivt-core";
import {
  arcoChunkUrl,
  gridRaster,
  hourIndex,
  WIND_GRID,
  WIND_MAP_HEIGHT,
  WIND_MAP_WIDTH,
  windDateSchema,
} from "@/lib/era5-wind-core";
import { encodeIndexedPng } from "@/lib/png-indexed";

/*
 * ERA5 atmospheric moisture-flux map (12:00 UTC) for the Earth Explorer globe, rendered from
 * the real viwve and viwvn fields of the same hour: every pixel is sqrt(Fx² + Fy²) at its
 * nearest 0.25° grid point, coloured by class, with direction arrows drawn from the components
 * at sampled grid points; missing values are transparent. NOT a general proxy: upstream URLs
 * are rebuilt from a validated date only.
 */
const pngCache = new Map<string, Uint8Array>();

export const Route = createFileRoute("/api/era5-ivt-map/$date")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const date = windDateSchema.safeParse(params.date);
        if (!date.success) return new Response("Invalid date", { status: 400 });

        let png = pngCache.get(date.data);
        if (!png) {
          try {
            const started = Date.now();
            const t = hourIndex(date.data, IVT_HOUR_UTC);
            const [east, north] = await Promise.all([
              readField(arcoChunkUrl("viwve", t)),
              readField(arcoChunkUrl("viwvn", t)),
            ]);
            const raster = gridRaster((i) => ivtPaletteIndex(east[i]!, north[i]!));
            const arrows = drawFluxArrows(
              raster,
              east,
              north,
              { width: WIND_MAP_WIDTH, height: WIND_MAP_HEIGHT, pixelDeg: 0.125 },
              WIND_GRID.lonCount,
              WIND_GRID.latCount,
            );
            png = await encodeIndexedPng(WIND_MAP_WIDTH, WIND_MAP_HEIGHT, raster, IVT_MAP_PALETTE);
            console.info(
              `ERA5 moisture flux map ${date.data} built in ${Date.now() - started} ms (${arrows} arrows)`,
            );
            pngCache.set(date.data, png);
            while (pngCache.size > 2) pngCache.delete(pngCache.keys().next().value!);
          } catch (err) {
            console.error("ERA5 moisture flux map failed", date.data, err);
            return new Response("ERA5 moisture flux map unavailable", {
              status: err instanceof ArcoDataMissing ? 404 : 502,
            });
          }
        }
        return new Response(png as BodyInit, {
          status: 200,
          headers: {
            "content-type": "image/png",
            "cache-control": "public, max-age=21600",
          },
        });
      },
    },
  },
});
