import { createFileRoute } from "@tanstack/react-router";
import {
  buildTileUrl,
  fetchErddap,
  isValidTile,
  sstSourceSchema,
  sstTimeSchema,
  tileBBox,
} from "@/lib/sst-core";
import { repairTileEdges } from "@/lib/sst-tile-edges";

/*
 * Same-origin SST overlay tiles for the Earth Explorer globe.
 * NOAA ERDDAP sends no CORS headers, so WebGL cannot use its images directly.
 * This is NOT a general proxy: the upstream URL is rebuilt from a validated tile
 * coordinate (z/x/y within the geographic tiling scheme), a required ISO date and
 * one of the two allow-listed NOAA sources.
 */
export const Route = createFileRoute("/api/sst-tiles/$z/$x/$y")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const z = Number(params.z);
        const x = Number(params.x);
        const y = Number(params.y);
        if (!isValidTile(z, x, y)) return new Response("Invalid tile", { status: 400 });

        const search = new URL(request.url).searchParams;
        const time = sstTimeSchema.safeParse(search.get("time"));
        if (!time.success) return new Response("Invalid or missing time", { status: 400 });
        const source = sstSourceSchema.safeParse(search.get("source"));
        if (!source.success) return new Response("Invalid or missing source", { status: 400 });

        try {
          const upstream = await fetchErddap(
            buildTileUrl(source.data, tileBBox(z, x, y), time.data),
            20_000,
          );
          const type = upstream.headers.get("content-type") ?? "";
          if (!upstream.ok || !type.startsWith("image/png")) {
            console.error(
              "ERDDAP tile failed",
              source.data,
              upstream.status,
              type,
              await upstream.text().catch(() => ""),
            );
            return new Response("SST tile unavailable", {
              status: upstream.status === 503 ? 503 : 502,
            });
          }
          // NCEI's rendered PNGs can leave a 1-px transparent edge; CoastWatch WMS tiles pass through.
          const body =
            source.data === "ncei"
              ? (repairTileEdges(
                  new Uint8Array(await upstream.arrayBuffer()),
                ) as Uint8Array<ArrayBuffer>)
              : upstream.body;
          return new Response(body, {
            status: 200,
            headers: {
              "content-type": "image/png",
              // A dated tile from the final OISST record does not change.
              "cache-control": "public, max-age=86400",
            },
          });
        } catch (err) {
          console.error("ERDDAP tile error", source.data, err);
          return new Response("SST tile unavailable", { status: 504 });
        }
      },
    },
  },
});
