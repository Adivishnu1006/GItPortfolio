import { createFileRoute } from "@tanstack/react-router";
import {
  WIND_COLOURS,
  WIND_MAP_HEIGHT,
  WIND_MAP_WIDTH,
  windDateSchema,
  windMapIndices,
} from "@/lib/era5-wind-core";
import { ArcoDataMissing, readWindField } from "@/lib/arco-era5-fetch";
import { encodeIndexedPng } from "@/lib/png-indexed";

/*
 * ERA5 10 m wind-speed map (12:00 UTC) for the Earth Explorer globe, rendered from the real
 * u10 and v10 fields: every pixel is sqrt(u² + v²) at its nearest 0.25° grid point, coloured
 * by Beaufort class; missing values are transparent. NOT a general proxy: upstream URLs are
 * rebuilt from a validated date only.
 */
const pngCache = new Map<string, Uint8Array>();

export const Route = createFileRoute("/api/era5-wind-map/$date")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const date = windDateSchema.safeParse(params.date);
        if (!date.success) return new Response("Invalid date", { status: 400 });

        let png = pngCache.get(date.data);
        if (!png) {
          try {
            const started = Date.now();
            const [u, v] = await Promise.all([
              readWindField("u", date.data),
              readWindField("v", date.data),
            ]);
            png = await encodeIndexedPng(
              WIND_MAP_WIDTH,
              WIND_MAP_HEIGHT,
              windMapIndices(u, v),
              WIND_COLOURS,
            );
            console.info(`ERA5 wind map ${date.data} built in ${Date.now() - started} ms`);
            pngCache.set(date.data, png);
            while (pngCache.size > 2) pngCache.delete(pngCache.keys().next().value!);
          } catch (err) {
            console.error("ERA5 wind map failed", date.data, err);
            return new Response("ERA5 wind map unavailable", {
              status: err instanceof ArcoDataMissing ? 404 : 502,
            });
          }
        }
        return new Response(png as BodyInit, {
          status: 200,
          headers: {
            "content-type": "image/png",
            "cache-control": "public, max-age=21600",
          },
        });
      },
    },
  },
});
