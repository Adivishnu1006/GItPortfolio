import { createFileRoute } from "@tanstack/react-router";
import { ArcoDataMissing, readField } from "@/lib/arco-era5-fetch";
import { RH_COLOURS, RH_HOUR_UTC, rhPaletteIndex } from "@/lib/era5-rh-core";
import {
  arcoChunkUrl,
  gridRaster,
  hourIndex,
  WIND_MAP_HEIGHT,
  WIND_MAP_WIDTH,
  windDateSchema,
} from "@/lib/era5-wind-core";
import { encodeIndexedPng } from "@/lib/png-indexed";

/*
 * ERA5 2 m relative humidity map (12:00 UTC) for the Earth Explorer globe, computed from the
 * real 2 m temperature and dew-point fields of the same hour: every pixel is
 * 100 · es(Td)/es(T) at its nearest 0.25° grid point, coloured in 10 % classes; missing or
 * inconsistent inputs are transparent. NOT a general proxy: upstream URLs are rebuilt from a
 * validated date only.
 */
const pngCache = new Map<string, Uint8Array>();

export const Route = createFileRoute("/api/era5-rh-map/$date")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const date = windDateSchema.safeParse(params.date);
        if (!date.success) return new Response("Invalid date", { status: 400 });

        let png = pngCache.get(date.data);
        if (!png) {
          try {
            const started = Date.now();
            const t = hourIndex(date.data, RH_HOUR_UTC);
            const [temperature, dewpoint] = await Promise.all([
              readField(arcoChunkUrl("t2m", t)),
              readField(arcoChunkUrl("d2m", t)),
            ]);
            png = await encodeIndexedPng(
              WIND_MAP_WIDTH,
              WIND_MAP_HEIGHT,
              gridRaster((i) => rhPaletteIndex(temperature[i]!, dewpoint[i]!)),
              RH_COLOURS,
            );
            console.info(`ERA5 humidity map ${date.data} built in ${Date.now() - started} ms`);
            pngCache.set(date.data, png);
            while (pngCache.size > 2) pngCache.delete(pngCache.keys().next().value!);
          } catch (err) {
            console.error("ERA5 humidity map failed", date.data, err);
            return new Response("ERA5 humidity map unavailable", {
              status: err instanceof ArcoDataMissing ? 404 : 502,
            });
          }
        }
        return new Response(png as BodyInit, {
          status: 200,
          headers: {
            "content-type": "image/png",
            "cache-control": "public, max-age=21600",
          },
        });
      },
    },
  },
});
