import { createFileRoute } from "@tanstack/react-router";
import { buildMapUrl, era5DateSchema } from "@/lib/era5-core";

/*
 * Same-origin ERA5 daily-mean 2 m air temperature map for the Earth Explorer globe.
 * The official Copernicus Climate Pulse image sends no Access-Control-Allow-Origin header,
 * so WebGL cannot use it directly. NOT a general proxy: the upstream URL is rebuilt from a
 * validated calendar date only.
 */
export const Route = createFileRoute("/api/era5-t2m-map/$date")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const date = era5DateSchema.safeParse(params.date);
        if (!date.success) return new Response("Invalid date", { status: 400 });

        try {
          const upstream = await fetch(buildMapUrl(date.data), {
            signal: AbortSignal.timeout(20_000),
          });
          const type = upstream.headers.get("content-type") ?? "";
          if (!upstream.ok || !type.startsWith("image/png")) {
            console.error("ERA5 map failed", date.data, upstream.status, type);
            return new Response("ERA5 map unavailable", {
              status: upstream.status === 404 ? 404 : 502,
            });
          }
          return new Response(upstream.body, {
            status: 200,
            headers: {
              "content-type": "image/png",
              "cache-control": "public, max-age=21600",
            },
          });
        } catch (err) {
          console.error("ERA5 map error", date.data, err);
          return new Response("ERA5 map unavailable", { status: 504 });
        }
      },
    },
  },
});
