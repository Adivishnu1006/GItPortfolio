import { createFileRoute } from "@tanstack/react-router";
import { AboutPage } from "@/components/views/AboutPage";

const HERO =
  "https://images.pexels.com/photos/1310757/pexels-photo-1310757.jpeg?auto=compress&cs=tinysrgb&w=1920";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Ledalla Naga Sai Adivishnu, GIS & Earth Observation" },
      {
        name: "description",
        content:
          "GIS analyst and Earth observation researcher working with Google Earth Engine, ERA5 reanalysis and satellite remote sensing.",
      },
      { property: "og:title", content: "About — Ledalla Naga Sai Adivishnu" },
      {
        property: "og:description",
        content:
          "Experience, skills and current focus in GIS, remote sensing and Earth observation.",
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: HERO },
      { name: "twitter:image", content: HERO },
    ],
  }),
  component: AboutPage,
});
