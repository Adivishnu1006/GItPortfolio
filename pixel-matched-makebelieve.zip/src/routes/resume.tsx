import { createFileRoute } from "@tanstack/react-router";
import { ResumePage } from "@/components/views/ResumePage";

export const Route = createFileRoute("/resume")({
  head: () => ({
    meta: [
      { title: "Resume — Ledalla Naga Sai Adivishnu, GIS Analyst" },
      {
        name: "description",
        content:
          "Resume: geospatial experience, GIS and remote sensing skills, education, achievements and projects. Download the full resume.",
      },
      { property: "og:title", content: "Resume — Ledalla Naga Sai Adivishnu" },
      {
        property: "og:description",
        content:
          "GIS Analyst, GIS Developer and Earth Observation profile with downloadable resume.",
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResumePage,
});
