import { createFileRoute } from "@tanstack/react-router";
import { ArticlesPage } from "@/components/views/ArticlesPage";

export const Route = createFileRoute("/articles/")({
  head: () => ({
    meta: [
      { title: "Articles — Earth Observation Lab" },
      {
        name: "description",
        content:
          "Technical articles on Earth observation: El Niño and the Indian Monsoon, Earth's water highways and the Living Earth atlas.",
      },
      { property: "og:title", content: "Articles — Earth Observation Lab" },
      {
        property: "og:description",
        content: "Technical writing on satellite data, reanalysis and Earth system connections.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ArticlesPage,
});
