import { createFileRoute } from "@tanstack/react-router";
import { ContactPage } from "@/components/views/ContactPage";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Earth Observation Lab" },
      {
        name: "description",
        content:
          "Get in touch about GIS, remote sensing and Earth observation collaborations, roles or research questions.",
      },
      { property: "og:title", content: "Contact — Earth Observation Lab" },
      {
        property: "og:description",
        content: "Let's talk about Earth — collaborations, research questions and opportunities.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});
