import { describe, expect, it } from "vitest";
import { deriveSstView, SST_POINT_UNREACHABLE } from "@/lib/earth-inspector";
import { buildReverseGeocodeUrl, parseReverseGeocode } from "@/lib/reverse-geocode";

const latestOk = {
  settled: true,
  time: "2026-10-04T12:00:00Z",
  source: "coastwatch",
  error: null,
};

describe("location inspector SST rules", () => {
  it("shows SST for a selected ocean point without any layer being chosen", () => {
    // deriveSstView takes no layer at all: the inspector never depends on the globe layer.
    const view = deriveSstView({
      hasLocation: true,
      latest: latestOk,
      point: {
        isError: false,
        data: {
          status: "ok",
          observation: {
            valueCelsius: 30.26,
            observedAt: "2026-10-04T12:00:00Z",
            gridLatitude: 0.125,
            gridLongitude: -139.875,
          },
        },
      },
    });
    expect(view).toEqual({
      state: "done",
      result: expect.objectContaining({ status: "ok" }),
    });
  });

  it("reports a land point as no ocean observation", () => {
    const view = deriveSstView({
      hasLocation: true,
      latest: latestOk,
      point: {
        isError: false,
        data: {
          status: "no-data",
          observedAt: "2026-10-04T12:00:00Z",
          gridLatitude: 17.375,
          gridLongitude: 78.375,
        },
      },
    });
    expect(view.state === "done" && view.result.status).toBe("no-data");
  });

  it("never presents a failed point request as an observation", () => {
    const view = deriveSstView({
      hasLocation: true,
      latest: latestOk,
      point: { isError: true },
    });
    expect(view).toEqual({
      state: "done",
      result: { status: "unavailable", message: SST_POINT_UNREACHABLE },
    });
  });

  it("is unavailable when NOAA's latest date could not be confirmed, even with old point data", () => {
    const view = deriveSstView({
      hasLocation: true,
      latest: { settled: true, time: null, source: null, error: "down" },
      point: {
        isError: false,
        data: {
          status: "ok",
          observation: {
            valueCelsius: 20,
            observedAt: "2026-10-01T12:00:00Z",
            gridLatitude: 0,
            gridLongitude: 0,
          },
        },
      },
    });
    expect(view).toEqual({ state: "done", result: { status: "unavailable", message: "down" } });
  });

  it("is idle with no selected location", () => {
    expect(
      deriveSstView({ hasLocation: false, latest: latestOk, point: { isError: false } }).state,
    ).toBe("idle");
  });
});

describe("place names", () => {
  it("rejects out-of-range coordinates", () => {
    expect(() => buildReverseGeocodeUrl(91, 0)).toThrow();
    expect(() => buildReverseGeocodeUrl(0, 181)).toThrow();
  });

  it("reads a city with its region and country", () => {
    expect(
      parseReverseGeocode({
        name: "Hyderabad",
        address: { city: "Hyderabad", state: "Telangana", country: "India" },
      }),
    ).toEqual({ name: "Hyderabad", detail: "Telangana, India" });
  });

  it("returns no name for open ocean", () => {
    expect(parseReverseGeocode({ error: "Unable to geocode" })).toEqual({
      name: null,
      detail: null,
    });
  });
});
