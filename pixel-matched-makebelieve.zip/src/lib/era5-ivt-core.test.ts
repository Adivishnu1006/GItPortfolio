import { describe, expect, it } from "vitest";
import {
  ARROW_STEP,
  buildFluxResult,
  deriveMoistureFluxView,
  drawFluxArrows,
  fluxMagnitude,
  fluxTimeIso,
  IVT_ARROW_CORE_INDEX,
  IVT_COLOURS,
  IVT_HOUR_UTC,
  IVT_MISSING_INDEX,
  IVT_POINT_UNREACHABLE,
  IVT_UNITS,
  IVT_VARIABLES,
  ivtClass,
  ivtPaletteIndex,
  transportDirectionTowards,
} from "@/lib/era5-ivt-core";
import {
  arcoChunkUrl,
  ARCO_VARIABLES,
  hourIndex,
  nearestGridCell,
  windDirectionFrom,
  WIND_GRID,
  WIND_MAP_HEIGHT,
  WIND_MAP_WIDTH,
} from "@/lib/era5-wind-core";

/*
 * Real ARCO-ERA5 viwve / viwvn (kg m⁻¹ s⁻¹) at 2026-10-13 12:00 UTC, nearest grid point.
 * Independently cross-checked by integrating q·u and q·v over ERA5's 37 pressure levels
 * (surface to 1 hPa, ∫ … dp/g) at the same hour and point: Pacific −351.1 / 43.8,
 * North Atlantic 503.9 / 522.3 — within 4 % (the coarse levels miss part of the lowest layer).
 */
const PACIFIC_0N_140W = { east: -360.889404296875, north: 49.515380859375 };
const ATLANTIC_45N_30W = { east: 514.673095703125, north: 543.702880859375 };
const PRESSURE_LEVEL_CHECK = {
  pacific: { east: -351.1, north: 43.8 },
  atlantic: { east: 503.9, north: 522.3 },
};

describe("variables and units", () => {
  it("reads viwve and viwvn from the same hour", () => {
    expect(IVT_VARIABLES.east.name).toBe("vertical_integral_of_eastward_water_vapour_flux");
    expect(IVT_VARIABLES.north.name).toBe("vertical_integral_of_northward_water_vapour_flux");
    expect(IVT_VARIABLES.east.paramId).toBe(162071);
    expect(IVT_VARIABLES.north.paramId).toBe(162072);
    expect(ARCO_VARIABLES.viwve).toBe(IVT_VARIABLES.east.name);
    expect(ARCO_VARIABLES.viwvn).toBe(IVT_VARIABLES.north.name);
    const t = hourIndex("2026-10-13", IVT_HOUR_UTC);
    expect(arcoChunkUrl("viwve", t)).toMatch(/eastward_water_vapour_flux\/1111356\.0\.0$/);
    expect(arcoChunkUrl("viwvn", t)).toMatch(/northward_water_vapour_flux\/1111356\.0\.0$/);
  });
  it("keeps the magnitude in kg m⁻¹ s⁻¹", () => {
    expect(IVT_UNITS).toBe("kg m⁻¹ s⁻¹");
  });
});

describe("magnitude = sqrt(Fx² + Fy²)", () => {
  it("matches the formula for real components", () => {
    expect(fluxMagnitude(PACIFIC_0N_140W.east, PACIFIC_0N_140W.north)).toBeCloseTo(364.27, 2);
    expect(fluxMagnitude(ATLANTIC_45N_30W.east, ATLANTIC_45N_30W.north)).toBeCloseTo(748.67, 2);
    expect(fluxMagnitude(3, -4)).toBe(5);
  });
  it("agrees with an independent pressure-level integration within 5 %", () => {
    for (const [real, check] of [
      [PACIFIC_0N_140W, PRESSURE_LEVEL_CHECK.pacific],
      [ATLANTIC_45N_30W, PRESSURE_LEVEL_CHECK.atlantic],
    ] as const) {
      const a = fluxMagnitude(real.east, real.north);
      const b = fluxMagnitude(check.east, check.north);
      expect(Math.abs(a - b) / a).toBeLessThan(0.05);
    }
  });
});

describe("transport direction (towards, clockwise from north)", () => {
  it("handles every sign combination", () => {
    expect(transportDirectionTowards(100, 0)).toBeCloseTo(90, 9); // towards east
    expect(transportDirectionTowards(0, 100)).toBeCloseTo(0, 9); // towards north
    expect(transportDirectionTowards(0, -100)).toBeCloseTo(180, 9); // towards south
    expect(transportDirectionTowards(-100, 0)).toBeCloseTo(270, 9); // towards west
    expect(transportDirectionTowards(100, 100)).toBeCloseTo(45, 9);
    expect(transportDirectionTowards(-100, 100)).toBeCloseTo(315, 9);
    expect(transportDirectionTowards(-100, -100)).toBeCloseTo(225, 9);
    expect(transportDirectionTowards(100, -100)).toBeCloseTo(135, 9);
  });
  it("is the opposite of the wind 'from' convention for the same vector", () => {
    const towards = transportDirectionTowards(ATLANTIC_45N_30W.east, ATLANTIC_45N_30W.north)!;
    const from = windDirectionFrom(ATLANTIC_45N_30W.east, ATLANTIC_45N_30W.north)!;
    expect((towards + 180) % 360).toBeCloseTo(from, 9);
    expect(towards).toBeGreaterThan(0);
    expect(towards).toBeLessThan(90); // north-east
  });
  it("has no direction without transport or with a missing component", () => {
    expect(transportDirectionTowards(0, 0)).toBeNull();
    expect(transportDirectionTowards(Number.NaN, 10)).toBeNull();
  });
});

describe("point result", () => {
  const cell = nearestGridCell(45, -30);
  it("carries both components, the 12:00 UTC time and the grid point", () => {
    const r = buildFluxResult(
      ATLANTIC_45N_30W.east,
      ATLANTIC_45N_30W.north,
      cell,
      "2026-10-13",
      "2026-06-30",
    );
    expect(r.status).toBe("ok");
    if (r.status !== "ok") return;
    expect(r.observation.eastward).toBe(ATLANTIC_45N_30W.east);
    expect(r.observation.northward).toBe(ATLANTIC_45N_30W.north);
    expect(r.observation.time).toBe("2026-10-13T12:00:00Z");
    expect(r.observation.gridLatitude).toBe(45);
    expect(r.observation.gridLongitude).toBe(-30);
    expect(r.observation.release).toBe("ERA5T");
  });
  it("shows no value when either component is missing", () => {
    expect(buildFluxResult(Number.NaN, 10, cell, "2026-10-13", null).status).toBe("no-data");
    expect(buildFluxResult(10, Number.NaN, cell, "2026-10-13", null).status).toBe("no-data");
  });
});

describe("map", () => {
  it("classes magnitudes at 0/50/100/150/250/350/500/750/1000", () => {
    expect(IVT_COLOURS).toHaveLength(9);
    expect(ivtClass(0)).toBe(0);
    expect(ivtClass(249.9)).toBe(3);
    expect(ivtClass(250)).toBe(4);
    expect(ivtClass(748.7)).toBe(6);
    expect(ivtClass(2024)).toBe(8);
    expect(ivtClass(Number.NaN)).toBeNull();
  });
  it("makes a missing component transparent, never a low-flux colour", () => {
    expect(ivtPaletteIndex(Number.NaN, 10)).toBe(IVT_MISSING_INDEX);
    expect(ivtPaletteIndex(0, 0)).toBe(0);
  });
  it("draws arrows from the real components, pointing the way moisture moves", () => {
    const n = WIND_GRID.latCount * WIND_GRID.lonCount;
    const fx = new Float32Array(n).fill(Number.NaN);
    const fy = new Float32Array(n).fill(Number.NaN);
    // One sampled grid point on the equator at 0° E: transport towards the east.
    const lat0 = 360; // latIndex of 0° (multiple of ARROW_STEP)
    expect(lat0 % ARROW_STEP).toBe(0);
    fx[lat0 * WIND_GRID.lonCount] = 500;
    fy[lat0 * WIND_GRID.lonCount] = 0;
    const raster = new Uint8Array(WIND_MAP_WIDTH * WIND_MAP_HEIGHT);
    const count = drawFluxArrows(
      raster,
      fx,
      fy,
      { width: WIND_MAP_WIDTH, height: WIND_MAP_HEIGHT, pixelDeg: 0.125 },
      WIND_GRID.lonCount,
      WIND_GRID.latCount,
    );
    expect(count).toBe(1);
    const cx = 1440;
    const cy = 720;
    // Core pixels east of the centre (arrow head side) and on the centre row.
    expect(raster[cy * WIND_MAP_WIDTH + cx + 10]).toBe(IVT_ARROW_CORE_INDEX);
    // Barbs trail back from the head (westwards), never extend east of the tip.
    const row = Array.from(raster.subarray(cy * WIND_MAP_WIDTH, (cy + 1) * WIND_MAP_WIDTH));
    const coreCols = row.map((v, i) => (v === IVT_ARROW_CORE_INDEX ? i : -1)).filter((i) => i >= 0);
    expect(Math.max(...coreCols)).toBeLessThanOrEqual(cx + 12);
    expect(Math.min(...coreCols)).toBeGreaterThanOrEqual(cx - 12);
  });
  it("draws no arrow where a component is missing", () => {
    const n = WIND_GRID.latCount * WIND_GRID.lonCount;
    const raster = new Uint8Array(WIND_MAP_WIDTH * WIND_MAP_HEIGHT);
    const count = drawFluxArrows(
      raster,
      new Float32Array(n).fill(Number.NaN),
      new Float32Array(n).fill(100),
      { width: WIND_MAP_WIDTH, height: WIND_MAP_HEIGHT, pixelDeg: 0.125 },
      WIND_GRID.lonCount,
      WIND_GRID.latCount,
    );
    expect(count).toBe(0);
  });
});

describe("inspector view", () => {
  const latest = { settled: true, date: "2026-10-13" };
  const ok = buildFluxResult(
    PACIFIC_0N_140W.east,
    PACIFIC_0N_140W.north,
    { gridLatitude: 0, gridLongitude: -140 },
    "2026-10-13",
    null,
  );
  it("is idle without a location and loading before the date is known", () => {
    expect(
      deriveMoistureFluxView({ hasLocation: false, latest, point: { isError: false } }),
    ).toEqual({
      state: "idle",
    });
    expect(
      deriveMoistureFluxView({
        hasLocation: true,
        latest: { settled: false, date: null },
        point: { isError: false },
      }),
    ).toEqual({ state: "loading" });
  });
  it("shows an explicit error when the components cannot be fetched", () => {
    expect(deriveMoistureFluxView({ hasLocation: true, latest, point: { isError: true } })).toEqual(
      {
        state: "done",
        result: { status: "unavailable", message: IVT_POINT_UNREACHABLE },
      },
    );
  });
  it("never shows a value for a different hour than the map", () => {
    expect(
      deriveMoistureFluxView({
        hasLocation: true,
        latest: { settled: true, date: "2026-10-12" },
        point: { data: ok, isError: false },
      }),
    ).toEqual({ state: "loading" });
    expect(fluxTimeIso("2026-10-12")).toBe("2026-10-12T12:00:00Z");
  });
  it("shows the value for the map's hour", () => {
    expect(
      deriveMoistureFluxView({ hasLocation: true, latest, point: { data: ok, isError: false } }),
    ).toEqual({
      state: "done",
      result: ok,
    });
  });
});
