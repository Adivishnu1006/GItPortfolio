import { createServerFn } from "@tanstack/react-start";
import { ArcoDataMissing, chunkExists, fetchCoverage, readValueAt } from "@/lib/arco-era5-fetch";
import {
  buildHumidityResult,
  RH_HOUR_UTC,
  RH_LATEST_UNAVAILABLE,
  RH_POINT_UNREACHABLE,
  type HumidityPointResult,
} from "@/lib/era5-rh-core";
import {
  addDays,
  arcoChunkUrl,
  hourIndex,
  nearestGridCell,
  windPointInputSchema,
} from "@/lib/era5-wind-core";

/*
 * ERA5 2 m relative humidity, derived from 2 m temperature and 2 m dew point read from the
 * public ARCO-ERA5 store (server-side; no CORS header). URLs are rebuilt from validated dates
 * and the allow-listed "t2m" / "d2m" variables only.
 */

export type HumidityLatest = {
  /** Newest UTC day whose 12:00 UTC temperature and dew-point fields both exist. */
  date: string | null;
  finalStop: string | null;
  error: string | null;
};

const inputUrls = (date: string) => {
  const t = hourIndex(date, RH_HOUR_UTC);
  return { temperature: arcoChunkUrl("t2m", t), dewpoint: arcoChunkUrl("d2m", t) };
};

export const getLatestHumidityDate = createServerFn({ method: "GET" }).handler(
  async (): Promise<HumidityLatest> => {
    try {
      const coverage = await fetchCoverage();
      const newest = coverage.era5tStop ?? coverage.finalStop;
      if (!newest) throw new Error("coverage dates missing");
      for (let back = 0; back < 4; back++) {
        const date = addDays(newest, -back);
        const urls = inputUrls(date);
        const [t, d] = await Promise.all([
          chunkExists(urls.temperature),
          chunkExists(urls.dewpoint),
        ]);
        if (t && d) {
          console.info(`ERA5 humidity latest ${date} (final ERA5 until ${coverage.finalStop})`);
          return { date, finalStop: coverage.finalStop, error: null };
        }
      }
      throw new Error("no recent day with both temperature and dew point");
    } catch (err) {
      console.error("ERA5 humidity latest failed", err);
      return { date: null, finalStop: null, error: RH_LATEST_UNAVAILABLE };
    }
  },
);

export const getHumidityPoint = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) =>
    windPointInputSchema
      .extend({ finalStop: windPointInputSchema.shape.date.nullable() })
      .parse(input),
  )
  .handler(async ({ data }): Promise<HumidityPointResult> => {
    const cell = nearestGridCell(data.latitude, data.longitude);
    const urls = inputUrls(data.date);
    try {
      // Same hour, same element index in both fields.
      const [temperatureK, dewpointK] = await Promise.all([
        readValueAt(urls.temperature, cell.index),
        readValueAt(urls.dewpoint, cell.index),
      ]);
      return buildHumidityResult(temperatureK, dewpointK, cell, data.date, data.finalStop);
    } catch (err) {
      console.error("ERA5 humidity point failed", data.date, cell.index, err);
      if (err instanceof ArcoDataMissing) {
        return {
          status: "unavailable",
          message: `ERA5 does not yet have both temperature and dew point for ${data.date}.`,
        };
      }
      return { status: "unavailable", message: RH_POINT_UNREACHABLE };
    }
  });
