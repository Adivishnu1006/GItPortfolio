import { createServerFn } from "@tanstack/react-start";
import { ArcoDataMissing, chunkExists, fetchCoverage, readValueAt } from "@/lib/arco-era5-fetch";
import {
  buildFluxResult,
  IVT_HOUR_UTC,
  IVT_LATEST_UNAVAILABLE,
  IVT_POINT_UNREACHABLE,
  type MoistureFluxPointResult,
} from "@/lib/era5-ivt-core";
import {
  addDays,
  arcoChunkUrl,
  hourIndex,
  nearestGridCell,
  windPointInputSchema,
} from "@/lib/era5-wind-core";

/*
 * ERA5 vertically integrated water-vapour flux (viwve / viwvn) from the public ARCO-ERA5 store
 * (server-side; no CORS header). URLs are rebuilt from validated dates and the allow-listed
 * "viwve" / "viwvn" variables only.
 */

export type MoistureFluxLatest = {
  /** Newest UTC day whose 12:00 UTC eastward and northward fields both exist. */
  date: string | null;
  finalStop: string | null;
  error: string | null;
};

const componentUrls = (date: string) => {
  const t = hourIndex(date, IVT_HOUR_UTC);
  return { east: arcoChunkUrl("viwve", t), north: arcoChunkUrl("viwvn", t) };
};

export const getLatestMoistureFluxDate = createServerFn({ method: "GET" }).handler(
  async (): Promise<MoistureFluxLatest> => {
    try {
      const coverage = await fetchCoverage();
      const newest = coverage.era5tStop ?? coverage.finalStop;
      if (!newest) throw new Error("coverage dates missing");
      for (let back = 0; back < 4; back++) {
        const date = addDays(newest, -back);
        const urls = componentUrls(date);
        const [e, n] = await Promise.all([chunkExists(urls.east), chunkExists(urls.north)]);
        if (e && n) {
          console.info(
            `ERA5 moisture flux latest ${date} (final ERA5 until ${coverage.finalStop})`,
          );
          return { date, finalStop: coverage.finalStop, error: null };
        }
      }
      throw new Error("no recent day with both flux components");
    } catch (err) {
      console.error("ERA5 moisture flux latest failed", err);
      return { date: null, finalStop: null, error: IVT_LATEST_UNAVAILABLE };
    }
  },
);

export const getMoistureFluxPoint = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) =>
    windPointInputSchema
      .extend({ finalStop: windPointInputSchema.shape.date.nullable() })
      .parse(input),
  )
  .handler(async ({ data }): Promise<MoistureFluxPointResult> => {
    const cell = nearestGridCell(data.latitude, data.longitude);
    const urls = componentUrls(data.date);
    try {
      // Same hour, same element index in both component fields.
      const [east, north] = await Promise.all([
        readValueAt(urls.east, cell.index),
        readValueAt(urls.north, cell.index),
      ]);
      return buildFluxResult(east, north, cell, data.date, data.finalStop);
    } catch (err) {
      console.error("ERA5 moisture flux point failed", data.date, cell.index, err);
      if (err instanceof ArcoDataMissing) {
        return {
          status: "unavailable",
          message: `ERA5 does not yet have both moisture-flux components for ${data.date}.`,
        };
      }
      return { status: "unavailable", message: IVT_POINT_UNREACHABLE };
    }
  });
