import { decode, encode } from "fast-png";

/**
 * NCEI's griddap .transparentPng rounds its drawing extent to whole pixels, which sometimes
 * leaves the outermost pixel row or column of a tile fully transparent even though the grid
 * cell it lies in has a value. On the globe that shows as a thin seam along tile edges.
 *
 * Fix: when an edge line is completely transparent but the line next to it has drawn pixels,
 * copy the neighbour line. This only touches display pixels inside the same 0.25° cell
 * (at most one pixel); point values come from the point service and are never affected.
 */
export function fillEmptyTileEdges(rgba: Uint8Array, width: number, height: number): boolean {
  const alphaAt = (x: number, y: number) => rgba[(y * width + x) * 4 + 3] ?? 0;
  const rowEmpty = (y: number) => {
    for (let x = 0; x < width; x++) if (alphaAt(x, y) > 0) return false;
    return true;
  };
  const colEmpty = (x: number) => {
    for (let y = 0; y < height; y++) if (alphaAt(x, y) > 0) return false;
    return true;
  };
  const copyRow = (from: number, to: number) =>
    rgba.copyWithin(to * width * 4, from * width * 4, (from + 1) * width * 4);
  const copyCol = (from: number, to: number) => {
    for (let y = 0; y < height; y++) {
      const row = y * width * 4;
      rgba.copyWithin(row + to * 4, row + from * 4, row + from * 4 + 4);
    }
  };

  if (width < 3 || height < 3) return false;
  let changed = false;
  const edges: Array<[boolean, () => void]> = [
    [rowEmpty(0) && !rowEmpty(1), () => copyRow(1, 0)],
    [rowEmpty(height - 1) && !rowEmpty(height - 2), () => copyRow(height - 2, height - 1)],
    [colEmpty(0) && !colEmpty(1), () => copyCol(1, 0)],
    [colEmpty(width - 1) && !colEmpty(width - 2), () => copyCol(width - 2, width - 1)],
  ];
  for (const [needsFill, fill] of edges) {
    if (needsFill) {
      fill();
      changed = true;
    }
  }
  return changed;
}

/** Decodes an RGBA PNG tile, fills empty edges, and re-encodes it only if something changed. */
export function repairTileEdges(png: Uint8Array): Uint8Array {
  const img = decode(png);
  if (img.channels !== 4 || img.depth !== 8 || !(img.data instanceof Uint8Array)) return png;
  const data = new Uint8Array(img.data);
  if (!fillEmptyTileEdges(data, img.width, img.height)) return png;
  return encode({ width: img.width, height: img.height, data, channels: 4, depth: 8 });
}
