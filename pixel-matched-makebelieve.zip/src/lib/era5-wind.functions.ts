import { createServerFn } from "@tanstack/react-start";
import {
  addDays,
  buildWindResult,
  nearestGridCell,
  WIND_LATEST_UNAVAILABLE,
  windPointInputSchema,
  type WindPointResult,
} from "@/lib/era5-wind-core";
import {
  ArcoDataMissing,
  fetchCoverage,
  readWindValue,
  windChunkExists,
} from "@/lib/arco-era5-fetch";

/*
 * ERA5 10 m wind from the public ARCO-ERA5 store. The store sends no CORS header, so all
 * access is server-side with URLs rebuilt from validated dates only.
 */

export type WindLatest = {
  /** Newest UTC day whose 12:00 UTC u and v fields both exist. */
  date: string | null;
  /** Last day of final (non-preliminary) ERA5 in the store. */
  finalStop: string | null;
  error: string | null;
};

export const getLatestWindDate = createServerFn({ method: "GET" }).handler(
  async (): Promise<WindLatest> => {
    try {
      const coverage = await fetchCoverage();
      const newest = coverage.era5tStop ?? coverage.finalStop;
      if (!newest) throw new Error("coverage dates missing");
      // Confirm both components really exist; step back if the newest day is incomplete.
      for (let back = 0; back < 4; back++) {
        const date = addDays(newest, -back);
        const [u, v] = await Promise.all([windChunkExists("u", date), windChunkExists("v", date)]);
        if (u && v) {
          console.info(`ERA5 wind latest ${date} (final ERA5 until ${coverage.finalStop})`);
          return { date, finalStop: coverage.finalStop, error: null };
        }
      }
      throw new Error("no recent day with both wind components");
    } catch (err) {
      console.error("ERA5 wind latest failed", err);
      return { date: null, finalStop: null, error: WIND_LATEST_UNAVAILABLE };
    }
  },
);

export const getWindPoint = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) =>
    windPointInputSchema
      .extend({ finalStop: windPointInputSchema.shape.date.nullable() })
      .parse(input),
  )
  .handler(async ({ data }): Promise<WindPointResult> => {
    const cell = nearestGridCell(data.latitude, data.longitude);
    try {
      // Same hour, same element index in both component fields.
      const [u, v] = await Promise.all([
        readWindValue("u", data.date, cell.index),
        readWindValue("v", data.date, cell.index),
      ]);
      return buildWindResult(u, v, cell, data.date, data.finalStop);
    } catch (err) {
      console.error("ERA5 wind point failed", data.date, cell.index, err);
      if (err instanceof ArcoDataMissing) {
        return { status: "unavailable", message: `ERA5 has no wind field for ${data.date} yet.` };
      }
      return {
        status: "unavailable",
        message: "ERA5 wind values could not be retrieved. Please try again shortly.",
      };
    }
  });
