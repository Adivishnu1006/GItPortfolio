import { describe, expect, it } from "vitest";
import { fillEmptyTileEdges } from "@/lib/sst-tile-edges";

/** 4×4 RGBA image; `alpha[y][x]` > 0 marks a drawn pixel. */
function image(alpha: number[][]): Uint8Array {
  const data = new Uint8Array(4 * 4 * 4);
  alpha.forEach((row, y) =>
    row.forEach((a, x) => {
      const i = (y * 4 + x) * 4;
      data.set([10 * x, 10 * y, 100, a], i);
    }),
  );
  return data;
}
const alphaRow = (d: Uint8Array, y: number) => [0, 1, 2, 3].map((x) => d[(y * 4 + x) * 4 + 3]);

describe("SST tile edge repair", () => {
  it("fills a fully transparent top row from the row below it", () => {
    const d = image([
      [0, 0, 0, 0],
      [255, 0, 255, 255],
      [255, 255, 255, 255],
      [255, 255, 255, 255],
    ]);
    expect(fillEmptyTileEdges(d, 4, 4)).toBe(true);
    expect(alphaRow(d, 0)).toEqual([255, 0, 255, 255]);
  });

  it("leaves an all-land tile (nothing drawn) untouched", () => {
    const d = image([
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ]);
    expect(fillEmptyTileEdges(d, 4, 4)).toBe(false);
  });

  it("does not change edges that already have drawn pixels", () => {
    const d = image([
      [0, 255, 0, 0],
      [255, 255, 255, 255],
      [255, 255, 255, 255],
      [255, 255, 255, 0],
    ]);
    expect(fillEmptyTileEdges(d, 4, 4)).toBe(false);
  });
});
