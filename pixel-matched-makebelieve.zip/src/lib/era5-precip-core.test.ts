import { describe, expect, it } from "vitest";
import {
  buildPrecipResult,
  dailyHourIndices,
  dailyTotalMm,
  dailyValidTimes,
  derivePrecipView,
  metresToMm,
  PRECIP_COLOURS,
  PRECIP_MISSING_INDEX,
  PRECIP_POINT_UNREACHABLE,
  precipClass,
} from "@/lib/era5-precip-core";
import { gridRaster, nearestGridCell, WIND_GRID, WIND_MAP_WIDTH } from "@/lib/era5-wind-core";

/*
 * Real ERA5 "tp" hourly accumulations (m) from ARCO-ERA5 for 2026-10-12, valid 00:00 on the
 * 12th through 00:00 on the 13th (25 values), at two grid points. Cross-checked against
 * Open-Meteo's ERA5 hourly precipitation: same values per hour after its 0.1 mm rounding.
 */
const ATLANTIC_10N_30W = [
  0.000427722930908, 0.00109148025513, 0.0018892288208, 0.00211524963379, 0.00078296661377,
  0.000626087188721, 0.00148391723633, 0.000161170959473, 0.000501155853271, 0.000444889068604,
  0.000216484069824, 0.000160694122314, 1.14440917969e-5, 3.2901763916e-5, 1.28746032715e-5,
  8.58306884766e-6, 5.05447387695e-5, 0.000117778778076, 0.000224113464355, 3.48091125488e-5,
  0.000100135803223, 0.000124931335449, 0.000137805938721, 2.24113464355e-5, 1.43051147461e-5,
];
const SAHARA_23N_10E = new Array<number>(25).fill(0);
/** The 24 values that belong to UTC day 2026-10-12 (valid 01:00 … next 00:00). */
const day = (series: number[]) => series.slice(1, 25);

describe("units", () => {
  it("converts metres of water equivalent to millimetres", () => {
    expect(metresToMm(0.001)).toBeCloseTo(1, 12);
    expect(metresToMm(0.0237)).toBeCloseTo(23.7, 10);
  });
});

describe("daily accumulation convention", () => {
  it("uses the 24 hourly values valid 01:00 to the next day's 00:00", () => {
    const idx = dailyHourIndices("2026-10-12");
    expect(idx).toHaveLength(24);
    expect(idx[0]).toBe(1111321); // 2026-10-12 01:00 UTC
    expect(idx[23]).toBe(1111344); // 2026-10-13 00:00 UTC
    const times = dailyValidTimes("2026-10-12");
    expect(times[0]).toBe("2026-10-12T01:00:00Z");
    expect(times[23]).toBe("2026-10-13T00:00:00Z");
  });

  it("never counts an hour twice across consecutive days", () => {
    const a = dailyHourIndices("2026-10-11");
    const b = dailyHourIndices("2026-10-12");
    expect(a.filter((i) => b.includes(i))).toEqual([]);
    expect(b[0]).toBe(a[23]! + 1);
  });

  it("sums hourly accumulations instead of treating them as running totals", () => {
    const total = dailyTotalMm(day(ATLANTIC_10N_30W))!;
    expect(total).toBeCloseTo(10.366, 3);
    // Not the last value (a cumulative field would make the last value the daily total).
    expect(total).not.toBeCloseTo(metresToMm(ATLANTIC_10N_30W[24]!), 1);
    // The 00:00 value of the 12th belongs to the 11th and is excluded.
    expect(dailyTotalMm(ATLANTIC_10N_30W.slice(0, 24))!).toBeCloseTo(10.779, 3);
  });

  it("gives 0 mm for a dry desert point", () => {
    expect(dailyTotalMm(day(SAHARA_23N_10E))).toBe(0);
  });

  it("refuses incomplete days and missing hours", () => {
    expect(dailyTotalMm(day(ATLANTIC_10N_30W).slice(0, 23))).toBeNull();
    const gap = day(ATLANTIC_10N_30W);
    gap[5] = Number.NaN;
    expect(dailyTotalMm(gap)).toBeNull();
    const r = buildPrecipResult(gap, nearestGridCell(10, -30), "2026-10-12", "ERA5T");
    expect(r.status).toBe("no-data");
  });
});

describe("point results", () => {
  const cell = nearestGridCell(10, -30);

  it("reports the daily total, the period and the wet hours", () => {
    const r = buildPrecipResult(day(ATLANTIC_10N_30W), cell, "2026-10-12", "ERA5T");
    expect(r.status).toBe("ok");
    if (r.status !== "ok") return;
    expect(r.observation.totalMm).toBeCloseTo(10.366, 3);
    expect(r.observation.periodStart).toBe("2026-10-12T00:00:00Z");
    expect(r.observation.periodEnd).toBe("2026-10-13T00:00:00Z");
    expect(r.observation.maxHourMm).toBeCloseTo(2.115, 3);
    expect(r.observation.wetHours).toBe(16);
  });

  it("keeps zero precipitation as a real 0 mm reading", () => {
    const r = buildPrecipResult(day(SAHARA_23N_10E), nearestGridCell(23, 10), "2026-10-12", "ERA5");
    expect(r.status).toBe("ok");
    if (r.status === "ok") expect(r.observation.totalMm).toBe(0);
  });

  it("shows a failed request as unavailable, not as a total", () => {
    expect(
      derivePrecipView({
        hasLocation: true,
        latest: { settled: true, date: "2026-10-12" },
        point: { isError: true },
      }),
    ).toEqual({
      state: "done",
      result: { status: "unavailable", message: PRECIP_POINT_UNREACHABLE },
    });
  });

  it("never shows a total for another day than the map", () => {
    const other = buildPrecipResult(day(SAHARA_23N_10E), cell, "2026-10-11", "ERA5T");
    expect(
      derivePrecipView({
        hasLocation: true,
        latest: { settled: true, date: "2026-10-12" },
        point: { data: other, isError: false },
      }).state,
    ).toBe("loading");
  });

  it("is unavailable when no complete day can be confirmed", () => {
    const v = derivePrecipView({
      hasLocation: true,
      latest: { settled: true, date: null },
      point: { isError: false },
    });
    expect(v.state === "done" && v.result.status).toBe("unavailable");
  });
});

describe("map classes", () => {
  it("separates dry, wet and missing", () => {
    expect(precipClass(0)).toBe(0);
    expect(precipClass(0.099)).toBe(0);
    expect(precipClass(0.1)).toBe(1);
    expect(precipClass(10.366)).toBe(5);
    expect(precipClass(237.4)).toBe(8);
    expect(precipClass(Number.NaN)).toBeNull();
    expect(PRECIP_MISSING_INDEX).toBe(PRECIP_COLOURS.length);
  });

  it("colours zero as dry and a missing cell as transparent on the raster", () => {
    const n = WIND_GRID.latCount * WIND_GRID.lonCount;
    const sum = new Float64Array(n);
    const wet = nearestGridCell(10, -30);
    sum[wet.index] = dailyTotalMm(day(ATLANTIC_10N_30W))!;
    const missing = nearestGridCell(45, -90);
    sum[missing.index] = Number.NaN;
    const px = gridRaster((i) => precipClass(sum[i]!) ?? PRECIP_MISSING_INDEX);
    expect(px[0]).toBe(0);
    // Pixel just north-east of 10°N 30°W: row 639, column 1200.
    expect(px[639 * WIND_MAP_WIDTH + 1200]).toBe(5);
    expect(px[359 * WIND_MAP_WIDTH + 720]).toBe(PRECIP_MISSING_INDEX);
  });
});
