/**
 * Location-inspector rules, independent of which layer is drawn on the globe: a selected
 * point always gets its SST state, and a failed request is never shown as an observation.
 */
import type { SstPointResult } from "@/lib/sst-core";

export type SstPointView =
  { state: "idle" } | { state: "loading" } | { state: "done"; result: SstPointResult };

export const SST_LATEST_UNAVAILABLE = "NOAA's SST servers could not be reached right now.";
export const SST_POINT_UNREACHABLE = "NOAA could not be reached. Please try again shortly.";

export type SstViewInput = {
  hasLocation: boolean;
  latest: {
    settled: boolean;
    time: string | null;
    source: string | null;
    error?: string | null | undefined;
  };
  point: { data?: SstPointResult | undefined; isError: boolean };
};

export function deriveSstView({ hasLocation, latest, point }: SstViewInput): SstPointView {
  if (!hasLocation) return { state: "idle" };
  if (!latest.settled) return { state: "loading" };
  if (!latest.time || !latest.source) {
    return {
      state: "done",
      result: { status: "unavailable", message: latest.error ?? SST_LATEST_UNAVAILABLE },
    };
  }
  if (point.isError) {
    return { state: "done", result: { status: "unavailable", message: SST_POINT_UNREACHABLE } };
  }
  if (point.data) return { state: "done", result: point.data };
  return { state: "loading" };
}

/** One-line SST summary used in the collapsed inspector. */
export function sstSummary(view: SstPointView): string {
  if (view.state === "idle") return "";
  if (view.state === "loading") return "Retrieving NOAA observation…";
  const r = view.result;
  if (r.status === "ok") {
    return `${r.observation.valueCelsius.toFixed(2)} °C · ${r.observation.observedAt.slice(0, 10)}`;
  }
  if (r.status === "no-data") return "No ocean observation";
  return "Observation unavailable";
}
