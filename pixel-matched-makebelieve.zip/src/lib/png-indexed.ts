/**
 * Minimal palette (colour type 3) PNG encoder for server-rendered data maps.
 * Uses the standard CompressionStream("deflate") (zlib format, as PNG's IDAT requires),
 * available in both the Worker runtime and Node. This compresses the image payload itself;
 * it never sets an HTTP content-encoding.
 */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(bytes: Uint8Array, start = 0, end = bytes.length): number {
  let c = 0xffffffff;
  for (let i = start; i < end; i++) c = CRC_TABLE[(c ^ bytes[i]!) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type: string, data: Uint8Array): Uint8Array {
  const out = new Uint8Array(12 + data.length);
  const view = new DataView(out.buffer);
  view.setUint32(0, data.length);
  for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
  out.set(data, 8);
  view.setUint32(8 + data.length, crc32(out, 4, 8 + data.length));
  return out;
}

async function zlibDeflate(data: Uint8Array): Promise<Uint8Array> {
  const stream = new Response(data as BodyInit).body!.pipeThrough(new CompressionStream("deflate"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function hexToRgb(hex: string): [number, number, number] {
  const m = /^#([0-9a-f]{6})$/i.exec(hex);
  if (!m) throw new Error(`Invalid colour ${hex}`);
  const n = parseInt(m[1]!, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/**
 * Encodes width × height palette indices (row-major). `colours[i]` is opaque; the index
 * `colours.length` is fully transparent (used for missing values).
 */
export async function encodeIndexedPng(
  width: number,
  height: number,
  indices: Uint8Array,
  colours: readonly string[],
): Promise<Uint8Array> {
  if (indices.length !== width * height) throw new Error("Index buffer size mismatch");
  if (colours.length > 255) throw new Error("Too many palette colours");

  const ihdr = new Uint8Array(13);
  const v = new DataView(ihdr.buffer);
  v.setUint32(0, width);
  v.setUint32(4, height);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 3; // palette
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const plte = new Uint8Array((colours.length + 1) * 3);
  colours.forEach((c, i) => plte.set(hexToRgb(c), i * 3));
  const trns = new Uint8Array(colours.length + 1).fill(255);
  trns[colours.length] = 0;

  // Filter type 0 (none) per scanline.
  const raw = new Uint8Array((width + 1) * height);
  for (let r = 0; r < height; r++) {
    raw.set(indices.subarray(r * width, (r + 1) * width), r * (width + 1) + 1);
  }
  const idat = await zlibDeflate(raw);

  const parts = [
    new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("PLTE", plte),
    chunk("tRNS", trns),
    chunk("IDAT", idat),
    chunk("IEND", new Uint8Array(0)),
  ];
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}
