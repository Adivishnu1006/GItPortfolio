/**
 * Browser-side ERA5 point access through Open-Meteo (keyless, sends CORS headers). Called from
 * the visitor's browser so the free service's per-address rate limit applies per visitor,
 * not to the shared hosting address.
 */
import {
  AIR_RATE_LIMITED,
  buildLatestProbeUrl,
  buildPointUrl,
  parseLatestDay,
  parsePointResponse,
  type AirTempPointResult,
} from "@/lib/era5-core";

async function getJson(url: string, signal?: AbortSignal): Promise<unknown> {
  let lastError: unknown = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    const res = await fetch(url, {
      signal: signal ?? null,
      headers: { Accept: "application/json" },
    });
    if (res.status === 429) throw new Error(AIR_RATE_LIMITED);
    if (res.ok) return res.json();
    lastError = new Error(`ERA5 request failed (HTTP ${res.status})`);
    if (res.status < 500) break;
  }
  throw lastError;
}

export type Era5Latest = { date: string | null; error: string | null };

/** Newest day with a complete set of hourly ERA5 values. */
export async function fetchEra5LatestDate(signal?: AbortSignal): Promise<Era5Latest> {
  const today = new Date().toISOString().slice(0, 10);
  try {
    const date = parseLatestDay(await getJson(buildLatestProbeUrl(today), signal));
    return date
      ? { date, error: null }
      : { date: null, error: "No complete ERA5 day was found in the last two weeks." };
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") throw err;
    return {
      date: null,
      error: err instanceof Error && err.message === AIR_RATE_LIMITED ? AIR_RATE_LIMITED : null,
    };
  }
}

export async function fetchEra5Point(
  latitude: number,
  longitude: number,
  date: string,
  signal?: AbortSignal,
): Promise<AirTempPointResult> {
  return parsePointResponse(await getJson(buildPointUrl(latitude, longitude, date), signal), date);
}
