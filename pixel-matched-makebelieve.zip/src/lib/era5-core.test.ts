import { describe, expect, it } from "vitest";
import {
  AIR_POINT_UNREACHABLE,
  AIR_RATE_LIMITED,
  buildMapUrl,
  buildPointUrl,
  celsiusToKelvin,
  deriveAirTempView,
  legendPosition,
  parseLatestDay,
  parsePointResponse,
} from "@/lib/era5-core";

/** Real Open-Meteo ERA5 response for Hyderabad's grid point on 2026-10-14. */
const HYDERABAD_HOURLY = [
  22.4, 22.6, 24.8, 25.7, 26.1, 27.7, 31.2, 31.7, 32.9, 32.9, 30.7, 30.6, 30.4, 30.3, 29.1, 27.6,
  26.9, 25.5, 25.0, 25.0, 23.5, 23.3, 23.2, 23.1,
];
const hours = (day: string) =>
  Array.from({ length: 24 }, (_, h) => `${day}T${String(h).padStart(2, "0")}:00`);
const response = (values: (number | null)[], day = "2026-10-14", lat = 17.5, lon = 78.5) => ({
  latitude: lat,
  longitude: lon,
  elevation: 558,
  hourly_units: { time: "iso8601", temperature_2m: "°C" },
  hourly: { time: hours(day), temperature_2m: values },
});

describe("ERA5 point requests", () => {
  it("asks for the raw nearest ERA5 grid point on one UTC day", () => {
    const url = new URL(buildPointUrl(17.385, 78.4867, "2026-10-14"));
    expect(url.origin + url.pathname).toBe("https://archive-api.open-meteo.com/v1/archive");
    expect(url.searchParams.get("models")).toBe("era5");
    expect(url.searchParams.get("hourly")).toBe("temperature_2m");
    expect(url.searchParams.get("elevation")).toBe("nan");
    expect(url.searchParams.get("cell_selection")).toBe("nearest");
    expect(url.searchParams.get("timezone")).toBe("GMT");
    expect(url.searchParams.get("start_date")).toBe("2026-10-14");
    expect(url.searchParams.get("end_date")).toBe("2026-10-14");
  });

  it("rejects out-of-range coordinates and invalid or future dates", () => {
    expect(() => buildPointUrl(91, 0, "2026-10-14")).toThrow();
    expect(() => buildPointUrl(0, 400, "2026-10-14")).toThrow();
    expect(() => buildPointUrl(0, 0, "2026-02-30")).toThrow();
    expect(() => buildPointUrl(0, 0, "1939-12-31")).toThrow();
    expect(() => buildPointUrl(0, 0, "2999-01-01")).toThrow();
  });
});

describe("ERA5 daily mean", () => {
  it("averages the 24 hourly values of a land point (Hyderabad)", () => {
    const r = parsePointResponse(response(HYDERABAD_HOURLY), "2026-10-14");
    expect(r).toEqual({
      status: "ok",
      observation: {
        meanCelsius: 27.18,
        minCelsius: 22.4,
        maxCelsius: 32.9,
        date: "2026-10-14",
        gridLatitude: 17.5,
        gridLongitude: 78.5,
        gridElevation: 558,
      },
    });
  });

  it("returns a value for an ocean point too (2 m air temperature covers the sea)", () => {
    const r = parsePointResponse(
      response(Array(24).fill(27.7), "2026-10-14", 0, -140),
      "2026-10-14",
    );
    expect(r.status === "ok" && r.observation.meanCelsius).toBe(27.7);
  });

  it("converts Celsius to kelvin with 273.15", () => {
    expect(celsiusToKelvin(27.18)).toBeCloseTo(300.33, 2);
  });

  it("never averages an incomplete day", () => {
    const values: (number | null)[] = [...HYDERABAD_HOURLY];
    values[5] = null;
    expect(parsePointResponse(response(values), "2026-10-14").status).toBe("no-data");
  });

  it("rejects a response in the wrong unit", () => {
    const bad = response(HYDERABAD_HOURLY);
    bad.hourly_units.temperature_2m = "°F";
    expect(parsePointResponse(bad, "2026-10-14").status).toBe("unavailable");
  });
});

describe("ERA5 latest day", () => {
  it("picks the newest day that has all 24 hourly values", () => {
    const days = ["2026-10-13", "2026-10-14", "2026-10-15"];
    const data = {
      hourly_units: { temperature_2m: "°C" },
      hourly: {
        time: days.flatMap(hours),
        temperature_2m: [
          ...Array(24).fill(25),
          ...Array(24).fill(26),
          ...Array(12).fill(27),
          ...Array(12).fill(null),
        ],
      },
    };
    expect(parseLatestDay(data)).toBe("2026-10-14");
  });
});

describe("ERA5 inspector state", () => {
  const latest = { settled: true, date: "2026-10-14", error: null };

  it("never presents a failed request as a value", () => {
    expect(
      deriveAirTempView({
        hasLocation: true,
        latest,
        point: { isError: true, error: new Error("x") },
      }),
    ).toEqual({ state: "done", result: { status: "unavailable", message: AIR_POINT_UNREACHABLE } });
  });

  it("says when the free point service is rate limited", () => {
    const view = deriveAirTempView({
      hasLocation: true,
      latest,
      point: { isError: true, error: new Error(AIR_RATE_LIMITED) },
    });
    expect(
      view.state === "done" && view.result.status === "unavailable" && view.result.message,
    ).toBe(AIR_RATE_LIMITED);
  });

  it("never shows a value from a different day than the map's data date", () => {
    const old = parsePointResponse(response(HYDERABAD_HOURLY, "2026-10-13"), "2026-10-13");
    expect(
      deriveAirTempView({ hasLocation: true, latest, point: { isError: false, data: old } }).state,
    ).toBe("loading");
  });

  it("is unavailable when the latest day could not be confirmed", () => {
    const view = deriveAirTempView({
      hasLocation: true,
      latest: { settled: true, date: null, error: null },
      point: { isError: false },
    });
    expect(view.state === "done" && view.result.status).toBe("unavailable");
  });
});

describe("ERA5 map", () => {
  it("builds the official Climate Pulse daily map URL from a date only", () => {
    expect(buildMapUrl("2026-10-14")).toBe(
      "https://sites.ecmwf.int/data/climatepulse/maps/wrap/daily/2t/absolute/2026/climpulse_map_era5_wrap_daily_2t_absolute_20261014.png",
    );
    expect(() => buildMapUrl("../../etc")).toThrow();
  });

  it("places legend ticks on the 34-colour bar", () => {
    expect(legendPosition(0)).toBe(50);
    expect(legendPosition(-32)).toBeCloseTo(2.941, 3);
    expect(legendPosition(32)).toBeCloseTo(97.059, 3);
  });
});
