/**
 * ERA5 10 m wind rules shared by the server function, the map route and tests.
 * Pure, runtime-agnostic code only: no fetch at import, no env, no browser APIs.
 *
 * Source: ARCO-ERA5, the analysis-ready copy of Copernicus/ECMWF ERA5 hourly single-level data
 * published by Google Research as a Google Cloud public dataset (keyless, no CORS header, so it
 * is read server-side). Store: full_37-1h-0p25deg-chunk-1.zarr-v3 (Zarr v2).
 *  - Variables: 10m_u_component_of_wind (u10, ECMWF param 165) and 10m_v_component_of_wind
 *    (v10, param 166), m s**-1, 10 m above the surface. Not 100 m wind or pressure-level wind.
 *  - Grid: 721 latitudes 90 → −90 and 1440 longitudes 0 → 359.75, 0.25° spacing.
 *  - Time: hourly, index = hours since 1900-01-01 00:00 UTC; one chunk = one hour, whole globe.
 *  - Encoding: float32 little-endian, Blosc (LZ4 + byte shuffle), NaN fill value.
 *  - Coverage: "valid_time_stop" (final ERA5) and "valid_time_stop_era5t" (preliminary ERA5T)
 *    in the store's .zattrs.
 *
 * Wind speed = sqrt(u² + v²) from u and v of the same hour and the same grid point; shown as the
 * instantaneous hourly value at WIND_HOUR_UTC (no daily mean: that would need 48 global fields).
 */
import { z } from "zod";

export const ARCO_ERA5_STORE =
  "https://storage.googleapis.com/gcp-public-data-arco-era5/ar/full_37-1h-0p25deg-chunk-1.zarr-v3";

export const WIND_VARIABLES = {
  u: { name: "10m_u_component_of_wind", shortName: "u10", paramId: 165 },
  v: { name: "10m_v_component_of_wind", shortName: "v10", paramId: 166 },
} as const;
export type WindComponent = keyof typeof WIND_VARIABLES;

export const WIND_GRID = { latCount: 721, lonCount: 1440, step: 0.25 } as const;
const CHUNK_BYTES = WIND_GRID.latCount * WIND_GRID.lonCount * 4;

/** UTC hour shown on the map and in the inspector. */
export const WIND_HOUR_UTC = 12;

const ERA5_FIRST_DAY = "1940-01-01";
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

function isRealDay(value: string): boolean {
  if (!ISO_DAY.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

/** A calendar day (UTC) inside the ERA5 record and not in the future. */
export const windDateSchema = z
  .string()
  .refine(isRealDay, "Invalid date")
  .refine((v) => v >= ERA5_FIRST_DAY, "Before the ERA5 record")
  .refine((v) => v <= new Date().toISOString().slice(0, 10), "Date is in the future");

export const windPointInputSchema = z.object({
  latitude: z.number().finite().min(-90).max(90),
  longitude: z.number().finite().min(-180).max(360),
  date: windDateSchema,
});
export type WindPointInput = z.infer<typeof windPointInputSchema>;

/** Zarr time index of an hour: hours since 1900-01-01 00:00 UTC. */
export function hourIndex(date: string, hour: number = WIND_HOUR_UTC): number {
  const day = windDateSchema.parse(date);
  if (!Number.isInteger(hour) || hour < 0 || hour > 23) throw new Error("Invalid hour");
  return (Date.parse(`${day}T00:00:00Z`) - Date.parse("1900-01-01T00:00:00Z")) / 3_600_000 + hour;
}

/** ARCO-ERA5 variables this site may read (allow-list; URLs are never built from input). */
export const ARCO_VARIABLES = {
  u10: WIND_VARIABLES.u.name,
  v10: WIND_VARIABLES.v.name,
  tp: "total_precipitation",
  t2m: "2m_temperature",
  d2m: "2m_dewpoint_temperature",
  viwve: "vertical_integral_of_eastward_water_vapour_flux",
  viwvn: "vertical_integral_of_northward_water_vapour_flux",
} as const;
export type ArcoVariable = keyof typeof ARCO_VARIABLES;

/** URL of one global hourly chunk of an allow-listed variable. */
export function arcoChunkUrl(variable: ArcoVariable, timeIndex: number): string {
  if (!Number.isInteger(timeIndex) || timeIndex < 0) throw new Error("Invalid time index");
  return `${ARCO_ERA5_STORE}/${ARCO_VARIABLES[variable]}/${timeIndex}.0.0`;
}

/** URL of one global hourly wind chunk, only ever built from a validated date. */
export function chunkUrl(component: WindComponent, date: string): string {
  return arcoChunkUrl(component === "u" ? "u10" : "v10", hourIndex(date));
}

export const ZATTRS_URL = `${ARCO_ERA5_STORE}/.zattrs`;

export type WindCoverage = { finalStop: string | null; era5tStop: string | null };

/** Reads the store's coverage dates; anything malformed becomes null. */
export function parseCoverage(data: unknown): WindCoverage {
  const r = data as { valid_time_stop?: unknown; valid_time_stop_era5t?: unknown } | null;
  const day = (v: unknown) => (typeof v === "string" && isRealDay(v) ? v : null);
  return { finalStop: day(r?.valid_time_stop), era5tStop: day(r?.valid_time_stop_era5t) };
}

export function addDays(day: string, delta: number): string {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + delta);
  return d.toISOString().slice(0, 10);
}

/** Final ERA5, or preliminary ERA5T (ECMWF may still revise it) after the final-data stop. */
export function releaseFor(date: string, finalStop: string | null): "ERA5" | "ERA5T" {
  return finalStop && date <= finalStop ? "ERA5" : "ERA5T";
}

/* ----------------------------------------------------------------------------------------- */
/* Grid lookup                                                                                 */

export function normalizeLongitude(longitude: number): number {
  let lon = ((((longitude + 180) % 360) + 360) % 360) - 180;
  if (lon === -180 && longitude > 0) lon = 180;
  return lon;
}

export type GridCell = {
  latIndex: number;
  lonIndex: number;
  /** Element index in the flattened [lat][lon] chunk. */
  index: number;
  gridLatitude: number;
  /** −180..180 for display. */
  gridLongitude: number;
};

/** Nearest ERA5 grid point; the map uses the same rule, so map and point always agree. */
export function nearestGridCell(latitude: number, longitude: number): GridCell {
  const { step, lonCount } = WIND_GRID;
  const latIndex = Math.round((90 - latitude) / step);
  const lon360 = ((longitude % 360) + 360) % 360;
  const lonIndex = Math.round(lon360 / step) % lonCount;
  return {
    latIndex,
    lonIndex,
    index: latIndex * lonCount + lonIndex,
    gridLatitude: 90 - latIndex * step,
    gridLongitude: normalizeLongitude(lonIndex * step),
  };
}

/* ----------------------------------------------------------------------------------------- */
/* Wind maths                                                                                  */

/** Horizontal wind speed (m/s) from eastward u and northward v of the same hour and cell. */
export function windSpeed(u: number, v: number): number {
  return Math.hypot(u, v);
}

export function msToKmh(ms: number): number {
  return ms * 3.6;
}

/**
 * Meteorological wind direction: where the wind blows FROM, degrees clockwise from true north
 * (0/360 = from the north, 90 = from the east). Null for calm air (direction undefined).
 */
export function windDirectionFrom(u: number, v: number): number | null {
  if (Math.hypot(u, v) < 1e-6) return null;
  const deg = (Math.atan2(-u, -v) * 180) / Math.PI;
  return (deg + 360) % 360;
}

const COMPASS = [
  "N",
  "NNE",
  "NE",
  "ENE",
  "E",
  "ESE",
  "SE",
  "SSE",
  "S",
  "SSW",
  "SW",
  "WSW",
  "W",
  "WNW",
  "NW",
  "NNW",
] as const;

export function compassPoint(directionDeg: number): string {
  return COMPASS[Math.round(directionDeg / 22.5) % 16]!;
}

/**
 * Colour classes = WMO Beaufort scale lower bounds (m/s at 10 m): force 0 below 0.3 m/s up to
 * force 12 from 32.7 m/s. Colours: matplotlib viridis sampled at 13 even steps (perceptually
 * uniform, colour-blind safe). The CSS ramp (--wind-ramp) uses the same colours in order.
 */
export const BEAUFORT_LOWER_BOUNDS = [
  0, 0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7,
] as const;
export const WIND_COLOURS = [
  "#440154",
  "#481f70",
  "#443983",
  "#3b528b",
  "#31688e",
  "#287c8e",
  "#21918c",
  "#20a486",
  "#35b779",
  "#5ec962",
  "#90d743",
  "#c8e020",
  "#fde725",
] as const;

/** Beaufort force (0–12) for a speed in m/s; null for a missing value. */
export function beaufortForce(speed: number): number | null {
  if (!Number.isFinite(speed) || speed < 0) return null;
  let force = 0;
  for (let i = 1; i < BEAUFORT_LOWER_BOUNDS.length; i++) {
    if (speed >= BEAUFORT_LOWER_BOUNDS[i]!) force = i;
  }
  return force;
}

/* ----------------------------------------------------------------------------------------- */
/* Blosc (LZ4 + byte shuffle) decoding, as written by numcodecs / c-blosc 1.x                  */

export type BloscHeader = {
  flags: number;
  typesize: number;
  nbytes: number;
  blocksize: number;
  cbytes: number;
  nblocks: number;
};

const BLOSC_HEADER = 16;
const FLAG_SHUFFLE = 0x1;
const FLAG_MEMCPYED = 0x2;
const FLAG_BITSHUFFLE = 0x4;
const FLAG_DONT_SPLIT = 0x10;
const LZ4_FORMAT = 1;

export function readBloscHeader(buf: Uint8Array): BloscHeader {
  if (buf.length < BLOSC_HEADER) throw new Error("Blosc header truncated");
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const flags = buf[2]!;
  const typesize = buf[3]!;
  const nbytes = view.getInt32(4, true);
  const blocksize = view.getInt32(8, true);
  const cbytes = view.getInt32(12, true);
  if (flags & FLAG_BITSHUFFLE) throw new Error("Bit-shuffle is not supported");
  if (!(flags & FLAG_MEMCPYED) && flags >> 5 !== LZ4_FORMAT) {
    throw new Error("Only LZ4-compressed Blosc chunks are supported");
  }
  if (nbytes < 0 || blocksize <= 0 || cbytes < BLOSC_HEADER || typesize < 1) {
    throw new Error("Invalid Blosc header");
  }
  return { flags, typesize, nbytes, blocksize, cbytes, nblocks: Math.ceil(nbytes / blocksize) };
}

/** Offset of every compressed block (needs the first 16 + 4·nblocks bytes). */
export function readBlockStarts(buf: Uint8Array, h: BloscHeader): number[] {
  const need = BLOSC_HEADER + 4 * h.nblocks;
  if (buf.length < need) throw new Error("Blosc block table truncated");
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return Array.from({ length: h.nblocks }, (_, i) => view.getInt32(BLOSC_HEADER + 4 * i, true));
}

/** LZ4 block-format decompression into dst; returns bytes written. */
export function lz4DecompressBlock(
  src: Uint8Array,
  srcStart: number,
  srcEnd: number,
  dst: Uint8Array,
  dstStart: number,
  dstLength: number,
): number {
  let s = srcStart;
  let d = dstStart;
  const dEnd = dstStart + dstLength;
  while (s < srcEnd) {
    const token = src[s++]!;
    let literals = token >>> 4;
    if (literals === 15) {
      let b: number;
      do {
        b = src[s++]!;
        literals += b;
      } while (b === 255 && s < srcEnd);
    }
    if (s + literals > srcEnd || d + literals > dEnd) throw new Error("LZ4 literal overflow");
    dst.set(src.subarray(s, s + literals), d);
    s += literals;
    d += literals;
    if (s >= srcEnd) break; // last sequence has literals only
    const offset = src[s]! | (src[s + 1]! << 8);
    s += 2;
    if (offset === 0 || offset > d - dstStart) throw new Error("LZ4 invalid match offset");
    let length = token & 15;
    if (length === 15) {
      let b: number;
      do {
        b = src[s++]!;
        length += b;
      } while (b === 255 && s < srcEnd);
    }
    length += 4;
    if (d + length > dEnd) throw new Error("LZ4 match overflow");
    let m = d - offset;
    if (offset >= length) {
      dst.copyWithin(d, m, m + length);
      d += length;
    } else {
      for (let i = 0; i < length; i++) dst[d++] = dst[m++]!;
    }
  }
  return d - dstStart;
}

function unshuffle(src: Uint8Array, dst: Uint8Array, dstStart: number, typesize: number) {
  const n = src.length;
  const quot = Math.floor(n / typesize);
  for (let j = 0; j < quot; j++) {
    for (let i = 0; i < typesize; i++) dst[dstStart + j * typesize + i] = src[i * quot + j]!;
  }
  for (let k = quot * typesize; k < n; k++) dst[dstStart + k] = src[k]!;
}

/**
 * Decodes one block. `src` holds the compressed block starting at `src[srcOffset]`.
 * Writes the block's decompressed bytes at dst[dstStart].
 */
export function decodeBloscBlock(
  h: BloscHeader,
  blockIndex: number,
  src: Uint8Array,
  srcOffset: number,
  dst: Uint8Array,
  dstStart: number,
) {
  const leftover = h.nbytes % h.blocksize;
  const isLeftover = leftover !== 0 && blockIndex === h.nblocks - 1;
  const bsize = isLeftover ? leftover : h.blocksize;
  const split =
    !(h.flags & FLAG_DONT_SPLIT) && h.typesize <= 16 && bsize / h.typesize >= 128 && !isLeftover;
  const nsplits = split ? h.typesize : 1;
  const neblock = bsize / nsplits;
  const shuffle = (h.flags & FLAG_SHUFFLE) !== 0 && h.typesize > 1;
  const out = shuffle ? new Uint8Array(bsize) : dst.subarray(dstStart, dstStart + bsize);
  const view = new DataView(src.buffer, src.byteOffset, src.byteLength);
  let s = srcOffset;
  for (let j = 0; j < nsplits; j++) {
    const csize = view.getInt32(s, true);
    s += 4;
    if (csize === neblock) {
      out.set(src.subarray(s, s + neblock), j * neblock);
    } else {
      const n = lz4DecompressBlock(src, s, s + csize, out, j * neblock, neblock);
      if (n !== neblock) throw new Error("Blosc block size mismatch");
    }
    s += csize;
  }
  if (shuffle) unshuffle(out, dst, dstStart, h.typesize);
}

/** Decodes a whole Blosc chunk into raw bytes. */
export function decodeBloscChunk(buf: Uint8Array): Uint8Array {
  const h = readBloscHeader(buf);
  if (buf.length < h.cbytes) throw new Error("Blosc chunk truncated");
  const out = new Uint8Array(h.nbytes);
  if (h.flags & FLAG_MEMCPYED) {
    out.set(buf.subarray(BLOSC_HEADER, BLOSC_HEADER + h.nbytes));
    return out;
  }
  const starts = readBlockStarts(buf, h);
  starts.forEach((start, i) => decodeBloscBlock(h, i, buf, start, out, i * h.blocksize));
  return out;
}

/** Decodes a global wind chunk into float32 values [lat][lon]. */
export function decodeWindChunk(buf: Uint8Array): Float32Array {
  const raw = decodeBloscChunk(buf);
  if (raw.length !== CHUNK_BYTES) throw new Error("Unexpected ERA5 chunk size");
  return new Float32Array(raw.buffer, raw.byteOffset, raw.length / 4);
}

/* ----------------------------------------------------------------------------------------- */
/* Point results                                                                               */

export type WindObservation = {
  speedMs: number;
  speedKmh: number;
  beaufort: number;
  /** Degrees clockwise from north, direction the wind blows from; null when calm. */
  directionFrom: number | null;
  u: number;
  v: number;
  /** ISO time of the instantaneous hourly value. */
  time: string;
  release: "ERA5" | "ERA5T";
  gridLatitude: number;
  gridLongitude: number;
};

export type WindPointResult =
  | { status: "ok"; observation: WindObservation }
  | { status: "no-data"; time: string; message: string }
  | { status: "unavailable"; message: string };

export function windTimeIso(date: string, hour: number = WIND_HOUR_UTC): string {
  return `${date}T${String(hour).padStart(2, "0")}:00:00Z`;
}

/**
 * Builds the point result from u and v read at the same element of the same hour's chunks.
 * A missing component (NaN) is never replaced by a neighbouring value.
 */
export function buildWindResult(
  u: number,
  v: number,
  cell: GridCell,
  date: string,
  finalStop: string | null,
): WindPointResult {
  const time = windTimeIso(date);
  if (!Number.isFinite(u) || !Number.isFinite(v)) {
    return {
      status: "no-data",
      time,
      message: "ERA5 has no wind value for this grid point at this hour.",
    };
  }
  const speed = windSpeed(u, v);
  return {
    status: "ok",
    observation: {
      speedMs: speed,
      speedKmh: msToKmh(speed),
      beaufort: beaufortForce(speed)!,
      directionFrom: windDirectionFrom(u, v),
      u,
      v,
      time,
      release: releaseFor(date, finalStop),
      gridLatitude: cell.gridLatitude,
      gridLongitude: cell.gridLongitude,
    },
  };
}

/* ----------------------------------------------------------------------------------------- */
/* Map raster                                                                                  */

/** Map image: 0.125° pixels, so every pixel centre has exactly one nearest grid point. */
export const WIND_MAP_WIDTH = 2880;
export const WIND_MAP_HEIGHT = 1440;
export const WIND_MAP_EXTENT = [-180, -90, 180, 90] as const;
/** Palette index used for missing values (transparent). */
export const WIND_MISSING_INDEX = WIND_COLOURS.length;

/**
 * Palette index per map pixel (row-major, north-up, −180..180): each pixel takes the class of
 * its nearest 0.25° grid point (`classOf` receives the flattened grid element index).
 */
export function gridRaster(classOf: (elementIndex: number) => number): Uint8Array {
  const { lonCount } = WIND_GRID;
  const out = new Uint8Array(WIND_MAP_WIDTH * WIND_MAP_HEIGHT);
  const colLon = new Int32Array(WIND_MAP_WIDTH);
  for (let c = 0; c < WIND_MAP_WIDTH; c++) {
    const lon = -180 + 0.125 * c + 0.0625;
    colLon[c] = nearestGridCell(0, lon).lonIndex;
  }
  for (let r = 0; r < WIND_MAP_HEIGHT; r++) {
    const latIndex = nearestGridCell(90 - 0.125 * r - 0.0625, 0).latIndex;
    const rowBase = latIndex * lonCount;
    const outBase = r * WIND_MAP_WIDTH;
    for (let c = 0; c < WIND_MAP_WIDTH; c++) out[outBase + c] = classOf(rowBase + colLon[c]!);
  }
  return out;
}

/** Wind map raster: Beaufort class of sqrt(u² + v²) per pixel, missing → transparent. */
export function windMapIndices(u: Float32Array, v: Float32Array): Uint8Array {
  return gridRaster((i) => {
    const speed = Math.hypot(u[i]!, v[i]!);
    return Number.isFinite(speed) ? beaufortForce(speed)! : WIND_MISSING_INDEX;
  });
}

export const WIND_LATEST_UNAVAILABLE =
  "The latest ERA5 wind hour could not be confirmed right now.";
export const WIND_POINT_UNREACHABLE =
  "ERA5 wind values could not be retrieved. Please try again shortly.";

export type WindView =
  { state: "idle" } | { state: "loading" } | { state: "done"; result: WindPointResult };

export type WindViewInput = {
  hasLocation: boolean;
  latest: { settled: boolean; date: string | null; error?: string | null | undefined };
  point: { data?: WindPointResult | undefined; isError: boolean };
};

/** Inspector state for wind speed; independent of the layer drawn on the globe. */
export function deriveWindView({ hasLocation, latest, point }: WindViewInput): WindView {
  if (!hasLocation) return { state: "idle" };
  if (!latest.settled) return { state: "loading" };
  if (!latest.date) {
    return {
      state: "done",
      result: { status: "unavailable", message: latest.error ?? WIND_LATEST_UNAVAILABLE },
    };
  }
  if (point.isError) {
    return { state: "done", result: { status: "unavailable", message: WIND_POINT_UNREACHABLE } };
  }
  if (point.data) {
    // A value for another hour is never shown under the current map time.
    if (point.data.status === "ok" && point.data.observation.time !== windTimeIso(latest.date)) {
      return { state: "loading" };
    }
    return { state: "done", result: point.data };
  }
  return { state: "loading" };
}

export function windSummary(view: WindView): string {
  if (view.state === "idle") return "";
  if (view.state === "loading") return "Retrieving ERA5 wind…";
  const r = view.result;
  if (r.status === "ok") {
    return `${r.observation.speedMs.toFixed(1)} m/s · ${r.observation.time.slice(0, 10)} ${WIND_HOUR_UTC}:00 UTC`;
  }
  if (r.status === "no-data") return "No ERA5 wind value";
  return "Value unavailable";
}
