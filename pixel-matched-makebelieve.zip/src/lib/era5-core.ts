/**
 * ERA5 2 m air temperature rules shared by the browser fetchers, the map route and tests.
 * Pure, runtime-agnostic code only: no fetch side effects at import, no env, no browser APIs.
 *
 * Dataset: "ERA5 hourly data on single levels from 1940 to present" (Copernicus C3S / ECMWF,
 * CDS id reanalysis-era5-single-levels, DOI 10.24381/cds.adbb2d47). Variable 2m_temperature
 * (GRIB short name 2t, parameter 167), stored in kelvin on a 0.25° grid, hourly.
 * Conversion: °C = K − 273.15 (ECMWF parameter database, param 167).
 *
 * Two keyless access paths, both carrying the same explicit date:
 *  - Map: the official C3S/ECMWF Climate Pulse daily-mean map image (equirectangular,
 *    −180..180°, −90..90°, 2 °C colour steps). It sends no CORS header, so it is served
 *    same-origin through /api/era5-t2m-map/$date, rebuilt only from a validated date.
 *  - Point values: Open-Meteo Historical Weather API with models=era5 (a redistribution of
 *    the Copernicus ERA5 record; returns °C). Requested with elevation=nan (no downscaling)
 *    and cell_selection=nearest (the nearest grid point, never a substituted land cell).
 *    The daily mean is the mean of the 24 hourly values 00–23 UTC, as Climate Pulse uses.
 */
import { z } from "zod";

export const KELVIN_OFFSET = 273.15;
export const celsiusToKelvin = (c: number) => c + KELVIN_OFFSET;
export const kelvinToCelsius = (k: number) => k - KELVIN_OFFSET;

export const ERA5_DATASET = {
  name: "ERA5 hourly data on single levels from 1940 to present",
  cdsId: "reanalysis-era5-single-levels",
  doi: "10.24381/cds.adbb2d47",
  variable: "2m_temperature",
  shortName: "2t",
  paramId: 167,
  sourceUnits: "K",
  gridDegrees: 0.25,
} as const;

export const OPEN_METEO_ARCHIVE = "https://archive-api.open-meteo.com/v1/archive";
const CLIMATE_PULSE_MAP_BASE =
  "https://sites.ecmwf.int/data/climatepulse/maps/wrap/daily/2t/absolute";

/** First day of the ERA5 record. */
const ERA5_FIRST_DAY = "1940-01-01";
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

function isRealDay(value: string): boolean {
  if (!ISO_DAY.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

/** A calendar day (UTC) inside the ERA5 record and not in the future. */
export const era5DateSchema = z
  .string()
  .refine(isRealDay, "Invalid date")
  .refine((v) => v >= ERA5_FIRST_DAY, "Before the ERA5 record")
  .refine((v) => v <= new Date().toISOString().slice(0, 10), "Date is in the future");

export function addDays(day: string, delta: number): string {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + delta);
  return d.toISOString().slice(0, 10);
}

/** Official Climate Pulse daily-mean map for one day (only ever built from a validated date). */
export function buildMapUrl(date: string): string {
  const day = era5DateSchema.parse(date);
  return `${CLIMATE_PULSE_MAP_BASE}/${day.slice(0, 4)}/climpulse_map_era5_wrap_daily_2t_absolute_${day.replaceAll("-", "")}.png`;
}

/** Map image extent in degrees (west, south, east, north); verified against point values. */
export const T2M_MAP_EXTENT = [-180, -90, 180, 90] as const;

/**
 * Colour steps of the Climate Pulse map, matched to the image palette by comparing it with
 * ERA5 daily means at ~300 grid points: 2 °C bins from −32 to +32 °C, plus one colour below
 * and one above. The CSS ramp (--t2m-ramp) uses the same 34 colours in this order.
 */
export const T2M_LEGEND = { min: -32, max: 32, step: 2, colours: 34 } as const;

/** Position (0–100 %) of a temperature on the 34-colour legend bar. */
export function legendPosition(celsius: number): number {
  const { min, max, step, colours } = T2M_LEGEND;
  const clamped = Math.max(min, Math.min(max, celsius));
  return ((1 + (clamped - min) / step) / colours) * 100;
}

const coordinateSchema = z.object({
  latitude: z.number().finite().min(-90).max(90),
  longitude: z.number().finite().min(-180).max(360),
});

export function normalizeLongitude(longitude: number): number {
  let lon = ((((longitude + 180) % 360) + 360) % 360) - 180;
  if (lon === -180 && longitude > 0) lon = 180;
  return lon;
}

function archiveParams(latitude: number, longitude: number, start: string, end: string) {
  return new URLSearchParams({
    latitude: latitude.toFixed(4),
    longitude: normalizeLongitude(longitude).toFixed(4),
    start_date: start,
    end_date: end,
    hourly: "temperature_2m",
    models: "era5",
    // No statistical downscaling and no land-cell preference: the raw nearest ERA5 grid point.
    elevation: "nan",
    cell_selection: "nearest",
    timezone: "GMT",
    temperature_unit: "celsius",
  });
}

export function buildPointUrl(latitude: number, longitude: number, date: string): string {
  const c = coordinateSchema.parse({ latitude, longitude });
  const day = era5DateSchema.parse(date);
  return `${OPEN_METEO_ARCHIVE}?${archiveParams(c.latitude, c.longitude, day, day).toString()}`;
}

/** Probe point and window used to find the newest complete ERA5 day. */
export const LATEST_PROBE = { latitude: 0, longitude: 0, days: 14 } as const;

export function buildLatestProbeUrl(today: string): string {
  const end = era5DateSchema.parse(today);
  const start = addDays(end, -LATEST_PROBE.days);
  return `${OPEN_METEO_ARCHIVE}?${archiveParams(LATEST_PROBE.latitude, LATEST_PROBE.longitude, start, end).toString()}`;
}

type ArchiveResponse = {
  latitude?: unknown;
  longitude?: unknown;
  elevation?: unknown;
  hourly_units?: { temperature_2m?: unknown };
  hourly?: { time?: unknown; temperature_2m?: unknown };
};

type Hourly = { time: string[]; values: (number | null)[] };

function readHourly(data: unknown): Hourly | null {
  const r = data as ArchiveResponse | null;
  const time = r?.hourly?.time;
  const values = r?.hourly?.temperature_2m;
  if (!Array.isArray(time) || !Array.isArray(values) || time.length !== values.length) return null;
  if (r?.hourly_units?.temperature_2m !== "°C") return null;
  return {
    time: time.map(String),
    values: values.map((v) => (typeof v === "number" && Number.isFinite(v) ? v : null)),
  };
}

/** Newest day in the probe response that has all 24 hourly values; null if none. */
export function parseLatestDay(data: unknown): string | null {
  const hourly = readHourly(data);
  if (!hourly) return null;
  const counts = new Map<string, number>();
  hourly.time.forEach((t, i) => {
    if (hourly.values[i] === null) return;
    const day = t.slice(0, 10);
    counts.set(day, (counts.get(day) ?? 0) + 1);
  });
  const complete = [...counts.entries()].filter(([, n]) => n === 24).map(([d]) => d);
  return complete.length ? complete.sort().at(-1)! : null;
}

export type AirTempObservation = {
  /** Mean of the 24 hourly values 00–23 UTC. */
  meanCelsius: number;
  minCelsius: number;
  maxCelsius: number;
  date: string;
  /** Nearest ERA5 grid point that was sampled. */
  gridLatitude: number;
  gridLongitude: number;
  /** Mean height of that grid cell (m). */
  gridElevation: number | null;
};

export type AirTempPointResult =
  | { status: "ok"; observation: AirTempObservation }
  | { status: "no-data"; date: string; message: string }
  | { status: "unavailable"; message: string };

export function parsePointResponse(data: unknown, date: string): AirTempPointResult {
  const r = data as ArchiveResponse | null;
  const hourly = readHourly(data);
  if (!hourly || typeof r?.latitude !== "number" || typeof r?.longitude !== "number") {
    return { status: "unavailable", message: "The ERA5 response could not be read." };
  }
  const values = hourly.values.filter((_, i) => hourly.time[i]?.startsWith(date));
  if (values.length !== 24 || values.some((v) => v === null)) {
    // Never average an incomplete day into a "daily mean".
    return {
      status: "no-data",
      date,
      message: "ERA5 has no complete set of 24 hourly values for this grid point on this day.",
    };
  }
  const nums = values as number[];
  const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
  // Round half up at 0.01 °C after removing float noise (e.g. 27.174999… is exactly 27.175).
  const meanRounded = Math.round(Number((mean * 100).toFixed(6))) / 100;
  return {
    status: "ok",
    observation: {
      meanCelsius: meanRounded,
      minCelsius: Math.min(...nums),
      maxCelsius: Math.max(...nums),
      date,
      gridLatitude: r.latitude,
      gridLongitude: r.longitude,
      gridElevation:
        typeof r.elevation === "number" && Number.isFinite(r.elevation) ? r.elevation : null,
    },
  };
}

export const AIR_LATEST_UNAVAILABLE = "The latest ERA5 day could not be confirmed right now.";
export const AIR_POINT_UNREACHABLE =
  "ERA5 point values could not be retrieved. Please try again shortly.";
export const AIR_RATE_LIMITED =
  "The free ERA5 point service is busy right now. Please try again in a minute.";

export type AirTempView =
  { state: "idle" } | { state: "loading" } | { state: "done"; result: AirTempPointResult };

export type AirTempViewInput = {
  hasLocation: boolean;
  latest: { settled: boolean; date: string | null; error?: string | null | undefined };
  point: { data?: AirTempPointResult | undefined; isError: boolean; error?: unknown };
};

/** Inspector state for 2 m air temperature; independent of the layer drawn on the globe. */
export function deriveAirTempView({ hasLocation, latest, point }: AirTempViewInput): AirTempView {
  if (!hasLocation) return { state: "idle" };
  if (!latest.settled) return { state: "loading" };
  if (!latest.date) {
    return {
      state: "done",
      result: { status: "unavailable", message: latest.error ?? AIR_LATEST_UNAVAILABLE },
    };
  }
  if (point.isError) {
    const message =
      point.error instanceof Error && point.error.message === AIR_RATE_LIMITED
        ? AIR_RATE_LIMITED
        : AIR_POINT_UNREACHABLE;
    return { state: "done", result: { status: "unavailable", message } };
  }
  if (point.data) {
    // A result for another day is never shown under the current data date.
    if (point.data.status === "ok" && point.data.observation.date !== latest.date) {
      return { state: "loading" };
    }
    return { state: "done", result: point.data };
  }
  return { state: "loading" };
}

export function airTempSummary(view: AirTempView): string {
  if (view.state === "idle") return "";
  if (view.state === "loading") return "Retrieving ERA5 value…";
  const r = view.result;
  if (r.status === "ok") {
    return `${r.observation.meanCelsius.toFixed(1)} °C · ${r.observation.date}`;
  }
  if (r.status === "no-data") return "No ERA5 value";
  return "Value unavailable";
}
