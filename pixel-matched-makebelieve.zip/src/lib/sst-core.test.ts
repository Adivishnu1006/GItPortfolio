import { describe, expect, it } from "vitest";
import {
  buildLatestTimeUrl,
  buildPngTileUrl,
  buildPointQuery,
  buildPointUrl,
  buildTileUrl,
  buildWmsTileUrl,
  isValidTile,
  OISST_WMS_LAYER,
  parseLatestTime,
  parsePointResponse,
  sstPointInputSchema,
  tileBBox,
} from "@/lib/sst-core";

const T = "2026-10-04T12:00:00Z";

const row = (lat: number, lon: number, sst: number | null, units = "degree_C", time = T) => ({
  table: {
    columnNames: ["time", "zlev", "latitude", "longitude", "sst"],
    columnUnits: ["UTC", "m", "degrees_north", "degrees_east", units],
    rows: [[time, 0, lat, lon, sst]],
  },
});

const steps = (values: (number | null)[]) => ({
  table: {
    columnNames: ["time", "depth", "latitude", "longitude", "sst"],
    rows: values.map((v, i) => [`2026-10-0${i + 1}T12:00:00Z`, 0, 0.125, 220.125, v]),
  },
});

describe("SST point values", () => {
  it("returns the ocean grid-cell value", () => {
    const r = parsePointResponse(row(0.125, -139.875, 30.26), T);
    expect(r).toEqual({
      status: "ok",
      observation: {
        valueCelsius: 30.26,
        observedAt: T,
        gridLatitude: 0.125,
        gridLongitude: -139.875,
      },
    });
  });

  it("reports NCEI 0–360 grid longitudes as -180..180", () => {
    const r = parsePointResponse(row(0.125, 220.125, 30.32, "Celsius"), T);
    expect(r.status === "ok" && r.observation.gridLongitude).toBe(-139.875);
  });

  it("returns no-data for a land cell (Hyderabad) instead of a nearby ocean value", () => {
    const r = parsePointResponse(row(17.375, 78.375, null), T);
    expect(r.status).toBe("no-data");
    expect("observation" in r).toBe(false);
  });

  it("treats fill values as no-data", () => {
    expect(parsePointResponse(row(10, 10, -999), T).status).toBe("no-data");
  });

  it("rejects values in unexpected units", () => {
    expect(parsePointResponse(row(0, 0, 300, "K"), T).status).toBe("unavailable");
  });

  it("rejects a response for a different date than requested", () => {
    const r = parsePointResponse(row(0, 0, 25, "degree_C", "2026-10-03T12:00:00Z"), T);
    expect(r.status).toBe("unavailable");
  });

  it("samples exactly one grid cell for the requested date", () => {
    expect(
      buildPointQuery({ latitude: 17.38, longitude: 78.48, time: T, source: "coastwatch" }),
    ).toBe("sst[(2026-10-04T12:00:00Z)][(0.0)][(17.3800)][(78.4800)]");
  });

  it("uses each server's longitude convention", () => {
    const p = { latitude: 90, longitude: 220, time: T };
    expect(buildPointQuery({ ...p, source: "coastwatch" })).toBe(
      `sst[(${T})][(0.0)][(89.8750)][(-140.0000)]`,
    );
    expect(buildPointQuery({ ...p, longitude: -140, source: "ncei" })).toBe(
      `sst[(${T})][(0.0)][(89.8750)][(220.0000)]`,
    );
    expect(buildPointUrl({ ...p, source: "ncei" })).toMatch(
      /^https:\/\/www\.ncei\.noaa\.gov\/erddap\/griddap\/ncdc_oisst_v2_avhrr_by_time_zlev_lat_lon\.json\?/,
    );
  });

  it("requires a date and an allow-listed server, and rejects bad input", () => {
    const ok = { latitude: 0, longitude: 0, time: T, source: "ncei" };
    expect(sstPointInputSchema.safeParse(ok).success).toBe(true);
    expect(sstPointInputSchema.safeParse({ ...ok, time: undefined }).success).toBe(false);
    expect(sstPointInputSchema.safeParse({ ...ok, source: "example.com" }).success).toBe(false);
    expect(sstPointInputSchema.safeParse({ ...ok, latitude: 91 }).success).toBe(false);
    expect(sstPointInputSchema.safeParse({ ...ok, time: "last; drop" }).success).toBe(false);
  });
});

describe("Latest SST date", () => {
  it("skips an empty newest step and uses the newest date with values", () => {
    expect(parseLatestTime(steps([30.37, 30.47, 30.32, null]))).toBe("2026-10-03T12:00:00Z");
  });

  it("uses the newest step when it has values", () => {
    expect(parseLatestTime(steps([30.37, 30.47, 30.32, 30.26]))).toBe("2026-10-04T12:00:00Z");
  });

  it("returns null when no recent step has values", () => {
    expect(parseLatestTime(steps([null, null]))).toBeNull();
  });

  it("probes the last four steps at an ocean cell on each server", () => {
    expect(decodeURI(buildLatestTimeUrl("coastwatch"))).toContain(
      "sst[last-3:last][(0.0)][(0.125)][(-139.875)]",
    );
    expect(decodeURI(buildLatestTimeUrl("ncei"))).toContain(
      "sst[last-3:last][(0.0)][(0.125)][(220.125)]",
    );
  });
});

describe("SST overlay tiles", () => {
  it("only accepts tiles inside the geographic tiling scheme up to level 4", () => {
    expect(isValidTile(0, 1, 0)).toBe(true);
    expect(isValidTile(0, 2, 0)).toBe(false);
    expect(isValidTile(4, 31, 15)).toBe(true);
    expect(isValidTile(5, 0, 0)).toBe(false);
    expect(isValidTile(1.5, 0, 0)).toBe(false);
  });

  it("maps tile coordinates to the right bounding box", () => {
    expect(tileBBox(0, 0, 0)).toEqual({ west: -180, south: -90, east: 0, north: 90 });
    expect(tileBBox(1, 3, 0)).toEqual({ west: 90, south: 0, east: 180, north: 90 });
  });

  it("requests the CoastWatch sst WMS layer for an explicit date, never 'last'", () => {
    const url = new URL(buildWmsTileUrl(tileBBox(0, 0, 0), T));
    expect(OISST_WMS_LAYER).toBe("ncdcOisst21Agg_LonPM180:sst");
    expect(url.searchParams.get("layers")).toBe("ncdcOisst21Agg_LonPM180:sst");
    expect(url.searchParams.get("time")).toBe(T);
  });

  it("requests NCEI grid-cell centres inside the tile, shifted to 0–360 in the west", () => {
    const url = decodeURIComponent(buildPngTileUrl(tileBBox(4, 7, 6), T));
    // Tile 4/7/6 = lon -101.25..-90, lat 11.25..22.5
    expect(url).toContain(`sst[(${T})][(0.0)][(11.375):(22.375)][(258.875):(269.875)]`);
    expect(url).toContain(".colorBar=Rainbow|C|Linear|0|32|");
    expect(url).toContain(".size=256|256");
    expect(buildTileUrl("ncei", tileBBox(0, 0, 0), T)).toContain(".transparentPng?");
    expect(buildTileUrl("coastwatch", tileBBox(0, 0, 0), T)).toContain("/wms/");
  });
});
