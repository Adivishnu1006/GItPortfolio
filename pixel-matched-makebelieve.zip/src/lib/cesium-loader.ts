/**
 * Loads the CesiumJS build from a version-pinned CDN, in the browser only.
 *
 * Cesium needs its Workers/Assets/Widgets folders served next to Cesium.js; loading the
 * official build from jsDelivr gives all of them (CESIUM_BASE_URL is derived from the
 * script URL) without bundling ~30 MB into the app or the server worker.
 * Call only from useEffect / event handlers. The `cesium` npm package is a devDependency
 * used for types only; keep CESIUM_VERSION equal to its version.
 */
import type * as CesiumNS from "cesium";

export type CesiumModule = typeof CesiumNS;

export const CESIUM_VERSION = "1.146.0";
export const CESIUM_BASE_URL = `https://cdn.jsdelivr.net/npm/cesium@${CESIUM_VERSION}/Build/Cesium/`;

const SCRIPT_SRI = "sha384-1lWK5deN/B+lLaUw4lk6xKp/L19ii/98SZLk6K8YthDskgvc+GbdixLzbCnSS2Wn";
const CSS_SRI = "sha384-ghEeMdcWWzRv/BPeUcX835vcKDGrxvROXisl/Btpv3GeekBUXTSPVcFJpI1Tcrgp";

declare global {
  interface Window {
    Cesium?: CesiumModule;
    CESIUM_BASE_URL?: string;
  }
}

let pending: Promise<CesiumModule> | null = null;

export function loadCesium(): Promise<CesiumModule> {
  if (typeof window === "undefined")
    return Promise.reject(new Error("Cesium can only load in the browser"));
  if (window.Cesium) return Promise.resolve(window.Cesium);
  if (pending) return pending;

  pending = new Promise<CesiumModule>((resolve, reject) => {
    window.CESIUM_BASE_URL = CESIUM_BASE_URL;

    if (!document.querySelector("link[data-cesium-widgets]")) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = `${CESIUM_BASE_URL}Widgets/widgets.css`;
      link.integrity = CSS_SRI;
      link.crossOrigin = "anonymous";
      link.setAttribute("data-cesium-widgets", "true");
      document.head.appendChild(link);
    }

    const script = document.createElement("script");
    script.src = `${CESIUM_BASE_URL}Cesium.js`;
    script.integrity = SCRIPT_SRI;
    script.crossOrigin = "anonymous";
    script.async = true;
    script.onload = () => {
      if (window.Cesium) resolve(window.Cesium);
      else {
        pending = null;
        reject(new Error("CesiumJS loaded but did not initialise"));
      }
    };
    script.onerror = () => {
      pending = null;
      script.remove();
      reject(new Error("CesiumJS could not be downloaded. Check your connection and try again."));
    };
    document.head.appendChild(script);
  });

  return pending;
}
