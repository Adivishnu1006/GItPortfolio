/**
 * NOAA OISST V2.1 (ERDDAP) access rules shared by the server functions, the tile route and tests.
 * Pure, runtime-agnostic code only: no fetch side effects at import, no env, no browser APIs.
 *
 * Two NOAA ERDDAP servers publish the same OISST V2.1 record (verified identical values):
 *  - coastwatch: NOAA CoastWatch West Coast node. Longitudes -180..180, WMS map service.
 *    Its IPv6 address does not answer, so hosts that connect over IPv6 time out.
 *  - ncei: NOAA NCEI, the dataset's producer. Longitudes 0..360, no WMS, so map tiles use
 *    griddap .transparentPng with the same palette/range as the CoastWatch WMS.
 *    Its newest time step can be an empty placeholder, so the latest date is the newest
 *    step that actually contains values.
 */
import { z } from "zod";

export const SST_SOURCES = {
  coastwatch: {
    id: "coastwatch",
    label: "NOAA CoastWatch ERDDAP",
    baseUrl: "https://coastwatch.pfeg.noaa.gov/erddap",
    datasetId: "ncdcOisst21Agg_LonPM180",
    longitudes: "pm180",
    overlay: "wms",
  },
  ncei: {
    id: "ncei",
    label: "NOAA NCEI ERDDAP",
    baseUrl: "https://www.ncei.noaa.gov/erddap",
    datasetId: "ncdc_oisst_v2_avhrr_by_time_zlev_lat_lon",
    longitudes: "0360",
    overlay: "png",
  },
} as const;

export type SstSourceId = keyof typeof SST_SOURCES;
/** Preference order when more than one source answers. */
export const SST_SOURCE_ORDER: readonly SstSourceId[] = ["coastwatch", "ncei"];
export const sstSourceSchema = z.enum(["coastwatch", "ncei"]);

/** Backwards-compatible names for the primary (CoastWatch) source. */
export const ERDDAP_BASE_URL = SST_SOURCES.coastwatch.baseUrl;
export const OISST_DATASET_ID = SST_SOURCES.coastwatch.datasetId;
/** WMS layer name as advertised by the CoastWatch ERDDAP GetCapabilities document. */
export const OISST_WMS_LAYER = `${OISST_DATASET_ID}:sst`;

/** OISST grid-cell centres span ±89.875° lat; 0.25° spacing. */
const GRID_LAT_LIMIT = 89.875;
const HALF_CELL = 0.125;

/**
 * Highest tile level served. Level 4 tiles are 11.25° wide (exactly 45 grid cells), so tile
 * edges fall on grid-cell edges for both sources; 256 px ≈ 0.044°/px, finer than the grid.
 */
export const SST_TILE_MAX_LEVEL = 4;
export const SST_TILE_SIZE = 256;

/** ERDDAP returns ISO timestamps such as 2026-10-04T12:00:00Z. */
const ISO_TIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;

export const sstTimeSchema = z.string().regex(ISO_TIME, "Invalid observation time");

/** A point request always names a verified date and the source that verified it. */
export const sstPointInputSchema = z.object({
  latitude: z.number().finite().min(-90).max(90),
  longitude: z.number().finite().min(-180).max(360),
  time: sstTimeSchema,
  source: sstSourceSchema,
});
export type SstPointInput = z.infer<typeof sstPointInputSchema>;

export type SstObservation = {
  valueCelsius: number;
  observedAt: string;
  /** Centre of the 0.25° grid cell that was sampled (longitude in -180..180). */
  gridLatitude: number;
  gridLongitude: number;
};

export type SstPointResult =
  | { status: "ok"; observation: SstObservation }
  /** The sampled grid cell has no ocean value (land, or masked). No nearest-ocean substitution. */
  | {
      status: "no-data";
      observedAt: string | null;
      gridLatitude: number | null;
      gridLongitude: number | null;
    }
  | { status: "unavailable"; message: string };

export function normalizeLongitude(longitude: number): number {
  let lon = ((((longitude + 180) % 360) + 360) % 360) - 180;
  if (lon === -180 && longitude > 0) lon = 180;
  return lon;
}

function to360(longitude: number): number {
  return ((longitude % 360) + 360) % 360;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

/** Longitude expressed in the source's convention, clamped to the grid-cell centres. */
function sourceLongitude(source: SstSourceId, longitude: number): number {
  return SST_SOURCES[source].longitudes === "pm180"
    ? clamp(normalizeLongitude(longitude), -180 + HALF_CELL, 180 - HALF_CELL)
    : clamp(to360(longitude), HALF_CELL, 360 - HALF_CELL);
}

/** griddap query for one grid cell on one date. ERDDAP snaps each coordinate to the nearest cell. */
export function buildPointQuery(input: SstPointInput): string {
  const lat = clamp(input.latitude, -GRID_LAT_LIMIT, GRID_LAT_LIMIT);
  const lon = sourceLongitude(input.source, input.longitude);
  return `sst[(${input.time})][(0.0)][(${lat.toFixed(4)})][(${lon.toFixed(4)})]`;
}

export function buildPointUrl(input: SstPointInput): string {
  const s = SST_SOURCES[input.source];
  return `${s.baseUrl}/griddap/${s.datasetId}.json?${encodeURI(buildPointQuery(input))}`;
}

/** Equatorial Pacific cell (0.125°N, 139.875°W): always open ocean, never ice. */
const PROBE_LAT = 0.125;
const PROBE_LON = -139.875;

/** The last four daily steps at an always-ocean cell, used to find the newest populated date. */
export function buildLatestTimeUrl(source: SstSourceId): string {
  const s = SST_SOURCES[source];
  const lon = sourceLongitude(source, PROBE_LON).toFixed(3);
  const query = `sst[last-3:last][(0.0)][(${PROBE_LAT})][(${lon})]`;
  return `${s.baseUrl}/griddap/${s.datasetId}.json?${encodeURI(query)}`;
}

type ErddapTable = {
  table?: { columnNames?: unknown; columnUnits?: unknown; rows?: unknown };
};

function readTable(data: unknown): {
  rows: Record<string, unknown>[];
  units: Record<string, unknown>;
} {
  const table = (data as ErddapTable | null)?.table;
  if (!table || !Array.isArray(table.columnNames) || !Array.isArray(table.rows)) {
    return { rows: [], units: {} };
  }
  const names = table.columnNames;
  const units: Record<string, unknown> = {};
  if (Array.isArray(table.columnUnits)) {
    names.forEach((name, i) => {
      if (typeof name === "string") units[name] = (table.columnUnits as unknown[])[i];
    });
  }
  const rows = table.rows.filter(Array.isArray).map((row) => {
    const out: Record<string, unknown> = {};
    names.forEach((name, i) => {
      if (typeof name === "string") out[name] = (row as unknown[])[i];
    });
    return out;
  });
  return { rows, units };
}

const finite = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);

/** Physically plausible SST bounds; anything outside is treated as a fill value. */
const MIN_PLAUSIBLE_SST = -3;
const MAX_PLAUSIBLE_SST = 40;
const isOceanValue = (v: unknown): v is number =>
  finite(v) && v >= MIN_PLAUSIBLE_SST && v <= MAX_PLAUSIBLE_SST;

/** Unit strings the two servers use for degrees Celsius. */
const CELSIUS_UNITS = new Set(["degree_C", "degrees_C", "Celsius", "degC", "celsius"]);

export function parsePointResponse(data: unknown, expectedTime?: string): SstPointResult {
  const { rows, units } = readTable(data);
  const row = rows[0];
  if (!row || !("sst" in row)) {
    return { status: "unavailable", message: "NOAA returned an unexpected response." };
  }
  const unit = units["sst"];
  if (unit !== undefined && !(typeof unit === "string" && CELSIUS_UNITS.has(unit))) {
    return { status: "unavailable", message: "NOAA returned values in unexpected units." };
  }

  const observedAt = typeof row["time"] === "string" ? row["time"] : null;
  if (expectedTime && observedAt !== expectedTime) {
    return { status: "unavailable", message: "NOAA returned a different date than requested." };
  }
  const gridLatitude = finite(row["latitude"]) ? row["latitude"] : null;
  const gridLongitude = finite(row["longitude"]) ? normalizeLongitude(row["longitude"]) : null;
  const value = row["sst"];

  if (!isOceanValue(value)) {
    return { status: "no-data", observedAt, gridLatitude, gridLongitude };
  }
  if (!observedAt || gridLatitude === null || gridLongitude === null) {
    return { status: "unavailable", message: "NOAA did not return the sampled grid cell." };
  }
  return {
    status: "ok",
    observation: { valueCelsius: value, observedAt, gridLatitude, gridLongitude },
  };
}

/** Newest date whose probe cell holds a real value (skips empty placeholder steps). */
export function parseLatestTime(data: unknown): string | null {
  const { rows } = readTable(data);
  for (const row of [...rows].reverse()) {
    const time = row["time"];
    if (typeof time === "string" && ISO_TIME.test(time) && isOceanValue(row["sst"])) {
      return time;
    }
  }
  return null;
}

/* ── Overlay tiles (Cesium GeographicTilingScheme: 2×1 tiles at level 0, y counted from north) ── */

export type TileBBox = { west: number; south: number; east: number; north: number };

export function isValidTile(z: number, x: number, y: number): boolean {
  if (![z, x, y].every(Number.isInteger)) return false;
  if (z < 0 || z > SST_TILE_MAX_LEVEL) return false;
  return x >= 0 && x < 2 ** (z + 1) && y >= 0 && y < 2 ** z;
}

export function tileBBox(z: number, x: number, y: number): TileBBox {
  const size = 180 / 2 ** z;
  const west = -180 + x * size;
  const north = 90 - y * size;
  return { west, south: north - size, east: west + size, north };
}

export function buildWmsTileUrl(bbox: TileBBox, time: string): string {
  const s = SST_SOURCES.coastwatch;
  const params = new URLSearchParams({
    service: "WMS",
    version: "1.1.1",
    request: "GetMap",
    layers: OISST_WMS_LAYER,
    styles: "",
    srs: "EPSG:4326",
    bbox: [bbox.west, bbox.south, bbox.east, bbox.north].join(","),
    width: String(SST_TILE_SIZE),
    height: String(SST_TILE_SIZE),
    format: "image/png",
    transparent: "true",
    // Always a concrete date: CoastWatch answers time=last with a fully transparent image.
    time,
  });
  return `${s.baseUrl}/wms/${s.datasetId}/request?${params.toString()}`;
}

/**
 * NCEI tile via griddap .transparentPng. Requests the grid-cell centres inside the tile, so the
 * drawn cells cover the tile exactly. Palette and range match the CoastWatch WMS default
 * (Rainbow, linear 0–32 °C), so one legend serves both sources.
 */
export function buildPngTileUrl(bbox: TileBBox, time: string): string {
  const s = SST_SOURCES.ncei;
  // Tiles never straddle 0° or 180°, so a western-hemisphere tile maps to one 180..360 span.
  const shift = bbox.west < 0 ? 360 : 0;
  const west = bbox.west + shift + HALF_CELL;
  const east = bbox.east + shift - HALF_CELL;
  const south = bbox.south + HALF_CELL;
  const north = bbox.north - HALF_CELL;
  const f = (n: number) => n.toFixed(3);
  const query = `sst[(${time})][(0.0)][(${f(south)}):(${f(north)})][(${f(west)}):(${f(east)})]`;
  const range = `${sstDataSource.legendMin}|${sstDataSource.legendMax}`;
  return (
    `${s.baseUrl}/griddap/${s.datasetId}.transparentPng?${encodeURIComponent(query)}` +
    `&.draw=surface&.vars=${encodeURIComponent("longitude|latitude|sst")}` +
    `&.colorBar=${encodeURIComponent(`Rainbow|C|Linear|${range}|`)}` +
    `&.size=${encodeURIComponent(`${SST_TILE_SIZE}|${SST_TILE_SIZE}`)}`
  );
}

export function buildTileUrl(source: SstSourceId, bbox: TileBBox, time: string): string {
  return SST_SOURCES[source].overlay === "wms"
    ? buildWmsTileUrl(bbox, time)
    : buildPngTileUrl(bbox, time);
}

/**
 * fetch() for ERDDAP with a short retry on transient overload responses
 * (NOAA's server intermittently answers 503 "Wait a minute, then try again").
 * Timeouts are not retried: they mean the host is unreachable from this network.
 */
export async function fetchErddap(url: string, timeoutMs: number, retries = 2): Promise<Response> {
  for (let attempt = 0; ; attempt++) {
    const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) });
    if (attempt >= retries || ![429, 502, 503, 504].includes(res.status)) return res;
    await res.body?.cancel();
    await new Promise((r) => setTimeout(r, 600 * (attempt + 1)));
  }
}

export const sstDataSource = {
  dataset:
    "NOAA 0.25° Daily Optimum Interpolation Sea Surface Temperature, Version 2.1 (AVHRR-only, final)",
  datasetId: OISST_DATASET_ID,
  provider: "NOAA NCEI / CoastWatch ERDDAP",
  units: "°C",
  legendMin: 0,
  legendMax: 32,
  attribution: "NOAA OISST V2.1; Huang et al. (2020), DOI: 10.25921/RE9P-PT57",
} as const;
