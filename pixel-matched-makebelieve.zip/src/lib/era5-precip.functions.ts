import { createServerFn } from "@tanstack/react-start";
import {
  ArcoDataMissing,
  chunkExists,
  fetchCoverage,
  mapPool,
  MAX_PARALLEL_FETCHES,
  readValueAt,
} from "@/lib/arco-era5-fetch";
import {
  buildPrecipResult,
  dailyHourIndices,
  PRECIP_LATEST_UNAVAILABLE,
  PRECIP_POINT_UNREACHABLE,
  type PrecipPointResult,
} from "@/lib/era5-precip-core";
import {
  addDays,
  arcoChunkUrl,
  nearestGridCell,
  releaseFor,
  windPointInputSchema,
} from "@/lib/era5-wind-core";

/*
 * ERA5 total precipitation from the public ARCO-ERA5 store (server-side; no CORS header).
 * URLs are rebuilt from validated dates and the allow-listed "tp" variable only.
 */

export type PrecipLatest = {
  /** Newest UTC day whose 24 hourly accumulations (D 01:00 … D+1 00:00) exist. */
  date: string | null;
  finalStop: string | null;
  error: string | null;
};

export const getLatestPrecipDate = createServerFn({ method: "GET" }).handler(
  async (): Promise<PrecipLatest> => {
    try {
      const coverage = await fetchCoverage();
      const newest = coverage.era5tStop ?? coverage.finalStop;
      if (!newest) throw new Error("coverage dates missing");
      const today = new Date().toISOString().slice(0, 10);
      for (let back = 0; back < 5; back++) {
        const date = addDays(newest, -back);
        if (addDays(date, 1) > today) continue;
        const hours = dailyHourIndices(date);
        // The store fills hour by hour, so the first and the last hour bound the whole day.
        const [first, last] = await Promise.all([
          chunkExists(arcoChunkUrl("tp", hours[0]!)),
          chunkExists(arcoChunkUrl("tp", hours[23]!)),
        ]);
        if (first && last) {
          console.info(`ERA5 precipitation latest complete day ${date}`);
          return { date, finalStop: coverage.finalStop, error: null };
        }
      }
      throw new Error("no recent complete precipitation day");
    } catch (err) {
      console.error("ERA5 precipitation latest failed", err);
      return { date: null, finalStop: null, error: PRECIP_LATEST_UNAVAILABLE };
    }
  },
);

export const getPrecipPoint = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) =>
    windPointInputSchema
      .extend({ finalStop: windPointInputSchema.shape.date.nullable() })
      .parse(input),
  )
  .handler(async ({ data }): Promise<PrecipPointResult> => {
    const cell = nearestGridCell(data.latitude, data.longitude);
    try {
      // The 24 hourly accumulations of this UTC day, same grid element in every hour.
      const hourly = await mapPool(dailyHourIndices(data.date), MAX_PARALLEL_FETCHES, (t) =>
        readValueAt(arcoChunkUrl("tp", t), cell.index),
      );
      return buildPrecipResult(hourly, cell, data.date, releaseFor(data.date, data.finalStop));
    } catch (err) {
      console.error("ERA5 precipitation point failed", data.date, cell.index, err);
      if (err instanceof ArcoDataMissing) {
        return {
          status: "unavailable",
          message: `ERA5 does not yet have all 24 hours of ${data.date}, so no daily total is shown.`,
        };
      }
      return { status: "unavailable", message: PRECIP_POINT_UNREACHABLE };
    }
  });
