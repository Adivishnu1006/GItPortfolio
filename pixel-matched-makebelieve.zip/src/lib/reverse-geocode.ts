/**
 * Readable place names for a selected point, from OpenStreetMap Nominatim (keyless, sends
 * CORS headers). Called from the browser so the request carries the site's Referer, as
 * Nominatim's usage policy requires; requests are spaced at least ~1 s apart.
 */

const NOMINATIM_REVERSE = "https://nominatim.openstreetmap.org/reverse";
const MIN_SPACING_MS = 1100;

export type PlaceName = {
  /** Short name such as a city, district or region; null when nothing is named here. */
  name: string | null;
  /** Wider context such as "Telangana, India". */
  detail: string | null;
};

export const NO_PLACE: PlaceName = { name: null, detail: null };

export function buildReverseGeocodeUrl(latitude: number, longitude: number): string {
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
    throw new Error("Latitude must be between -90 and 90");
  }
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    throw new Error("Longitude must be between -180 and 180");
  }
  const params = new URLSearchParams({
    format: "jsonv2",
    lat: latitude.toFixed(4),
    lon: longitude.toFixed(4),
    zoom: "10",
    "accept-language": "en",
  });
  return `${NOMINATIM_REVERSE}?${params.toString()}`;
}

type NominatimAddress = Record<string, string | undefined>;

const NAME_KEYS = [
  "city",
  "town",
  "village",
  "municipality",
  "county",
  "state_district",
  "state",
  "region",
  "country",
] as const;

export function parseReverseGeocode(data: unknown): PlaceName {
  if (!data || typeof data !== "object" || "error" in data) return NO_PLACE;
  const record = data as { name?: unknown; address?: NominatimAddress };
  const address = record.address ?? {};
  const explicit =
    typeof record.name === "string" && record.name.trim() ? record.name.trim() : null;
  const fromAddress = NAME_KEYS.map((k) => address[k]).find((v) => typeof v === "string" && v);
  const name = explicit ?? fromAddress ?? null;
  if (!name) return NO_PLACE;
  const context = [address["state"], address["country"]].filter(
    (v): v is string => typeof v === "string" && v.length > 0 && v !== name,
  );
  return { name, detail: context.length ? context.join(", ") : null };
}

let nextSlot = 0;

function wait(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new DOMException("Aborted", "AbortError"));
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        clearTimeout(timer);
        reject(new DOMException("Aborted", "AbortError"));
      },
      { once: true },
    );
  });
}

/** Browser-only. Resolves NO_PLACE for open ocean / unnamed areas; throws on network errors. */
export async function fetchPlaceName(
  latitude: number,
  longitude: number,
  signal?: AbortSignal,
): Promise<PlaceName> {
  const url = buildReverseGeocodeUrl(latitude, longitude);
  const now = Date.now();
  const delay = Math.max(0, nextSlot - now);
  nextSlot = Math.max(now, nextSlot) + MIN_SPACING_MS;
  if (delay) await wait(delay, signal);
  const res = await fetch(url, { signal: signal ?? null, headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`Place lookup failed (HTTP ${res.status})`);
  return parseReverseGeocode(await res.json());
}
