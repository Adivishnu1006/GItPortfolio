import { createServerFn } from "@tanstack/react-start";
import {
  buildLatestTimeUrl,
  buildPointUrl,
  fetchErddap,
  parseLatestTime,
  parsePointResponse,
  SST_SOURCE_ORDER,
  SST_SOURCES,
  sstPointInputSchema,
  type SstPointResult,
  type SstSourceId,
} from "@/lib/sst-core";

/*
 * NOAA ERDDAP does not send CORS headers, so the browser cannot call it directly.
 * These server functions make the request on the server with fixed, validated queries;
 * they never forward arbitrary URLs.
 */

/** Short probe budget: an unreachable host times out rather than refusing. */
const PROBE_TIMEOUT_MS = 6_000;
const POINT_TIMEOUT_MS = 12_000;

export type LatestSstTime = {
  time: string | null;
  source: SstSourceId | null;
  error: string | null;
};

async function probeSource(id: SstSourceId): Promise<string> {
  const started = Date.now();
  try {
    const res = await fetchErddap(buildLatestTimeUrl(id), PROBE_TIMEOUT_MS, 1);
    if (!res.ok) {
      await res.body?.cancel();
      throw new Error(`HTTP ${res.status}`);
    }
    const time = parseLatestTime(await res.json());
    if (!time) throw new Error("no populated date in the latest steps");
    console.info(`SST source ${id} ok in ${Date.now() - started} ms, latest ${time}`);
    return time;
  } catch (err) {
    const reason = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
    console.warn(`SST source ${id} failed after ${Date.now() - started} ms — ${reason}`);
    throw err;
  }
}

/**
 * Probes every NOAA source in parallel and returns the first (in preference order) that
 * answered with a populated date. Points and tiles then use that same source and date.
 */
export const getLatestSstTime = createServerFn({ method: "GET" }).handler(
  async (): Promise<LatestSstTime> => {
    const results = await Promise.allSettled(
      SST_SOURCE_ORDER.map(async (id) => ({ id, time: await probeSource(id) })),
    );
    for (const r of results) {
      if (r.status === "fulfilled") return { time: r.value.time, source: r.value.id, error: null };
    }
    return {
      time: null,
      source: null,
      error: "NOAA's SST servers could not be reached right now. Please try again shortly.",
    };
  },
);

export const getSstPoint = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => sstPointInputSchema.parse(input))
  .handler(async ({ data }): Promise<SstPointResult> => {
    const label = SST_SOURCES[data.source].label;
    try {
      const res = await fetchErddap(buildPointUrl(data), POINT_TIMEOUT_MS);
      if (res.status === 404) {
        console.error("ERDDAP point 404", data.source, await res.text().catch(() => ""));
        return {
          status: "unavailable",
          message: `${label} has no record for ${data.time.slice(0, 10)}.`,
        };
      }
      if (!res.ok) {
        console.error(
          "ERDDAP point HTTP",
          data.source,
          res.status,
          await res.text().catch(() => ""),
        );
        return {
          status: "unavailable",
          message: `${label} could not return a value for this point right now.`,
        };
      }
      return parsePointResponse(await res.json(), data.time);
    } catch (err) {
      console.error("ERDDAP point failed", data.source, err);
      return {
        status: "unavailable",
        message: `${label} could not be reached. Please try again shortly.`,
      };
    }
  });
