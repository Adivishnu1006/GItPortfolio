import { describe, expect, it } from "vitest";
import { inflateSync } from "node:zlib";
import {
  beaufortForce,
  buildWindResult,
  chunkUrl,
  compassPoint,
  decodeBloscChunk,
  deriveWindView,
  hourIndex,
  lz4DecompressBlock,
  msToKmh,
  nearestGridCell,
  parseCoverage,
  releaseFor,
  WIND_COLOURS,
  WIND_GRID,
  WIND_MAP_WIDTH,
  WIND_MISSING_INDEX,
  WIND_POINT_UNREACHABLE,
  windDateSchema,
  windDirectionFrom,
  windMapIndices,
  windPointInputSchema,
  windSpeed,
} from "@/lib/era5-wind-core";
import { encodeIndexedPng } from "@/lib/png-indexed";

/*
 * Real ERA5 components at 2026-10-13 12:00 UTC, decoded from the ARCO-ERA5 u10/v10 chunks
 * (index 1111356) and cross-checked against Open-Meteo's ERA5 wind_speed_10m/direction:
 * grid 0°N 0°E: u −1.960, v 5.975 → 6.29 m/s (Open-Meteo 6.31), from 162° (Open-Meteo 162°)
 * grid 50°S 100°W: u 12.741, v −6.968 → 14.52 m/s (Open-Meteo 14.52), from 299° (299°)
 */
const GULF_OF_GUINEA = { u: -1.96, v: 5.975 };
const SOUTHERN_OCEAN = { u: 12.741, v: -6.968 };

describe("wind speed from u and v", () => {
  it("is sqrt(u² + v²) for verified ERA5 sample components", () => {
    expect(windSpeed(GULF_OF_GUINEA.u, GULF_OF_GUINEA.v)).toBeCloseTo(6.288, 3);
    expect(windSpeed(SOUTHERN_OCEAN.u, SOUTHERN_OCEAN.v)).toBeCloseTo(14.522, 3);
    expect(windSpeed(3, -4)).toBe(5);
  });

  it("converts m/s to km/h with factor 3.6", () => {
    expect(msToKmh(10)).toBeCloseTo(36, 10);
    expect(msToKmh(6.288)).toBeCloseTo(22.637, 3);
  });

  it("gives the meteorological direction the wind blows from", () => {
    expect(windDirectionFrom(0, -5)).toBeCloseTo(0, 6); // northerly
    expect(windDirectionFrom(-5, 0)).toBeCloseTo(90, 6); // easterly
    expect(windDirectionFrom(0, 5)).toBeCloseTo(180, 6); // southerly
    expect(windDirectionFrom(5, 0)).toBeCloseTo(270, 6); // westerly
    expect(Math.round(windDirectionFrom(GULF_OF_GUINEA.u, GULF_OF_GUINEA.v)!)).toBe(162);
    expect(Math.round(windDirectionFrom(SOUTHERN_OCEAN.u, SOUTHERN_OCEAN.v)!)).toBe(299);
    expect(windDirectionFrom(0, 0)).toBeNull();
    expect(compassPoint(162)).toBe("SSE");
    expect(compassPoint(359)).toBe("N");
  });

  it("classifies speeds on the Beaufort scale", () => {
    expect(beaufortForce(0.2)).toBe(0);
    expect(beaufortForce(0.3)).toBe(1);
    expect(beaufortForce(6.29)).toBe(4);
    expect(beaufortForce(14.52)).toBe(7);
    expect(beaufortForce(32.7)).toBe(12);
    expect(beaufortForce(Number.NaN)).toBeNull();
  });
});

describe("timestamps and grid cells", () => {
  it("indexes 2026-10-13 12:00 UTC as hour 1111356 since 1900", () => {
    expect(hourIndex("2026-10-13")).toBe(1111356);
  });

  it("reads u and v from the same hour", () => {
    const u = chunkUrl("u", "2026-10-13");
    const v = chunkUrl("v", "2026-10-13");
    expect(u).toMatch(/\/10m_u_component_of_wind\/1111356\.0\.0$/);
    expect(v).toMatch(/\/10m_v_component_of_wind\/1111356\.0\.0$/);
  });

  it("picks the nearest 0.25° grid point and wraps longitude", () => {
    const hyd = nearestGridCell(17.385, 78.4867);
    expect(hyd).toMatchObject({ gridLatitude: 17.5, gridLongitude: 78.5 });
    expect(hyd.index).toBe(hyd.latIndex * WIND_GRID.lonCount + hyd.lonIndex);
    expect(nearestGridCell(10, -100).lonIndex).toBe(nearestGridCell(10, 260).lonIndex);
    expect(nearestGridCell(0, 359.9).lonIndex).toBe(0);
    expect(nearestGridCell(-90, 0).latIndex).toBe(720);
  });

  it("rejects invalid dates and out-of-range points", () => {
    expect(windDateSchema.safeParse("2026-02-30").success).toBe(false);
    expect(windDateSchema.safeParse("1939-12-31").success).toBe(false);
    expect(windDateSchema.safeParse("2999-01-01").success).toBe(false);
    expect(
      windPointInputSchema.safeParse({ latitude: 91, longitude: 0, date: "2026-10-13" }).success,
    ).toBe(false);
  });

  it("labels data after the final-ERA5 stop as preliminary ERA5T", () => {
    const cov = parseCoverage({
      valid_time_stop: "2026-06-30",
      valid_time_stop_era5t: "2026-10-13",
    });
    expect(cov).toEqual({ finalStop: "2026-06-30", era5tStop: "2026-10-13" });
    expect(releaseFor("2026-10-13", cov.finalStop)).toBe("ERA5T");
    expect(releaseFor("2026-06-30", cov.finalStop)).toBe("ERA5");
    expect(parseCoverage({ valid_time_stop: "soon" }).finalStop).toBeNull();
  });
});

describe("point results never fabricate values", () => {
  const cell = nearestGridCell(0, 0);

  it("builds a reading from both components of the same cell", () => {
    const r = buildWindResult(GULF_OF_GUINEA.u, GULF_OF_GUINEA.v, cell, "2026-10-13", "2026-06-30");
    expect(r.status).toBe("ok");
    if (r.status !== "ok") return;
    expect(r.observation.speedMs).toBeCloseTo(6.288, 3);
    expect(r.observation.speedKmh).toBeCloseTo(r.observation.speedMs * 3.6, 10);
    expect(r.observation.speedKmh).toBeCloseTo(22.638, 3);
    expect(r.observation.time).toBe("2026-10-13T12:00:00Z");
    expect(r.observation.release).toBe("ERA5T");
  });

  it("returns no-data when a component is missing", () => {
    expect(buildWindResult(Number.NaN, 2, cell, "2026-10-13", null).status).toBe("no-data");
    expect(buildWindResult(2, Number.NaN, cell, "2026-10-13", null).status).toBe("no-data");
  });

  it("shows a failed request as unavailable, not as a reading", () => {
    const view = deriveWindView({
      hasLocation: true,
      latest: { settled: true, date: "2026-10-13" },
      point: { isError: true },
    });
    expect(view).toEqual({
      state: "done",
      result: { status: "unavailable", message: WIND_POINT_UNREACHABLE },
    });
  });

  it("never shows a value for another hour than the map", () => {
    const old = buildWindResult(1, 1, cell, "2026-10-12", null);
    const view = deriveWindView({
      hasLocation: true,
      latest: { settled: true, date: "2026-10-13" },
      point: { data: old, isError: false },
    });
    expect(view.state).toBe("loading");
  });

  it("is unavailable when the latest hour cannot be confirmed, idle without a point", () => {
    expect(
      deriveWindView({
        hasLocation: true,
        latest: { settled: true, date: null },
        point: { isError: false },
      }).state,
    ).toBe("done");
    expect(
      deriveWindView({
        hasLocation: false,
        latest: { settled: false, date: null },
        point: { isError: false },
      }),
    ).toEqual({ state: "idle" });
  });
});

/** Builds a Blosc chunk whose split streams are stored uncompressed (csize == stream size). */
function rawSplitBlosc(values: Float32Array, blocksize: number): Uint8Array {
  const bytes = new Uint8Array(values.buffer);
  const typesize = 4;
  const nblocks = Math.ceil(bytes.length / blocksize);
  const parts: Uint8Array[] = [];
  for (let b = 0; b < nblocks; b++) {
    const block = bytes.subarray(b * blocksize, Math.min(bytes.length, (b + 1) * blocksize));
    const leftover = block.length !== blocksize;
    const quot = block.length / typesize;
    const shuffled = new Uint8Array(block.length);
    for (let j = 0; j < quot; j++)
      for (let i = 0; i < typesize; i++) shuffled[i * quot + j] = block[j * typesize + i]!;
    const nsplits = leftover ? 1 : typesize;
    const ne = block.length / nsplits;
    const out = new Uint8Array(nsplits * (4 + ne));
    const dv = new DataView(out.buffer);
    for (let s = 0; s < nsplits; s++) {
      dv.setInt32(s * (4 + ne), ne, true);
      out.set(shuffled.subarray(s * ne, (s + 1) * ne), s * (4 + ne) + 4);
    }
    parts.push(out);
  }
  const headerLen = 16 + 4 * nblocks;
  const total = headerLen + parts.reduce((n, p) => n + p.length, 0);
  const buf = new Uint8Array(total);
  const dv = new DataView(buf.buffer);
  buf[0] = 2;
  buf[1] = 1;
  buf[2] = 0x21; // LZ4 + byte shuffle, split allowed
  buf[3] = typesize;
  dv.setInt32(4, bytes.length, true);
  dv.setInt32(8, blocksize, true);
  dv.setInt32(12, total, true);
  let o = headerLen;
  parts.forEach((p, i) => {
    dv.setInt32(16 + 4 * i, o, true);
    buf.set(p, o);
    o += p.length;
  });
  return buf;
}

describe("Blosc / LZ4 decoding", () => {
  it("decodes LZ4 literals and overlapping matches", () => {
    // "abc" + match(offset 3, length 6) → "abcabcabc", then literal "Z".
    const src = new Uint8Array([0x32, 97, 98, 99, 3, 0, 0x10, 90]);
    const dst = new Uint8Array(10);
    expect(lz4DecompressBlock(src, 0, src.length, dst, 0, 10)).toBe(10);
    expect(new TextDecoder().decode(dst)).toBe("abcabcabcZ");
  });

  it("rejects corrupt LZ4 offsets", () => {
    const src = new Uint8Array([0x10, 97, 9, 0]);
    expect(() => lz4DecompressBlock(src, 0, src.length, new Uint8Array(20), 0, 20)).toThrow();
  });

  it("undoes byte shuffle and splits, including a short last block", () => {
    const values = new Float32Array(700).map((_, i) => i * 0.5 - 100);
    const decoded = decodeBloscChunk(rawSplitBlosc(values, 1024));
    expect(Array.from(new Float32Array(decoded.buffer))).toEqual(Array.from(values));
  });
});

describe("wind map raster", () => {
  it("colours each pixel from its nearest grid point and leaves missing cells transparent", () => {
    const n = WIND_GRID.latCount * WIND_GRID.lonCount;
    const u = new Float32Array(n);
    const v = new Float32Array(n);
    const cell = nearestGridCell(0, 0);
    u[cell.index] = SOUTHERN_OCEAN.u;
    v[cell.index] = SOUTHERN_OCEAN.v;
    const missing = nearestGridCell(45, -90);
    u[missing.index] = Number.NaN;
    const px = windMapIndices(u, v);
    // Pixel just north-east of 0°N 0°E (row 719, column 1440).
    expect(px[719 * WIND_MAP_WIDTH + 1440]).toBe(7);
    // Calm everywhere else → force 0.
    expect(px[0]).toBe(0);
    // Pixel just north-east of 45°N 90°W: row 359, column 720.
    expect(px[359 * WIND_MAP_WIDTH + 720]).toBe(WIND_MISSING_INDEX);
  });

  it("encodes a valid palette PNG with a transparent missing colour", async () => {
    const png = await encodeIndexedPng(3, 2, new Uint8Array([0, 1, 2, 12, 13, 0]), WIND_COLOURS);
    expect(Array.from(png.subarray(0, 8))).toEqual([137, 80, 78, 71, 13, 10, 26, 10]);
    const text = new TextDecoder("latin1").decode(png);
    const idat = text.indexOf("IDAT");
    const len = new DataView(png.buffer).getUint32(idat - 4);
    const raw = inflateSync(png.subarray(idat + 4, idat + 4 + len));
    expect(Array.from(raw)).toEqual([0, 0, 1, 2, 0, 12, 13, 0]);
    const trns = text.indexOf("tRNS");
    expect(png[trns + 4 + WIND_COLOURS.length]).toBe(0);
  });
});
