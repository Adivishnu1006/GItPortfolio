/**
 * Server-side reads of the public ARCO-ERA5 store (no CORS header, so never from the browser).
 * Every URL is built in era5-wind-core.ts from a validated date and an allow-listed variable.
 * Small in-memory caches keep repeated clicks and map loads cheap within one server instance.
 */
import {
  chunkUrl,
  decodeBloscBlock,
  decodeWindChunk,
  parseCoverage,
  readBlockStarts,
  readBloscHeader,
  ZATTRS_URL,
  type BloscHeader,
  type WindComponent,
  type WindCoverage,
} from "@/lib/era5-wind-core";

const HEADER_TIMEOUT_MS = 10_000;
const BLOCK_TIMEOUT_MS = 15_000;
const CHUNK_TIMEOUT_MS = 30_000;
/** The server runtime allows 6 outbound requests waiting for headers at once. */
export const MAX_PARALLEL_FETCHES = 6;

export class ArcoDataMissing extends Error {}

function lru<V>(max: number) {
  const map = new Map<string, V>();
  return {
    get(key: string) {
      const v = map.get(key);
      if (v !== undefined) {
        map.delete(key);
        map.set(key, v);
      }
      return v;
    },
    set(key: string, value: V) {
      map.delete(key);
      map.set(key, value);
      while (map.size > max) map.delete(map.keys().next().value!);
    },
  };
}

/** Runs tasks with at most `limit` in flight; results keep input order. */
export async function mapPool<T, R>(
  items: readonly T[],
  limit: number,
  task: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      results[i] = await task(items[i]!, i);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

async function fetchBytes(url: string, timeoutMs: number, range?: string): Promise<Uint8Array> {
  const res = await fetch(url, {
    headers: range ? { Range: `bytes=${range}` } : {},
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (res.status === 404) {
    await res.body?.cancel();
    throw new ArcoDataMissing(`ERA5 chunk not found: ${url}`);
  }
  if (!(res.ok || res.status === 206)) {
    await res.body?.cancel();
    throw new Error(`ERA5 store HTTP ${res.status}`);
  }
  if (range && res.status !== 206) throw new Error("ERA5 store ignored the byte range");
  return new Uint8Array(await res.arrayBuffer());
}

type ChunkIndex = { header: BloscHeader; starts: number[] };
const indexCache = lru<ChunkIndex>(64);
const blockCache = lru<Float32Array>(40);

async function chunkIndex(url: string): Promise<ChunkIndex> {
  const hit = indexCache.get(url);
  if (hit) return hit;
  const head = await fetchBytes(url, HEADER_TIMEOUT_MS, "0-1023");
  const header = readBloscHeader(head);
  if (header.flags & 0x2) throw new Error("Uncompressed ERA5 chunks are not expected");
  const index = { header, starts: readBlockStarts(head, header) };
  indexCache.set(url, index);
  return index;
}

/** Reads one float32 element by downloading only the compressed block that contains it. */
export async function readValueAt(url: string, elementIndex: number): Promise<number> {
  const { header, starts } = await chunkIndex(url);
  const byteOffset = elementIndex * 4;
  if (byteOffset < 0 || byteOffset + 4 > header.nbytes) throw new Error("Element out of range");
  const block = Math.floor(byteOffset / header.blocksize);
  const key = `${url}#${block}`;
  let values = blockCache.get(key);
  if (!values) {
    const start = starts[block]!;
    const end = block + 1 < starts.length ? starts[block + 1]! : header.cbytes;
    const compressed = await fetchBytes(url, BLOCK_TIMEOUT_MS, `${start}-${end - 1}`);
    const bsize = Math.min(header.blocksize, header.nbytes - block * header.blocksize);
    const out = new Uint8Array(bsize);
    decodeBloscBlock(header, block, compressed, 0, out, 0);
    values = new Float32Array(out.buffer);
    blockCache.set(key, values);
  }
  return values[(byteOffset - block * header.blocksize) / 4]!;
}

/** Downloads and decodes one whole global hourly field. */
export async function readField(url: string): Promise<Float32Array> {
  return decodeWindChunk(await fetchBytes(url, CHUNK_TIMEOUT_MS));
}

/** True when the hourly chunk exists (HEAD request). */
export async function chunkExists(url: string): Promise<boolean> {
  const res = await fetch(url, { method: "HEAD", signal: AbortSignal.timeout(HEADER_TIMEOUT_MS) });
  if (res.status === 404) return false;
  if (!res.ok) throw new Error(`ERA5 store HTTP ${res.status}`);
  return true;
}

/** Coverage dates published in the store's .zattrs. */
export async function fetchCoverage(): Promise<WindCoverage> {
  const res = await fetch(ZATTRS_URL, { signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new Error(`ERA5 store HTTP ${res.status}`);
  return parseCoverage(await res.json());
}

/* Wind helpers (u10/v10 at the fixed wind hour). */
export const readWindValue = (c: WindComponent, date: string, elementIndex: number) =>
  readValueAt(chunkUrl(c, date), elementIndex);
export const readWindField = (c: WindComponent, date: string) => readField(chunkUrl(c, date));
export const windChunkExists = (c: WindComponent, date: string) => chunkExists(chunkUrl(c, date));
