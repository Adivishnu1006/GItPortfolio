/**
 * ERA5 total precipitation rules shared by the server function, the map route and tests.
 * Pure, runtime-agnostic code only.
 *
 * Source: ARCO-ERA5 analysis-ready store (same store and decoder as the wind layer), variable
 * total_precipitation (short name tp, ECMWF parameter 228), units m of water equivalent.
 * It is rain plus snow (liquid and frozen water) reaching the surface, large-scale + convective.
 *
 * Accumulation convention (ECMWF, ERA5 hourly data as served by the CDS and mirrored by
 * ARCO-ERA5): each hourly value is the amount accumulated over the 1 hour ENDING at its valid
 * time; values are already de-accumulated (verified: they rise and fall within forecast
 * windows instead of growing monotonically). Daily total for UTC day D therefore =
 * sum of the 24 values valid at D 01:00 … D+1 00:00 (period D 00:00 → D+1 00:00). The value
 * valid at D 00:00 belongs to the previous day and is never counted for D.
 */
import { addDays, hourIndex, type WindPointInput } from "@/lib/era5-wind-core";

export const PRECIP_VARIABLE = {
  name: "total_precipitation",
  shortName: "tp",
  paramId: 228,
  sourceUnits: "m",
} as const;

export const metresToMm = (m: number) => m * 1000;

/** Zarr time indices of the 24 hourly accumulations that make up UTC day `date`. */
export function dailyHourIndices(date: string): number[] {
  const first = hourIndex(date, 1);
  const last = hourIndex(addDays(date, 1), 0);
  const out = Array.from({ length: 24 }, (_, i) => first + i);
  if (out[23] !== last) throw new Error("Day boundary mismatch");
  return out;
}

/** Valid times (ISO, UTC) of those 24 hourly accumulations. */
export function dailyValidTimes(date: string): string[] {
  const start = Date.parse(`${date}T00:00:00Z`);
  return Array.from({ length: 24 }, (_, i) =>
    new Date(start + (i + 1) * 3_600_000).toISOString().replace(".000Z", "Z"),
  );
}

export type PrecipObservation = {
  totalMm: number;
  /** Largest single-hour amount in the day (mm). */
  maxHourMm: number;
  /** Hours with at least 0.1 mm. */
  wetHours: number;
  date: string;
  periodStart: string;
  periodEnd: string;
  release: "ERA5" | "ERA5T";
  gridLatitude: number;
  gridLongitude: number;
};

export type PrecipPointResult =
  | { status: "ok"; observation: PrecipObservation }
  | { status: "no-data"; date: string; message: string }
  | { status: "unavailable"; message: string };

export type PrecipPointInput = WindPointInput & { finalStop: string | null };

/**
 * Daily total from the 24 hourly accumulations (metres). Anything other than 24 finite values
 * is an incomplete day and never becomes a total.
 */
export function dailyTotalMm(hourlyMetres: readonly number[]): number | null {
  if (hourlyMetres.length !== 24 || hourlyMetres.some((v) => !Number.isFinite(v))) return null;
  return metresToMm(hourlyMetres.reduce((a, b) => a + b, 0));
}

export function buildPrecipResult(
  hourlyMetres: readonly number[],
  cell: { gridLatitude: number; gridLongitude: number },
  date: string,
  release: "ERA5" | "ERA5T",
): PrecipPointResult {
  const total = dailyTotalMm(hourlyMetres);
  if (total === null) {
    const have = hourlyMetres.filter((v) => Number.isFinite(v)).length;
    return {
      status: "no-data",
      date,
      message: `ERA5 has ${have} of the 24 hourly values for this grid point on this day, so no daily total is shown.`,
    };
  }
  const mm = hourlyMetres.map(metresToMm);
  return {
    status: "ok",
    observation: {
      totalMm: total,
      maxHourMm: Math.max(...mm),
      wetHours: mm.filter((v) => v >= 0.1).length,
      date,
      periodStart: `${date}T00:00:00Z`,
      periodEnd: `${addDays(date, 1)}T00:00:00Z`,
      release,
      gridLatitude: cell.gridLatitude,
      gridLongitude: cell.gridLongitude,
    },
  };
}

/**
 * Colour classes (mm/day), lower bounds. Class 0 is "dry" (< 0.1 mm, below the smallest
 * amount a standard rain gauge records). Wet classes use ColorBrewer YlGnBu (sequential,
 * colour-blind safe); dry is a neutral grey so it is never confused with missing data, which
 * is fully transparent. The CSS ramp (--precip-ramp) uses the same colours in order.
 */
export const PRECIP_LOWER_BOUNDS = [0, 0.1, 1, 2, 5, 10, 20, 50, 100] as const;
export const PRECIP_COLOURS = [
  "#d9d4cb",
  "#edf8b1",
  "#c7e9b4",
  "#7fcdbb",
  "#41b6c4",
  "#1d91c0",
  "#225ea8",
  "#253494",
  "#081d58",
] as const;
export const PRECIP_MISSING_INDEX = PRECIP_COLOURS.length;

export function precipClass(totalMm: number): number | null {
  if (!Number.isFinite(totalMm)) return null;
  let cls = 0;
  for (let i = 1; i < PRECIP_LOWER_BOUNDS.length; i++) {
    if (totalMm >= PRECIP_LOWER_BOUNDS[i]!) cls = i;
  }
  return cls;
}

export const PRECIP_LATEST_UNAVAILABLE =
  "The latest complete ERA5 precipitation day could not be confirmed right now.";
export const PRECIP_POINT_UNREACHABLE =
  "ERA5 precipitation could not be retrieved. Please try again shortly.";

export type PrecipView =
  { state: "idle" } | { state: "loading" } | { state: "done"; result: PrecipPointResult };

export type PrecipViewInput = {
  hasLocation: boolean;
  latest: { settled: boolean; date: string | null; error?: string | null | undefined };
  point: { data?: PrecipPointResult | undefined; isError: boolean };
};

/** Inspector state for precipitation; independent of the layer drawn on the globe. */
export function derivePrecipView({ hasLocation, latest, point }: PrecipViewInput): PrecipView {
  if (!hasLocation) return { state: "idle" };
  if (!latest.settled) return { state: "loading" };
  if (!latest.date) {
    return {
      state: "done",
      result: { status: "unavailable", message: latest.error ?? PRECIP_LATEST_UNAVAILABLE },
    };
  }
  if (point.isError) {
    return { state: "done", result: { status: "unavailable", message: PRECIP_POINT_UNREACHABLE } };
  }
  if (point.data) {
    // A total for another day is never shown under the current map date.
    if (point.data.status === "ok" && point.data.observation.date !== latest.date) {
      return { state: "loading" };
    }
    return { state: "done", result: point.data };
  }
  return { state: "loading" };
}

export function precipSummary(view: PrecipView): string {
  if (view.state === "idle") return "";
  if (view.state === "loading") return "Retrieving ERA5 precipitation…";
  const r = view.result;
  if (r.status === "ok") return `${r.observation.totalMm.toFixed(1)} mm · ${r.observation.date}`;
  if (r.status === "no-data") return "No complete daily total";
  return "Value unavailable";
}
