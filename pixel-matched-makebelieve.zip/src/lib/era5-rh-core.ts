/**
 * ERA5 2 m relative humidity rules shared by the server function, the map route and tests.
 * Pure, runtime-agnostic code only.
 *
 * ERA5 does not archive near-surface relative humidity. Following the ECMWF/C3S ERA5 data
 * documentation ("Computation of near-surface humidity",
 * https://confluence.ecmwf.int/pages/viewpage.action?pageId=181128119), it is derived from
 * 2 m temperature T (2m_temperature, 2t, param 167, K) and 2 m dew-point temperature Td
 * (2m_dewpoint_temperature, 2d, param 168, K):
 *
 *   RH (%) = 100 · es(Td) / es(T)
 *
 * es is the saturation vapour pressure over WATER (ECMWF's stated usual practice for
 * near-surface RH), using the Tetens form of the IFS documentation (Part IV, eq. 7.5, water
 * parameters): es(T) = a1 · exp(a3 · (T − T0) / (T − a4)), a1 = 611.21 Pa, a3 = 17.502,
 * a4 = 32.19 K, T0 = 273.16 K. The formula takes kelvin directly (no °C conversion needed).
 * Both inputs come from the same ARCO-ERA5 store, hour and grid element, so grid, time,
 * release (ERA5/ERA5T) and missing-data mask are identical.
 */
import { releaseFor, WIND_HOUR_UTC, type GridCell } from "@/lib/era5-wind-core";

export const RH_VARIABLES = {
  temperature: { name: "2m_temperature", shortName: "2t", paramId: 167, units: "K" },
  dewpoint: { name: "2m_dewpoint_temperature", shortName: "2d", paramId: 168, units: "K" },
} as const;

/** UTC hour shown on the map and in the inspector (instantaneous, same as the wind layer). */
export const RH_HOUR_UTC = WIND_HOUR_UTC;

/** IFS Tetens constants for saturation over water. */
export const ES_WATER = { a1: 611.21, a3: 17.502, a4: 32.19, t0: 273.16 } as const;

/** Saturation vapour pressure over water (Pa) at temperature `kelvin`. */
export function saturationVapourPressure(kelvin: number): number {
  const { a1, a3, a4, t0 } = ES_WATER;
  return a1 * Math.exp((a3 * (kelvin - t0)) / (kelvin - a4));
}

/** Largest overshoot above 100 % treated as rounding noise (≈ 0.07 K of Td above T). */
export const RH_OVERSHOOT_TOLERANCE = 0.5;
/** Plausible near-surface temperature range (K); outside it the inputs are not trusted. */
const PLAUSIBLE_K = { min: 150, max: 350 } as const;

export type RhComputation =
  | { status: "ok"; rh: number; clamped: boolean }
  | { status: "missing" }
  | { status: "inconsistent" };

/**
 * RH from T and Td (both K, same hour and grid point). Only a tiny overshoot above 100 % is
 * clamped; a dew point clearly above the air temperature or an implausible value is refused,
 * so clamping can never hide bad or mismatched inputs.
 */
export function computeRelativeHumidity(temperatureK: number, dewpointK: number): RhComputation {
  if (!Number.isFinite(temperatureK) || !Number.isFinite(dewpointK)) return { status: "missing" };
  const plausible = (k: number) => k >= PLAUSIBLE_K.min && k <= PLAUSIBLE_K.max;
  if (!plausible(temperatureK) || !plausible(dewpointK)) return { status: "inconsistent" };
  const raw = (100 * saturationVapourPressure(dewpointK)) / saturationVapourPressure(temperatureK);
  if (!Number.isFinite(raw) || raw < 0) return { status: "inconsistent" };
  if (raw > 100 + RH_OVERSHOOT_TOLERANCE) return { status: "inconsistent" };
  if (raw > 100) return { status: "ok", rh: 100, clamped: true };
  return { status: "ok", rh: raw, clamped: false };
}

export const kelvinToCelsius = (k: number) => k - 273.15;

/* ----------------------------------------------------------------------------------------- */
/* Point results                                                                               */

export type HumidityObservation = {
  rhPercent: number;
  /** True when a rounding overshoot just above 100 % was set to 100 %. */
  clamped: boolean;
  temperatureK: number;
  dewpointK: number;
  /** ISO time of the instantaneous hourly inputs. */
  time: string;
  release: "ERA5" | "ERA5T";
  gridLatitude: number;
  gridLongitude: number;
};

export type HumidityPointResult =
  | { status: "ok"; observation: HumidityObservation }
  | { status: "no-data"; time: string; message: string }
  | { status: "unavailable"; message: string };

export function humidityTimeIso(date: string): string {
  return `${date}T${String(RH_HOUR_UTC).padStart(2, "0")}:00:00Z`;
}

/** Builds the point result from T and Td read at the same element of the same hour's chunks. */
export function buildHumidityResult(
  temperatureK: number,
  dewpointK: number,
  cell: Pick<GridCell, "gridLatitude" | "gridLongitude">,
  date: string,
  finalStop: string | null,
): HumidityPointResult {
  const time = humidityTimeIso(date);
  const rh = computeRelativeHumidity(temperatureK, dewpointK);
  if (rh.status === "missing") {
    return {
      status: "no-data",
      time,
      message:
        "ERA5 is missing the 2 m temperature or dew point for this grid point at this hour, so no humidity is shown.",
    };
  }
  if (rh.status === "inconsistent") {
    return {
      status: "no-data",
      time,
      message:
        "The ERA5 temperature and dew-point values here are not physically consistent, so no humidity is shown.",
    };
  }
  return {
    status: "ok",
    observation: {
      rhPercent: rh.rh,
      clamped: rh.clamped,
      temperatureK,
      dewpointK,
      time,
      release: releaseFor(date, finalStop),
      gridLatitude: cell.gridLatitude,
      gridLongitude: cell.gridLongitude,
    },
  };
}

/* ----------------------------------------------------------------------------------------- */
/* Map classes                                                                                 */

/**
 * Ten 10 % classes, dry → humid: ColorBrewer BrBG (10-class, diverging brown → blue-green,
 * colour-blind safe). Class 0 (0–10 %) is a solid colour, so valid very low humidity is never
 * confused with missing data, which is fully transparent. The CSS ramp (--rh-ramp) uses the same
 * colours in order.
 */
export const RH_CLASS_STEP = 10;
export const RH_COLOURS = [
  "#543005",
  "#8c510a",
  "#bf812d",
  "#dfc27d",
  "#f6e8c3",
  "#c7eae5",
  "#80cdc1",
  "#35978f",
  "#01665e",
  "#003c30",
] as const;
export const RH_MISSING_INDEX = RH_COLOURS.length;

/** Colour class 0–9 for a valid RH (0–100 %), null otherwise. */
export function rhClass(rhPercent: number): number | null {
  if (!Number.isFinite(rhPercent) || rhPercent < 0 || rhPercent > 100) return null;
  return Math.min(RH_COLOURS.length - 1, Math.floor(rhPercent / RH_CLASS_STEP));
}

/** Map palette index for one grid element: RH class, or transparent when not computable. */
export function rhPaletteIndex(temperatureK: number, dewpointK: number): number {
  const rh = computeRelativeHumidity(temperatureK, dewpointK);
  return rh.status === "ok" ? rhClass(rh.rh)! : RH_MISSING_INDEX;
}

/* ----------------------------------------------------------------------------------------- */
/* Inspector view                                                                              */

export const RH_LATEST_UNAVAILABLE =
  "The latest ERA5 humidity hour could not be confirmed right now.";
export const RH_POINT_UNREACHABLE =
  "ERA5 temperature and dew point could not be retrieved. Please try again shortly.";

export type HumidityView =
  { state: "idle" } | { state: "loading" } | { state: "done"; result: HumidityPointResult };

export type HumidityViewInput = {
  hasLocation: boolean;
  latest: { settled: boolean; date: string | null; error?: string | null | undefined };
  point: { data?: HumidityPointResult | undefined; isError: boolean };
};

/** Inspector state for relative humidity; independent of the layer drawn on the globe. */
export function deriveHumidityView({
  hasLocation,
  latest,
  point,
}: HumidityViewInput): HumidityView {
  if (!hasLocation) return { state: "idle" };
  if (!latest.settled) return { state: "loading" };
  if (!latest.date) {
    return {
      state: "done",
      result: { status: "unavailable", message: latest.error ?? RH_LATEST_UNAVAILABLE },
    };
  }
  if (point.isError) {
    return { state: "done", result: { status: "unavailable", message: RH_POINT_UNREACHABLE } };
  }
  if (point.data) {
    // A value for another hour is never shown under the current map time.
    if (
      point.data.status === "ok" &&
      point.data.observation.time !== humidityTimeIso(latest.date)
    ) {
      return { state: "loading" };
    }
    return { state: "done", result: point.data };
  }
  return { state: "loading" };
}

export function humiditySummary(view: HumidityView): string {
  if (view.state === "idle") return "";
  if (view.state === "loading") return "Retrieving ERA5 humidity…";
  const r = view.result;
  if (r.status === "ok") {
    return `${Math.round(r.observation.rhPercent)} % · ${r.observation.time.slice(0, 10)} ${RH_HOUR_UTC}:00 UTC`;
  }
  if (r.status === "no-data") return "No ERA5 humidity value";
  return "Value unavailable";
}
