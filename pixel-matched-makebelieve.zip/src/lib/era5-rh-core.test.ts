import { describe, expect, it } from "vitest";
import {
  buildHumidityResult,
  computeRelativeHumidity,
  deriveHumidityView,
  humidityTimeIso,
  RH_COLOURS,
  RH_HOUR_UTC,
  RH_MISSING_INDEX,
  RH_POINT_UNREACHABLE,
  RH_VARIABLES,
  rhClass,
  rhPaletteIndex,
  saturationVapourPressure,
} from "@/lib/era5-rh-core";
import {
  arcoChunkUrl,
  ARCO_VARIABLES,
  gridRaster,
  hourIndex,
  nearestGridCell,
  WIND_GRID,
  WIND_MAP_WIDTH,
} from "@/lib/era5-wind-core";

/*
 * Real ARCO-ERA5 2 m temperature and dew point (K) at 2026-10-13 12:00 UTC, nearest grid
 * point. Open-Meteo's ERA5 archive (independent copy, rounded to 1 %) reports 13 % for Riyadh
 * and 83 % for Singapore at the same hour and grid point.
 */
const RIYADH = { lat: 24.75, lon: 46.75, t: 309.98602294921875, td: 277.5970153808594 };
const SINGAPORE = { lat: 1.25, lon: 103.75, t: 300.98797607421875, td: 297.7571716308594 };
const PACIFIC = { lat: 0, lon: -140, t: 301.70281982421875, td: 297.6204528808594 };

const rhOf = (t: number, td: number) => {
  const r = computeRelativeHumidity(t, td);
  if (r.status !== "ok") throw new Error(`expected ok, got ${r.status}`);
  return r.rh;
};

describe("inputs", () => {
  it("reads ERA5 2m_temperature and 2m_dewpoint_temperature from the same hour", () => {
    expect(RH_VARIABLES.temperature.name).toBe("2m_temperature");
    expect(RH_VARIABLES.dewpoint.name).toBe("2m_dewpoint_temperature");
    expect(ARCO_VARIABLES.t2m).toBe("2m_temperature");
    expect(ARCO_VARIABLES.d2m).toBe("2m_dewpoint_temperature");
    const t = hourIndex("2026-10-13", RH_HOUR_UTC);
    expect(arcoChunkUrl("t2m", t)).toMatch(/\/2m_temperature\/1111356\.0\.0$/);
    expect(arcoChunkUrl("d2m", t)).toMatch(/\/2m_dewpoint_temperature\/1111356\.0\.0$/);
  });
});

describe("saturation vapour pressure (over water, IFS Tetens)", () => {
  it("equals 611.21 Pa at the triple point", () => {
    expect(saturationVapourPressure(273.16)).toBeCloseTo(611.21, 6);
  });
  it("is about 2.34 kPa at 20 °C", () => {
    expect(saturationVapourPressure(293.15)).toBeGreaterThan(2330);
    expect(saturationVapourPressure(293.15)).toBeLessThan(2345);
  });
});

describe("relative humidity = 100 · es(Td)/es(T)", () => {
  it("is 100 % when the dew point equals the air temperature", () => {
    expect(rhOf(290, 290)).toBeCloseTo(100, 10);
  });
  it("gives a dry-area value (Riyadh) matching the independent ERA5 copy", () => {
    expect(rhOf(RIYADH.t, RIYADH.td)).toBeCloseTo(13.48, 2);
    expect(Math.abs(rhOf(RIYADH.t, RIYADH.td) - 13)).toBeLessThanOrEqual(0.5);
  });
  it("gives a humid value (Singapore, land) matching the independent ERA5 copy", () => {
    expect(rhOf(SINGAPORE.t, SINGAPORE.td)).toBeCloseTo(82.62, 2);
    expect(Math.abs(rhOf(SINGAPORE.t, SINGAPORE.td) - 83)).toBeLessThanOrEqual(0.5);
  });
  it("gives an ocean value (equatorial Pacific)", () => {
    expect(rhOf(PACIFIC.t, PACIFIC.td)).toBeCloseTo(78.61, 2);
  });
  it("clamps only a tiny overshoot above 100 %", () => {
    expect(computeRelativeHumidity(280, 280.05)).toEqual({ status: "ok", rh: 100, clamped: true });
  });
  it("refuses a dew point clearly above the air temperature instead of clamping it", () => {
    expect(computeRelativeHumidity(280, 282).status).toBe("inconsistent");
    // Swapped inputs must not silently become 100 %.
    expect(computeRelativeHumidity(RIYADH.td, RIYADH.t).status).toBe("inconsistent");
  });
  it("treats a missing input as missing, never as zero humidity", () => {
    expect(computeRelativeHumidity(Number.NaN, 280).status).toBe("missing");
    expect(computeRelativeHumidity(280, Number.NaN).status).toBe("missing");
  });
  it("refuses inputs that are not kelvin temperatures", () => {
    expect(computeRelativeHumidity(25, 10).status).toBe("inconsistent");
  });
});

describe("point result", () => {
  const cell = nearestGridCell(RIYADH.lat, RIYADH.lon);
  it("carries the 12:00 UTC time, inputs and grid point", () => {
    const r = buildHumidityResult(RIYADH.t, RIYADH.td, cell, "2026-10-13", "2026-06-30");
    expect(r.status).toBe("ok");
    if (r.status !== "ok") return;
    expect(r.observation.time).toBe("2026-10-13T12:00:00Z");
    expect(r.observation.temperatureK).toBe(RIYADH.t);
    expect(r.observation.dewpointK).toBe(RIYADH.td);
    expect(r.observation.gridLatitude).toBe(24.75);
    expect(r.observation.gridLongitude).toBe(46.75);
    expect(r.observation.release).toBe("ERA5T");
  });
  it("shows no value when an input is missing", () => {
    const r = buildHumidityResult(Number.NaN, RIYADH.td, cell, "2026-10-13", null);
    expect(r.status).toBe("no-data");
  });
});

describe("map classes", () => {
  it("uses ten 10 % classes; 0 % is a visible class, not missing", () => {
    expect(RH_COLOURS).toHaveLength(10);
    expect(rhClass(0)).toBe(0);
    expect(rhClass(9.99)).toBe(0);
    expect(rhClass(10)).toBe(1);
    expect(rhClass(82.6)).toBe(8);
    expect(rhClass(100)).toBe(9);
    expect(rhClass(Number.NaN)).toBeNull();
  });
  it("makes missing or inconsistent inputs transparent", () => {
    expect(rhPaletteIndex(Number.NaN, 280)).toBe(RH_MISSING_INDEX);
    expect(rhPaletteIndex(280, 290)).toBe(RH_MISSING_INDEX);
    expect(rhPaletteIndex(RIYADH.t, RIYADH.td)).toBe(1);
  });
  it("colours each pixel from the same grid element as the point reading", () => {
    const n = WIND_GRID.latCount * WIND_GRID.lonCount;
    const t = new Float32Array(n).fill(Number.NaN);
    const d = new Float32Array(n).fill(Number.NaN);
    const sg = nearestGridCell(SINGAPORE.lat, SINGAPORE.lon);
    t[sg.index] = SINGAPORE.t;
    d[sg.index] = SINGAPORE.td;
    const raster = gridRaster((i) => rhPaletteIndex(t[i]!, d[i]!));
    // Pixel centre just north-east of the Singapore grid point.
    const row = Math.floor((90 - (SINGAPORE.lat + 0.06)) / 0.125);
    const col = Math.floor((SINGAPORE.lon + 0.06 + 180) / 0.125);
    expect(raster[row * WIND_MAP_WIDTH + col]).toBe(8);
    expect(raster[0]).toBe(RH_MISSING_INDEX);
  });
});

describe("inspector view", () => {
  const latest = { settled: true, date: "2026-10-13" };
  const ok = buildHumidityResult(
    SINGAPORE.t,
    SINGAPORE.td,
    { gridLatitude: 1.25, gridLongitude: 103.75 },
    "2026-10-13",
    null,
  );
  it("is idle without a location and loading before the date is known", () => {
    expect(deriveHumidityView({ hasLocation: false, latest, point: { isError: false } })).toEqual({
      state: "idle",
    });
    expect(
      deriveHumidityView({
        hasLocation: true,
        latest: { settled: false, date: null },
        point: { isError: false },
      }),
    ).toEqual({ state: "loading" });
  });
  it("shows an explicit error when the inputs cannot be fetched", () => {
    const v = deriveHumidityView({ hasLocation: true, latest, point: { isError: true } });
    expect(v).toEqual({
      state: "done",
      result: { status: "unavailable", message: RH_POINT_UNREACHABLE },
    });
  });
  it("never shows a value for a different hour than the map", () => {
    const v = deriveHumidityView({
      hasLocation: true,
      latest: { settled: true, date: "2026-10-12" },
      point: { data: ok, isError: false },
    });
    expect(v).toEqual({ state: "loading" });
    expect(humidityTimeIso("2026-10-12")).toBe("2026-10-12T12:00:00Z");
  });
  it("shows the value for the map's hour", () => {
    const v = deriveHumidityView({
      hasLocation: true,
      latest,
      point: { data: ok, isError: false },
    });
    expect(v).toEqual({ state: "done", result: ok });
  });
});
