/**
 * ERA5 vertically integrated water-vapour transport ("atmospheric moisture flux") rules shared
 * by the server function, the map route and tests. Pure, runtime-agnostic code only.
 *
 * Source: ERA5 hourly single levels (ERA5 data documentation, Table 6 "vertical integrals and
 * total column: instantaneous", https://confluence.ecmwf.int/pages/viewpage.action?pageId=414588701),
 * read from the ARCO-ERA5 store (same store and decoder as the wind layer):
 *  - vertical_integral_of_eastward_water_vapour_flux  (viwve, param 162071), kg m**-1 s**-1
 *  - vertical_integral_of_northward_water_vapour_flux (viwvn, param 162072), kg m**-1 s**-1
 * Each is the horizontal rate of flow of water vapour per metre across the flow, for the
 * column from the surface to the top of the atmosphere; positive = towards east / north
 * (https://codes.ecmwf.int/grib/param-db/162071). Both are instantaneous analysis values.
 *
 * Magnitude (IVT) = sqrt(Fx² + Fy²) from the two components of the same hour and grid element,
 * kept in kg m⁻¹ s⁻¹. Shown at IVT_HOUR_UTC, instantaneous (no time mean, so no averaging of
 * magnitudes or components happens anywhere).
 */
import { compassPoint, releaseFor, WIND_HOUR_UTC, type GridCell } from "@/lib/era5-wind-core";

export const IVT_VARIABLES = {
  east: {
    name: "vertical_integral_of_eastward_water_vapour_flux",
    shortName: "viwve",
    paramId: 162071,
  },
  north: {
    name: "vertical_integral_of_northward_water_vapour_flux",
    shortName: "viwvn",
    paramId: 162072,
  },
} as const;

export const IVT_UNITS = "kg m⁻¹ s⁻¹";

/** UTC hour shown on the map and in the inspector (instantaneous, same as wind/humidity). */
export const IVT_HOUR_UTC = WIND_HOUR_UTC;

/** Horizontal flux magnitude (kg m⁻¹ s⁻¹) from components of the same hour and cell. */
export function fluxMagnitude(fx: number, fy: number): number {
  return Math.hypot(fx, fy);
}

/**
 * Transport direction: the bearing the water vapour moves TOWARDS, degrees clockwise from true
 * north (90 = towards the east). This is the opposite of the meteorological wind convention
 * (where wind comes FROM). Null when there is no measurable transport.
 */
export function transportDirectionTowards(fx: number, fy: number): number | null {
  if (!Number.isFinite(fx) || !Number.isFinite(fy) || Math.hypot(fx, fy) < 1e-6) return null;
  const deg = (Math.atan2(fx, fy) * 180) / Math.PI;
  return (deg + 360) % 360;
}

export { compassPoint };

/* ----------------------------------------------------------------------------------------- */
/* Point results                                                                               */

export type MoistureFluxObservation = {
  magnitude: number;
  eastward: number;
  northward: number;
  /** Bearing the moisture moves towards; null when there is no transport. */
  directionTowards: number | null;
  /** ISO time of the instantaneous hourly values. */
  time: string;
  release: "ERA5" | "ERA5T";
  gridLatitude: number;
  gridLongitude: number;
};

export type MoistureFluxPointResult =
  | { status: "ok"; observation: MoistureFluxObservation }
  | { status: "no-data"; time: string; message: string }
  | { status: "unavailable"; message: string };

export function fluxTimeIso(date: string): string {
  return `${date}T${String(IVT_HOUR_UTC).padStart(2, "0")}:00:00Z`;
}

/** Builds the point result from Fx and Fy read at the same element of the same hour's chunks. */
export function buildFluxResult(
  eastward: number,
  northward: number,
  cell: Pick<GridCell, "gridLatitude" | "gridLongitude">,
  date: string,
  finalStop: string | null,
): MoistureFluxPointResult {
  const time = fluxTimeIso(date);
  if (!Number.isFinite(eastward) || !Number.isFinite(northward)) {
    return {
      status: "no-data",
      time,
      message:
        "ERA5 is missing the eastward or northward moisture-flux component for this grid point at this hour, so no flux is shown.",
    };
  }
  return {
    status: "ok",
    observation: {
      magnitude: fluxMagnitude(eastward, northward),
      eastward,
      northward,
      directionTowards: transportDirectionTowards(eastward, northward),
      time,
      release: releaseFor(date, finalStop),
      gridLatitude: cell.gridLatitude,
      gridLongitude: cell.gridLongitude,
    },
  };
}

/* ----------------------------------------------------------------------------------------- */
/* Map: magnitude classes + direction arrows                                                   */

/**
 * Magnitude classes (lower bounds, kg m⁻¹ s⁻¹). 250, 500, 750 and 1000 are the IVT thresholds of
 * the atmospheric-river scale (Ralph et al., 2019, BAMS 100, 269–289); 250 is the usual minimum
 * for an atmospheric river. Colours: ColorBrewer YlOrRd 9-class (sequential, colour-blind safe).
 * The CSS ramp (--ivt-ramp) uses the same colours in order.
 */
export const IVT_LOWER_BOUNDS = [0, 50, 100, 150, 250, 350, 500, 750, 1000] as const;
export const IVT_COLOURS = [
  "#ffffcc",
  "#ffeda0",
  "#fed976",
  "#feb24c",
  "#fd8d3c",
  "#fc4e2a",
  "#e31a1c",
  "#bd0026",
  "#800026",
] as const;
/** Arrow outline and core colours, appended after the data classes. */
export const IVT_ARROW_OUTLINE_INDEX = IVT_COLOURS.length;
export const IVT_ARROW_CORE_INDEX = IVT_COLOURS.length + 1;
export const IVT_MAP_PALETTE = [...IVT_COLOURS, "#1b1b1b", "#ffffff"] as const;
/** Transparent palette index (missing data). */
export const IVT_MISSING_INDEX = IVT_MAP_PALETTE.length;

export function ivtClass(magnitude: number): number | null {
  if (!Number.isFinite(magnitude) || magnitude < 0) return null;
  let cls = 0;
  for (let i = 1; i < IVT_LOWER_BOUNDS.length; i++) {
    if (magnitude >= IVT_LOWER_BOUNDS[i]!) cls = i;
  }
  return cls;
}

/** Palette index for one grid element: magnitude class, or transparent when a component is missing. */
export function ivtPaletteIndex(fx: number, fy: number): number {
  const cls = ivtClass(fluxMagnitude(fx, fy));
  return cls === null ? IVT_MISSING_INDEX : cls;
}

/** Arrow sampling: every ARROW_STEP grid points (5°), between ±ARROW_MAX_LAT, at the grid point itself. */
export const ARROW_STEP = 20;
export const ARROW_MAX_LAT = 70;
/** Arrows are drawn only where the magnitude is at least this (kg m⁻¹ s⁻¹). */
export const ARROW_MIN_MAGNITUDE = 50;

/** Map pixel geometry (must match the shared 0.125° map raster). */
export type MapGeometry = { width: number; height: number; pixelDeg: number };

/**
 * Draws direction arrows into a palette raster from the real Fx/Fy fields. Each arrow is centred
 * on a sampled grid point and points the way the moisture moves. Lengths grow with magnitude.
 * East–west pixel offsets are divided by cos(latitude) so the arrow keeps its true bearing once
 * the equirectangular image is draped on the globe.
 */
export function drawFluxArrows(
  raster: Uint8Array,
  fx: Float32Array,
  fy: Float32Array,
  geo: MapGeometry,
  lonCount: number,
  latCount: number,
): number {
  const { width, height, pixelDeg } = geo;
  const core = new Uint8Array(width * height);
  const plot = (x: number, y: number) => {
    const yi = Math.round(y);
    if (yi < 0 || yi >= height) return;
    const xi = ((Math.round(x) % width) + width) % width;
    core[yi * width + xi] = 1;
  };
  const line = (x0: number, y0: number, x1: number, y1: number) => {
    const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
    for (let s = 0; s <= n; s++) plot(x0 + ((x1 - x0) * s) / n, y0 + ((y1 - y0) * s) / n);
  };
  const pxPerDeg = 1 / pixelDeg;
  let count = 0;
  for (let latIndex = 0; latIndex < latCount; latIndex += ARROW_STEP) {
    const lat = 90 - latIndex * 0.25;
    if (Math.abs(lat) > ARROW_MAX_LAT) continue;
    const cosLat = Math.cos((lat * Math.PI) / 180);
    for (let lonIndex = 0; lonIndex < lonCount; lonIndex += ARROW_STEP) {
      const i = latIndex * lonCount + lonIndex;
      const u = fx[i]!;
      const v = fy[i]!;
      const mag = Math.hypot(u, v);
      if (!Number.isFinite(mag) || mag < ARROW_MIN_MAGNITUDE) continue;
      const lon = lonIndex * 0.25 > 180 ? lonIndex * 0.25 - 360 : lonIndex * 0.25;
      const cx = (lon + 180) * pxPerDeg;
      const cy = (90 - lat) * pxPerDeg;
      const length = 10 + 18 * Math.min(1, mag / 750); // pixels, globe-equivalent
      // Unit vector in "true" east/north, then to image pixels.
      const ex = u / mag;
      const ny = v / mag;
      const toImg = (east: number, north: number) => [(east * length) / cosLat, -north * length];
      const [dx, dy] = toImg(ex, ny);
      const x0 = cx - dx! / 2;
      const y0 = cy - dy! / 2;
      const x1 = cx + dx! / 2;
      const y1 = cy + dy! / 2;
      line(x0, y0, x1, y1);
      // Head: two barbs at ±150° from the direction, 35 % of the length.
      for (const a of [150, -150]) {
        const r = (a * Math.PI) / 180;
        const be = (ex * Math.cos(r) - ny * Math.sin(r)) * 0.35;
        const bn = (ex * Math.sin(r) + ny * Math.cos(r)) * 0.35;
        const [bx, by] = toImg(be, bn);
        line(x1, y1, x1 + bx!, y1 + by!);
      }
      count++;
    }
  }
  // Outline every core pixel's neighbours, then paint the core on top.
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      if (!core[y * width + x]) continue;
      for (let oy = -1; oy <= 1; oy++) {
        const yy = y + oy;
        if (yy < 0 || yy >= height) continue;
        for (let ox = -1; ox <= 1; ox++) {
          const xx = (x + ox + width) % width;
          if (!core[yy * width + xx]) raster[yy * width + xx] = IVT_ARROW_OUTLINE_INDEX;
        }
      }
    }
  }
  for (let p = 0; p < core.length; p++) if (core[p]) raster[p] = IVT_ARROW_CORE_INDEX;
  return count;
}

/* ----------------------------------------------------------------------------------------- */
/* Inspector view                                                                              */

export const IVT_LATEST_UNAVAILABLE =
  "The latest ERA5 moisture-flux hour could not be confirmed right now.";
export const IVT_POINT_UNREACHABLE =
  "ERA5 moisture-flux components could not be retrieved. Please try again shortly.";

export type MoistureFluxView =
  { state: "idle" } | { state: "loading" } | { state: "done"; result: MoistureFluxPointResult };

export type MoistureFluxViewInput = {
  hasLocation: boolean;
  latest: { settled: boolean; date: string | null; error?: string | null | undefined };
  point: { data?: MoistureFluxPointResult | undefined; isError: boolean };
};

/** Inspector state for moisture flux; independent of the layer drawn on the globe. */
export function deriveMoistureFluxView({
  hasLocation,
  latest,
  point,
}: MoistureFluxViewInput): MoistureFluxView {
  if (!hasLocation) return { state: "idle" };
  if (!latest.settled) return { state: "loading" };
  if (!latest.date) {
    return {
      state: "done",
      result: { status: "unavailable", message: latest.error ?? IVT_LATEST_UNAVAILABLE },
    };
  }
  if (point.isError) {
    return { state: "done", result: { status: "unavailable", message: IVT_POINT_UNREACHABLE } };
  }
  if (point.data) {
    // A value for another hour is never shown under the current map time.
    if (point.data.status === "ok" && point.data.observation.time !== fluxTimeIso(latest.date)) {
      return { state: "loading" };
    }
    return { state: "done", result: point.data };
  }
  return { state: "loading" };
}

export function moistureFluxSummary(view: MoistureFluxView): string {
  if (view.state === "idle") return "";
  if (view.state === "loading") return "Retrieving ERA5 moisture flux…";
  const r = view.result;
  if (r.status === "ok") {
    return `${Math.round(r.observation.magnitude)} ${IVT_UNITS} · ${r.observation.time.slice(0, 10)} ${IVT_HOUR_UTC}:00 UTC`;
  }
  if (r.status === "no-data") return "No ERA5 flux value";
  return "Value unavailable";
}
