<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Project rules

- Route files in `src/routes` stay thin (head + component wiring); page bodies live in `src/components/views`, shared chrome in `src/components/portfolio`, all copy in `src/data/content.ts` — keeps content editable in one place.
- Full research case studies register in `src/components/views/caseStudies.ts` and render via `/research/$slug` — new case studies need no new route file.
- Design tokens live only in `src/styles.css`; portfolio semantic colours (`bg`, `bg-alt`, `surface`, `body`, `muted` = muted text, `accent`, `accent-soft`, `default` = border, `warning`) are the ones to use, and shadcn's `muted`/`accent` follow these portfolio meanings — avoids two competing palettes.
- The site is dark-only: `.dark` is set on `<html>` in `__root.tsx`; no theme toggle — matches the original design.
- The root layout wrapper uses `isolate` so `-z-10` hero backgrounds paint above the page background — remove it and hero photos disappear.
- CesiumJS loads at runtime from the pinned jsDelivr build (`src/lib/cesium-loader.ts`, SRI) only inside `useEffect` on `/earth`; npm `cesium` is a types-only devDependency whose version must equal `CESIUM_VERSION` — keeps Cesium out of SSR/Worker bundles.
- NOAA ERDDAP sends no CORS headers, so all NOAA access is server-side: point values and latest date via `src/lib/sst.functions.ts`, overlay tiles via `/api/sst-tiles/$z/$x/$y`; upstream URLs are rebuilt only from validated inputs in `src/lib/sst-core.ts` — never forward client-supplied URLs.
- SST has two allow-listed NOAA ERDDAP sources (`SST_SOURCES`: CoastWatch primary, NCEI fallback) (CoastWatch times out from the hosted server over IPv6); points and tiles always carry the probed source and an explicit verified date, never `last` (blank/empty images).
- Land/missing SST cells return `no-data`; never substitute a nearby ocean value (covered by `src/lib/sst-core.test.ts`).
- Globe basemaps must be keyless and CORS-enabled (configured in `src/config/earthLayers.ts`); never fall back to a provider with an empty key.
- Cesium teardown order: event handlers/listeners → entities → imagery layers → `viewer.destroy()`.
- Earth Explorer keeps the globe layer (`activeLayerId`) and the inspected point (`selectedLocation`) independent; the inspector shows every measurement for the point, with states derived by tested `derive*View` functions (`src/lib/earth-inspector.ts`, `era5-core.ts`, `era5-wind-core.ts`, `era5-precip-core.ts`, `era5-rh-core.ts`, `era5-ivt-core.ts`) — planned layers are previewed as notices and never drawn. Each overlay reports its own status (`OverlayId`) so switching layers cannot overwrite another layer's status.
- ERA5 2 m air temperature: the map is the official C3S/ECMWF Climate Pulse daily-mean image (no CORS header, so served same-origin via `/api/era5-t2m-map/$date`, URL rebuilt only from a validated date in `src/lib/era5-core.ts`); point values come from Open-Meteo's keyless ERA5 archive called from the browser (`src/lib/era5.ts`, per-visitor rate limit) with `elevation=nan` and `cell_selection=nearest` (raw grid point). Map and points share the newest UTC day with all 24 hourly values; incomplete days are never averaged.
- ERA5 wind, precipitation, humidity and moisture flux read the public ARCO-ERA5 Zarr store server-side (no key, no CORS): one global hour per chunk, Blosc-LZ4 decoded by our pure decoder in `src/lib/era5-wind-core.ts` (no native npm codec in the Worker). `src/lib/arco-era5-fetch.ts` (shared) reads points via byte ranges of one block, variables only from the `ARCO_VARIABLES` allow-list, fan-out via `mapPool` ≤ 6 (runtime limit). Maps are server-rendered palette PNGs (`/api/era5-{wind,precip,rh,ivt}-map/$date`); map and points share one verified date.
- Wind speed = sqrt(u² + v²) from the same hour and element index. Precipitation `tp` values are 1-hour accumulations ending at the valid time; UTC day D = sum of values valid D 01:00 … D+1 00:00 (`dailyHourIndices`); a missing hour means no total. Dry (< 0.1 mm) is a visible class; missing data is transparent.
- Relative humidity = 100·es(Td)/es(T) from 2m_temperature and 2m_dewpoint_temperature of the same hour and element, es over water (IFS Tetens); only overshoots ≤ 0.5 % are clamped to 100, larger ones and missing inputs give no value (transparent on the map).
- Moisture flux = sqrt(viwve² + viwvn²) (kg m⁻¹ s⁻¹) from the same hour and element; direction is "towards" (opposite of wind "from"); map arrows are drawn server-side from the real components at sampled grid points, never averaged or synthetic.
- Place names come from OpenStreetMap Nominatim, called from the browser (`src/lib/reverse-geocode.ts`) so the site's Referer satisfies Nominatim's policy; requests are spaced ≥1.1 s and cached per rounded point.
