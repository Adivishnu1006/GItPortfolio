# Roadmap

## Phase 1 — Portfolio migration
- [x] Port design system (palette, fonts, type scale, shadows, dark theme) to Tailwind v4 tokens
- [x] Port Navigation, Footer, Reveal and content data
- [x] Port pages: Home, Living Earth, Research, Nepal case study, Articles (+ article detail), About, Resume, Contact
- [x] Keep /earth route and its nav/footer links
- [x] Per-route head metadata
- [x] Resume download file

## Phase 2 — Earth Explorer
- [x] Browser-only Cesium on /earth, assets from pinned CDN build
- [x] Typed globe state (fix missing sstActive/sstDate)
- [x] Server-side NOAA access: latest date + point value (server functions), SST overlay tiles (validated tile route)
- [x] Correct WMS layer name ncdcOisst21Agg_LonPM180:sst
- [x] Land handling: no nearest-ocean substitution
- [x] Safe cleanup ordering
- [x] Street basemap keyless; satellite basemap from a verified keyless provider
- [x] Inspector, legend, attribution, loading and missing-data states

## Phase 3 — Verification
- [x] Unit tests for SST rules (land → no value, input bounds, tile bounds)
- [x] Browser checks: /earth direct, ocean click, land click, overlay, basemap switch, nav away/back, all pages
- [x] Diagnose hosted NOAA timeouts; add NCEI fallback source, dated-only tiles, tile edge repair
- [x] Earth Explorer UX: location inspector independent of globe layer, place names, planned-layer notices
- [ ] Confirm NOAA data loads on the hosted preview (needs one visit to /earth by the user; check server logs for "SST source")
- [ ] Re-check on the published site after the user approves publishing (blocked: needs approval)

## Phase 4 — Second layer: ERA5 2 m air temperature
- [x] Verify official dataset, variable, units, resolution, latency and access paths
- [x] Global daily-mean map (official Climate Pulse image, same-origin route) with legend and data date
- [x] Point values in the inspector (daily mean, K and °C, grid point, source), separate from SST
- [x] Tests (land + ocean point, incomplete day, latest day, failures) and browser checks; map colour matches point values
- [ ] Optional: switch point values to the official Copernicus CDS API (blocked: needs the user's free CDS account key)

## Phase 5 — Third layer: ERA5 10 m wind speed
- [x] Verify source, variables (u10/v10), units, grid, time axis and coverage (ARCO-ERA5 public store)
- [x] Global wind-speed map from real u/v fields (Beaufort classes, viridis), legend with units and data time
- [x] Wind card in the inspector (m/s, km/h, Beaufort, direction, components, grid point, release)
- [x] Tests (formula, km/h, direction, timestamps, grid, missing data, failures, decoder, map raster, PNG) and browser checks

## Phase 6 — Fourth layer: ERA5 daily precipitation
- [x] Verify variable (tp, m), hourly accumulation convention and UTC-day aggregation
- [x] Global daily-total map from 24 real hourly fields (dry / YlGnBu classes, missing transparent)
- [x] Precipitation card in the inspector (mm/day, period, wet hours, release, grid point)
- [x] Tests (m→mm, day boundaries, no double counting, incomplete days, zero vs missing, failures) and browser checks against an independent ERA5 copy

## Phase 7 — Fifth layer: ERA5 2 m relative humidity
- [x] Verify inputs (2m_temperature 2t, 2m_dewpoint_temperature 2d) in ARCO-ERA5 and ECMWF's RH method
- [x] Global RH map from real T/Td fields at 12:00 UTC (10 % BrBG classes, missing transparent), legend in %
- [x] Humidity card in the inspector (%, T/Td inputs, time, formula, grid point, release)
- [x] Tests (formula, dry/humid/ocean samples vs independent ERA5 copy, clamping, missing, map classes, view) and browser checks

## Phase 8 — Sixth layer: ERA5 atmospheric moisture flux
- [x] Verify viwve/viwvn (params 162071/162072, kg m⁻¹ s⁻¹, instantaneous) in ARCO-ERA5
- [x] Global magnitude map (YlOrRd, AR-scale thresholds) with direction arrows from real components
- [x] Inspector card (magnitude, components, direction towards, time, grid, release)
- [x] Tests (formula, units, direction signs, missing data, arrows, view) + pressure-level cross-check + browser checks

## Later (not now)
- Kaleshwaram case study
- Contact form delivery (needs a decision)
- Confirm correct GitHub handle (needs user answer)
